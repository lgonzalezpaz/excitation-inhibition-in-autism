"""
Verification tests for the release model and the structural claims of the
manuscript. These are not smoke tests: each one checks a statement that the
paper makes, so a failure here means a claim in the paper is wrong.

Run with:  pytest -q
"""

from __future__ import annotations

import numpy as np
import pytest

from release_model import (
    SynapseParams, simulate_moments, monte_carlo_train, steady_state_occupancy,
    steady_state_mean, cv2_first_pulse, paired_pulse_ratio, failure_probability,
)
from identifiability import (
    mean_only_jacobian, elasticity_matrix, compensate, LOG_PARAMS,
)
from identifiability2 import pmf_at_isi, pulse_probabilities
from analysis_core import elasticities_analytic, elasticities_numeric
from ceiling import compensable_fraction, max_presynaptic_drive
from params_literature import SYNAPSES, CA3_CA1_HILL, fit_hill_two_points

RNG = np.random.default_rng(20261029)


def _random_synapse(rng):
    return SynapseParams(
        N=float(rng.integers(2, 25)), p0=float(rng.uniform(0.05, 0.9)),
        k_rep=float(rng.uniform(0.5, 40)), q=float(rng.uniform(5, 40)),
        cv_q=float(rng.uniform(0.1, 0.6)), f=float(rng.uniform(0.0, 0.5)),
        tau_f=float(rng.uniform(0.02, 0.4)))


# ---------------------------------------------------------------------------
# The moment recursions are exact
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", list(SYNAPSES))
def test_moments_match_monte_carlo(name):
    prm = SYNAPSES[name]
    prm = SynapseParams(**{**prm.as_dict(), "N": float(round(prm.N))})
    isis = [0.05] * 6
    an = simulate_moments(prm, isis)
    mc = monte_carlo_train(prm, isis, n_trials=300_000, seed=1)
    assert np.max(np.abs(mc["mean"] - an["mean"]) / an["mean"]) < 0.02
    assert np.max(np.abs(mc["var"] - an["var"]) / an["var"]) < 0.03
    assert np.max(np.abs(mc["p_fail"] - an["p_fail"])) < 0.01


def test_steady_state_closed_form_matches_iteration():
    for _ in range(50):
        prm = _random_synapse(RNG)
        prm = SynapseParams(**{**prm.as_dict(), "f": 0.0})
        rate = float(RNG.uniform(1, 100))
        b = np.exp(-prm.k_rep / rate)
        closed = (1 - b) / (1 - (1 - prm.p0) * b)
        u, _ = steady_state_occupancy(prm, rate)
        assert abs(u - closed) < 1e-12


def test_paired_pulse_pmf_normalised_and_matches_simulation():
    prm = SYNAPSES["E_cortical_L5"]
    prm = SynapseParams(**{**prm.as_dict(), "N": 6.0})
    isi = 0.05
    pmf = pmf_at_isi(prm, isi)
    assert abs(pmf.sum() - 1.0) < 1e-12
    r = np.arange(pmf.shape[0])
    mc = monte_carlo_train(prm, [isi], n_trials=300_000, seed=5)
    assert abs((pmf.sum(1) * r).sum() - mc["mean_counts"][0]) < 0.02
    assert abs((pmf.sum(0) * r).sum() - mc["mean_counts"][1]) < 0.02


# ---------------------------------------------------------------------------
# Structural identifiability claims
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", list(SYNAPSES))
def test_mean_only_jacobian_has_rank_one(name):
    j = mean_only_jacobian(SYNAPSES[name])
    assert np.linalg.matrix_rank(j, tol=1e-8) == 1
    # elasticities with respect to N, p and q are each exactly one
    assert np.allclose(j[0, [0, 1, 3]], 1.0, atol=1e-6)
    # and the mean of an isolated response does not depend on resupply
    assert abs(j[0, 2]) < 1e-9


@pytest.mark.parametrize("name", list(SYNAPSES))
def test_full_observable_vector_has_full_rank(name):
    j = elasticity_matrix(SYNAPSES[name])
    assert np.linalg.matrix_rank(j, tol=1e-8) == len(LOG_PARAMS)
    assert np.linalg.cond(j) < 100


def test_structural_zeros_hold_everywhere():
    """dlogPPR/dlogN = 0 and dlogCV2_1/dlog k_rep = 0 identically."""
    h = 1e-5
    for _ in range(200):
        prm = _random_synapse(RNG)
        isi = float(RNG.uniform(0.01, 0.5))
        d_ppr = (np.log(paired_pulse_ratio(prm.perturb(N=np.exp(h)), isi))
                 - np.log(paired_pulse_ratio(prm.perturb(N=np.exp(-h)), isi))) / (2 * h)
        d_cv2 = (np.log(cv2_first_pulse(prm.perturb(k_rep=np.exp(h))))
                 - np.log(cv2_first_pulse(prm.perturb(k_rep=np.exp(-h))))) / (2 * h)
        assert abs(d_ppr) < 1e-8
        assert abs(d_cv2) < 1e-12


def test_elasticity_identity_S_p_equals_steady_state_occupancy():
    for _ in range(100):
        prm = _random_synapse(RNG)
        prm = SynapseParams(**{**prm.as_dict(), "f": 0.0})
        rate = float(RNG.uniform(1, 100))
        a = elasticities_analytic(prm, rate)
        assert abs(a["S_p"] - a["u_star"]) < 1e-12


def test_analytic_and_numeric_elasticities_agree():
    for name in SYNAPSES:
        prm = SynapseParams(**{**SYNAPSES[name].as_dict(), "f": 0.0})
        a = elasticities_analytic(prm, 20.0)
        n = elasticities_numeric(prm, 20.0)
        for k in ("S_N", "S_p", "S_k"):
            assert abs(a[k] - n[k]) < 1e-6


def test_site_lesion_leaves_the_EI_ratio_exactly_unchanged():
    """S_N = 1 for every synapse, so a uniform site lesion cancels in the ratio."""
    for rate in (0.5, 2.0, 20.0, 100.0):
        for name in SYNAPSES:
            assert abs(elasticities_numeric(SYNAPSES[name], rate)["S_N"] - 1.0) < 1e-6


# ---------------------------------------------------------------------------
# Compensation geometry
# ---------------------------------------------------------------------------

def test_same_axis_compensation_erases_the_lesion_exactly():
    prm = SYNAPSES["E_cortical_L5"]
    target = steady_state_mean(prm, 20.0)
    les = prm.perturb(p0=0.8)
    cmp_ = compensate(les, target, actuator="p0", control_variable="mean_ss",
                      rate_ss=20.0)
    assert cmp_ is not None
    assert abs(np.log(cv2_first_pulse(cmp_) / cv2_first_pulse(prm))) < 1e-10
    assert abs(np.log(paired_pulse_ratio(cmp_, 0.05)
                      / paired_pulse_ratio(prm, 0.05))) < 1e-10


def test_capacity_lesions_lie_on_orthogonal_axes_under_quantal_compensation():
    prm = SYNAPSES["E_cortical_L5"]
    target = steady_state_mean(prm, 20.0)
    vecs = {}
    for par in ("N", "k_rep"):
        cmp_ = compensate(prm.perturb(**{par: 0.8}), target, actuator="q",
                          control_variable="mean_ss", rate_ss=20.0)
        assert cmp_ is not None
        vecs[par] = np.array([
            np.log(cv2_first_pulse(cmp_) / cv2_first_pulse(prm)),
            np.log(paired_pulse_ratio(cmp_, 0.05) / paired_pulse_ratio(prm, 0.05))])
    cos = (vecs["N"] @ vecs["k_rep"]
           / np.linalg.norm(vecs["N"]) / np.linalg.norm(vecs["k_rep"]))
    assert abs(cos) < 1e-9          # exactly 90 degrees apart


def test_presynaptic_drive_is_bounded_by_the_resupply_ceiling():
    for name, prm in SYNAPSES.items():
        for rate in (1.0, 20.0, 100.0):
            ceil = max_presynaptic_drive(prm, rate)
            for p in (0.3, 0.6, 0.9, 0.999):
                d = steady_state_mean(
                    SynapseParams(**{**prm.as_dict(), "p0": p}), rate)
                assert d <= ceil + 1e-12


def test_compensable_fraction_is_monotone_in_rate():
    for name, prm in SYNAPSES.items():
        vals = [compensable_fraction(prm, r) for r in (0.5, 1, 2, 5, 10, 20, 50, 100)]
        assert all(a >= b - 1e-12 for a, b in zip(vals, vals[1:]))


# ---------------------------------------------------------------------------
# Literature anchoring
# ---------------------------------------------------------------------------

def test_hill_fit_reproduces_both_anchor_points():
    h = CA3_CA1_HILL
    for ca, target in ((1.0, 0.08), (4.0, 0.79)):
        p = h["p_max"] * ca ** h["m"] / (h["kd"] ** h["m"] + ca ** h["m"])
        assert abs(p - target) < 1e-9


def test_calcium_prediction_is_consistent_with_the_independent_measurement():
    h = CA3_CA1_HILL
    p2 = h["p_max"] * 2.0 ** h["m"] / (h["kd"] ** h["m"] + 2.0 ** h["m"])
    assert abs(p2 - 0.43) / 0.28 < 1.0      # within one standard deviation


def test_inhibitory_paired_pulse_ratio_matches_its_calibration_target():
    assert abs(paired_pulse_ratio(SYNAPSES["I_basket"], 0.010) - 0.63) < 0.01


def test_mpfa_parabola_is_independent_of_release_probability():
    """Equation (9) contains N and q but not p."""
    from mpfa import parabola
    prm = SynapseParams(**{**SYNAPSES["E_cortical_L5"].as_dict(),
                           "N": 6.0, "q": 20.0})
    a = prm.q * (1 + prm.cv_q ** 2)
    mu = np.linspace(1, 100, 50)
    for scale in (0.5, 1.0, 1.7):
        prm2 = prm.perturb(p0=scale)
        a2 = prm2.q * (1 + prm2.cv_q ** 2)
        assert np.allclose(parabola(mu, a, prm.N), parabola(mu, a2, prm2.N))
