"""
build_manuscript.py
===================
Resolves citation keys in the manuscript into Vancouver-numbered references
in order of first appearance, and emits the final Markdown plus a reference
list. Fails loudly if any cited key is absent from the verified record set,
so an unverifiable citation can never reach the manuscript.

Usage:  python build_manuscript.py
"""

from __future__ import annotations

import json
import os
import re
import sys

MAN = os.environ.get("VESICLE_MS_DIR", "../manuscript")

JOURNAL_ABBREV = {
    "Genes, Brain and Behavior": "Genes Brain Behav",
    "European Journal of Neuroscience": "Eur J Neurosci",
    "Nature Neuroscience": "Nat Neurosci",
    "Trends in Cognitive Sciences": "Trends Cogn Sci",
    "Scientific Reports": "Sci Rep",
    "Translational Psychiatry": "Transl Psychiatry",
    "Journal of Neural Transmission": "J Neural Transm (Vienna)",
    "Nature Communications": "Nat Commun",
    "Frontiers in Computational Neuroscience": "Front Comput Neurosci",
    "The Journal of Physiology": "J Physiol",
    "The Journal of Neuroscience": "J Neurosci",
    "Journal of Neuroscience Methods": "J Neurosci Methods",
    "Trends in Neurosciences": "Trends Neurosci",
    "Current Biology": "Curr Biol",
    "Proceedings of the National Academy of Sciences": "Proc Natl Acad Sci U S A",
    "Nature Reviews Neuroscience": "Nat Rev Neurosci",
    "Biophysical Journal": "Biophys J",
    "Nature Genetics": "Nat Genet",
    "Molecular Autism": "Mol Autism",
    "Molecular Psychiatry": "Mol Psychiatry",
    "PLoS Computational Biology": "PLoS Comput Biol",
    "Annual Review of Physiology": "Annu Rev Physiol",
    "GENETICS": "Genetics",
    "Bioinformatics": "Bioinformatics",
    "Epilepsia": "Epilepsia",
    "Neuron": "Neuron",
    "Nature": "Nature",
    "Science": "Science",
    "Cell": "Cell",
}

# Corrections where Crossref metadata is incomplete; each value was confirmed
# against the PubMed record for the same DOI.
OVERRIDES = {
    "durst2022": {"page": "6126", "volume": "13",
                  "authors": ["Dürst CD", "Wiegert JS", "Schulze C", "Helassa N",
                              "Török K", "Oertner TG"]},
    "loebel2009": {"page": "27", "volume": "3",
                   "authors": ["Loebel A", "Silberberg G", "Helbig D",
                               "Markram H", "Tsodyks M", "Richardson MJ"]},
    "campagnola2022": {"page": "eabj5861", "volume": "375"},
    "gandal2018": {"page": "eaat8127", "volume": "362"},
    "avramiea2026": {"page": "16055", "volume": "16"},
    "luo2024": {"page": "325", "volume": "14"},
    "abrahams2013": {"page": "36", "volume": "4"},
    "goconsortium2023": {"page": "iyad031", "volume": "224",
                         "authors": ["The Gene Ontology Consortium"]},
    "arutiunian2026": {"page": "", "volume": ""},
    "bozzi2018": {"year": 2018},
    "specchio2022": {"year": 2022},
    "gutenkunst2007": {"page": "e189", "volume": "3"},
    "eggermann2011": {"year": 2012},
}


def fmt_authors(names: list[str]) -> str:
    if not names:
        return "[AUTHORS]"
    if len(names) <= 6:
        return ", ".join(names)
    return ", ".join(names[:6]) + ", et al"


def fmt_ref(rec: dict) -> str:
    journal = JOURNAL_ABBREV.get(rec["journal"], rec["journal"])
    vol = rec.get("volume") or ""
    page = rec.get("page") or ""
    loc = ""
    if vol and page:
        loc = f";{vol}:{page}"
    elif vol:
        loc = f";{vol}"
    title = rec["title"].rstrip(". ")
    return (f"{fmt_authors(rec['authors'])}. {title}. "
            f"{journal}. {rec['year']}{loc}. doi:{rec['doi']}")


def main() -> int:
    refs = json.load(open(f"{MAN}/refs_verified.json"))
    for k, patch in OVERRIDES.items():
        if k in refs:
            refs[k].update(patch)

    text = open(f"{MAN}/manuscript.md").read()
    # A citation key is a lowercase word ending in a four-digit year,
    # which cannot collide with LaTeX subscripts such as {rep} or {1}.
    pattern = re.compile(r"\{([a-z][a-z0-9_]*\d{4}(?:,[a-z][a-z0-9_]*\d{4})*)\}")

    order: list[str] = []
    missing: set[str] = set()

    def repl(m: re.Match) -> str:
        keys = m.group(1).split(",")
        nums = []
        for k in keys:
            if k == "REFERENCES":
                return m.group(0)
            if k not in refs:
                missing.add(k)
                nums.append("??")
                continue
            if k not in order:
                order.append(k)
            nums.append(str(order.index(k) + 1))
        # collapse consecutive runs, Vancouver style
        ints = [int(n) for n in nums if n != "??"]
        if len(ints) == len(nums) and len(ints) > 2 and ints == list(
                range(ints[0], ints[0] + len(ints))):
            return f"^{ints[0]}–{ints[-1]}^"
        return "^" + ",".join(nums) + "^"

    body = pattern.sub(repl, text)

    if missing:
        print("ERROR: cited keys absent from the verified reference set:",
              file=sys.stderr)
        for k in sorted(missing):
            print("  -", k, file=sys.stderr)
        return 1

    numbered = "\n".join(f"{i+1}. {fmt_ref(refs[k])}" for i, k in enumerate(order))
    body = body.replace("{REFERENCES}", numbered)

    out = f"{MAN}/manuscript_final.md"
    open(out, "w").write(body)

    unused = sorted(set(refs) - set(order))
    print(f"resolved {len(order)} citations into a numbered reference list")
    if unused:
        print(f"verified but not cited ({len(unused)}): {', '.join(unused)}")
    open(f"{MAN}/references_numbered.md", "w").write(numbered + "\n")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
