"""
figstyle.py
===========
Publication figure style. Single-column 89 mm and double-column 183 mm
widths, 7 pt sans-serif labels, thin recessive axes, no top or right spine.

The categorical palette is the Okabe-Ito colour-vision-deficiency-safe set,
ordered so that every adjacent pair clears a CVD separation of dE >= 8 in
deuteranopia and tritanopia simulation. Every series additionally carries a
distinct marker and, where more than one series appears, a direct label or a
legend, so identity is never carried by colour alone and the figures remain
readable in grayscale.

License: MIT (see LICENSE).
"""

from __future__ import annotations

import matplotlib as mpl
import matplotlib.pyplot as plt

# Okabe-Ito, validated order
PALETTE = ["#0072B2", "#D55E00", "#009E73", "#E69F00", "#CC79A7", "#56B4E9"]
INK = "#1a1a1a"
MUTED = "#6e6e6e"
GRID = "#d9d9d9"
SURFACE = "#ffffff"

MM = 1.0 / 25.4
W1 = 89 * MM          # single column
W15 = 120 * MM        # 1.5 column
W2 = 183 * MM         # double column

MARKERS = ["o", "s", "^", "D", "v", "P"]
LINESTYLES = ["-", "--", "-.", (0, (3, 1, 1, 1)), ":", (0, (5, 1))]


def apply_style() -> None:
    mpl.rcParams.update({
        "figure.dpi": 150,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02,
        "pdf.fonttype": 42,      # editable/embedded TrueType, not bitmaps
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
        "font.size": 7,
        "axes.labelsize": 7,
        "axes.titlesize": 7.5,
        "xtick.labelsize": 6.5,
        "ytick.labelsize": 6.5,
        "legend.fontsize": 6.2,
        "axes.linewidth": 0.6,
        "axes.edgecolor": INK,
        "axes.labelcolor": INK,
        "axes.titleweight": "bold",
        "axes.titlelocation": "left",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": False,
        "grid.color": GRID,
        "grid.linewidth": 0.4,
        "xtick.color": INK,
        "ytick.color": INK,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "xtick.major.size": 2.4,
        "ytick.major.size": 2.4,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "lines.linewidth": 1.1,
        "lines.markersize": 3.2,
        "lines.markeredgewidth": 0.5,
        "legend.frameon": False,
        "legend.handlelength": 1.8,
        "legend.labelspacing": 0.3,
        "text.color": INK,
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
    })


def panel_label(ax, letter: str, dx: float = -0.20, dy: float = 1.06) -> None:
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=8.5,
            fontweight="bold", va="top", ha="left", color=INK)


def soft_grid(ax, axis: str = "y") -> None:
    ax.grid(True, axis=axis, color=GRID, linewidth=0.4, zorder=0)
    ax.set_axisbelow(True)


def save(fig, stem: str, outdir: str = "../figs") -> list[str]:
    import os
    os.makedirs(outdir, exist_ok=True)
    paths = []
    for ext in ("pdf", "png"):
        p = os.path.join(outdir, f"{stem}.{ext}")
        fig.savefig(p)
        paths.append(p)
    plt.close(fig)
    return paths
