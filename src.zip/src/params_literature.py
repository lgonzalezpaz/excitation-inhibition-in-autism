"""
params_literature.py
====================
Presynaptic parameters taken from published measurements, with the source of
every value recorded alongside it. No value in this file is chosen freely;
values that could not be found in the primary literature are marked and are
either derived from measured quantities within this module or excluded from
the analyses that would depend on them.

Conventions
-----------
``k_rep`` is the reciprocal of a measured recovery time constant.
``p0`` is the per-site fusion probability for a single action potential at
the stated external Ca2+ concentration.

Provenance keys
---------------
measured  : the number appears in the cited work
derived   : computed in this module from measured numbers, with the
            derivation given
calibrated: fitted here to a measured summary statistic of the cited work,
            which is then no longer available as an independent test

License: MIT (see LICENSE).
"""

from __future__ import annotations

import numpy as np

from release_model import SynapseParams

__all__ = [
    "SOURCES", "CA_COOPERATIVITY", "fit_hill_two_points",
    "CA3_CA1_HILL", "SYNAPSES", "PARAM_PROVENANCE",
]

SOURCES = {
    "durst2022": "Dürst CD, Wiegert JS, Schulze C, Helassa N, Török K, Oertner TG. "
                 "Vesicular release probability sets the strength of individual Schaffer "
                 "collateral synapses. Nat Commun. 2022;13:6126. doi:10.1038/s41467-022-33565-6",
    "loebel2009": "Loebel A, Silberberg G, Helbig D, Markram H, Tsodyks M, Richardson MJE. "
                  "Multiquantal release underlies the distribution of synaptic efficacies in "
                  "the neocortex. Front Comput Neurosci. 2009;3:27. doi:10.3389/neuro.10.027.2009",
    "markram1997": "Markram H, Lübke J, Frotscher M, Roth A, Sakmann B. Physiology and anatomy "
                   "of synaptic connections between thick tufted pyramidal neurones in the "
                   "developing rat neocortex. J Physiol. 1997;500:409-440. "
                   "doi:10.1113/jphysiol.1997.sp022031",
    "kraushaar2000": "Kraushaar U, Jonas P. Efficacy and stability of quantal GABA release at a "
                     "hippocampal interneuron-principal neuron synapse. J Neurosci. "
                     "2000;20:5594-5607. doi:10.1523/JNEUROSCI.20-15-05594.2000",
    "hanse2001": "Hanse E, Gustafsson B. Vesicle release probability and pre-primed pool at "
                 "glutamatergic synapses in area CA1 of the rat neonatal hippocampus. "
                 "J Physiol. 2001;531:481-493. doi:10.1111/j.1469-7793.2001.0481i.x",
    "lou2005": "Lou X, Scheuss V, Schneggenburger R. Allosteric modulation of the presynaptic "
               "Ca2+ sensor for vesicle fusion. Nature. 2005;435:497-501. doi:10.1038/nature03568",
    "silver1998": "Silver RA, Momiyama A, Cull-Candy SG. Locus of frequency-dependent depression "
                  "identified with multiple-probability fluctuation analysis at rat climbing "
                  "fibre-Purkinje cell synapses. J Physiol. 1998;510:881-902. "
                  "doi:10.1111/j.1469-7793.1998.881bj.x",
    "dobrunz1997": "Dobrunz LE, Stevens CF. Heterogeneity of release probability, facilitation, "
                   "and depletion at central synapses. Neuron. 1997;18:995-1008. "
                   "doi:10.1016/S0896-6273(00)80338-4",
    "schikorski1997": "Schikorski T, Stevens CF. Quantitative ultrastructural analysis of "
                      "hippocampal excitatory synapses. J Neurosci. 1997;17:5858-5867. "
                      "doi:10.1523/JNEUROSCI.17-15-05858.1997",
    "delvendahl2019": "Delvendahl I, Kita K, Müller M. Rapid and sustained homeostatic control of "
                      "presynaptic exocytosis at a central synapse. Proc Natl Acad Sci U S A. "
                      "2019;116:23783-23789. doi:10.1073/pnas.1909675116",
    "muller2012": "Müller M, Davis GW. Transsynaptic control of presynaptic Ca2+ influx achieves "
                  "homeostatic potentiation of neurotransmitter release. Curr Biol. "
                  "2012;22:1102-1108. doi:10.1016/j.cub.2012.04.018",
    "bucurenciu2008": "Bucurenciu I, Kulik A, Schwaller B, Frotscher M, Jonas P. Nanodomain "
                      "coupling between Ca2+ channels and Ca2+ sensors promotes fast and "
                      "efficient transmitter release at a cortical GABAergic synapse. Neuron. "
                      "2008;57:536-545. doi:10.1016/j.neuron.2007.12.026",
    "campagnola2022": "Campagnola L, Seeman SC, Chartrand T, et al. Local connectivity and "
                      "synaptic dynamics in mouse and human neocortex. Science. "
                      "2022;375:eabj5861. doi:10.1126/science.abj5861",
    "clements2000": "Clements JD, Silver RA. Unveiling synaptic plasticity: a new graphical and "
                    "analytical approach. Trends Neurosci. 2000;23:105-113. "
                    "doi:10.1016/S0166-2236(99)01520-9",
    "silver2003": "Silver RA. Estimation of nonuniform quantal parameters with "
                  "multiple-probability fluctuation analysis: theory, application and limitations. "
                  "J Neurosci Methods. 2003;130:127-141. doi:10.1016/j.jneumeth.2003.09.030",
}

# Apparent intracellular Ca2+ cooperativity of vesicle fusion, calyx of Held,
# Ca2+ uncaging. The abstract of the cited work states a value of
# approximately 4 above 3 micromolar [Ca2+]i.
CA_COOPERATIVITY = {"value": 4.0, "source": "lou2005", "provenance": "measured",
                    "note": "stated as approximately 4 above 3 uM [Ca2+]i; "
                            "declines below 3 uM and falls under 1 at resting [Ca2+]i"}


def fit_hill_two_points(ca1: float, p1: float, ca2: float, p2: float,
                        m: float) -> dict:
    """Solve a Hill function for p_max and Kd from two measured points.

    With p(Ca) = p_max Ca^m / (Kd^m + Ca^m) and the cooperativity m fixed by
    independent measurement, two measured release probabilities determine
    p_max and Kd uniquely:

        Kd^m = p_max/p1 - 1 = (ca2/ca1)^m (p_max/p2 - 1) * ca1^m / ca1^m

    Rearranged in closed form below. Concentrations may be in any consistent
    units; Kd is returned in those units.
    """
    r = (ca2 / ca1) ** m
    # p_max/p1 - 1 = r * (p_max/p2 - 1)  (after scaling both sides by ca1^m)
    p_max = (r - 1.0) / (r / p2 - 1.0 / p1)
    kd_m = (p_max / p1 - 1.0) * ca1 ** m
    kd = kd_m ** (1.0 / m)
    return {"p_max": float(p_max), "kd": float(kd), "m": float(m)}


# Schaffer collateral Ca2+ titration: optical quantal analysis gave a median
# vesicular release probability of 0.08 at 1 mM external Ca2+ and 0.79 at
# 4 mM. Combining these with the independently measured cooperativity gives a
# Hill curve, and hence a prediction at the physiological concentration that
# can be checked against a separate study.
CA3_CA1_HILL = fit_hill_two_points(ca1=1.0, p1=0.08, ca2=4.0, p2=0.79,
                                   m=CA_COOPERATIVITY["value"])


def _p_at(ca: float, hill: dict) -> float:
    return float(hill["p_max"] * ca ** hill["m"] / (hill["kd"] ** hill["m"] + ca ** hill["m"]))


# ---------------------------------------------------------------------------
# Synapse classes used in the analyses
# ---------------------------------------------------------------------------
# Facilitation of the inhibitory synapse is calibrated to its measured
# paired-pulse depression (37 % at a 10 ms interval), because no independent
# measurement of a facilitation increment is available for that connection.
# The calibration is performed in validate_literature.py and the resulting
# value is recorded here for reproducibility.

SYNAPSES = {
    "E_cortical_L5": SynapseParams(
        N=5.5,          # anatomical contacts per connection, 5.5 +/- 1.1
        p0=0.46,        # utilisation parameter U = 0.46 +/- 0.1
        k_rep=1.0 / 0.525,   # from tau_rec = 525 +/- 134 ms
        q=1.0,
        cv_q=0.37,      # quantal CV measured by direct quantal resolution
        f=0.0,
        tau_f=0.100,
        label="Excitatory, neocortical L5 pyramidal to L5 pyramidal",
    ),
    "E_hippocampal_SC": SynapseParams(
        N=3.0,          # median number of release sites, IQR 2-4
        p0=_p_at(2.0, CA3_CA1_HILL),   # derived: Hill curve at 2 mM Ca2+
        k_rep=1.0 / 0.525,             # not measured at CA1; cortical value used
        q=1.0,
        cv_q=0.37,
        f=0.0,
        tau_f=0.100,
        label="Excitatory, hippocampal Schaffer collateral to CA1",
    ),
    "I_basket": SynapseParams(
        N=5.0,          # 3-7 release sites
        p0=0.50,        # about 0.5 per site at 2 mM Ca2+
        k_rep=1.0 / 2.0,     # from recovery tau = 2 s
        q=1.0,
        cv_q=0.37,
        f=0.283,        # calibrated to 37 % paired-pulse depression at 10 ms
        tau_f=0.100,
        label="Inhibitory, hippocampal basket cell to granule cell",
    ),
}

PARAM_PROVENANCE = {
    "E_cortical_L5": {
        "N": ("measured", "markram1997", "5.5 +/- 1.1 anatomical contacts per connection (n=19)"),
        "p0": ("measured", "loebel2009", "utilisation parameter U = 0.46 +/- 0.1 (n=20)"),
        "k_rep": ("derived", "loebel2009", "1/tau_rec with tau_rec = 525 +/- 134 ms"),
        "cv_q": ("measured", "silver1998", "quantal CV 0.37 +/- 0.01 by direct resolution"),
        "f": ("excluded", None, "no independent measurement; set to zero"),
    },
    "E_hippocampal_SC": {
        "N": ("measured", "durst2022", "median 3 release sites, IQR 2-4 (n=27 boutons)"),
        "p0": ("derived", "durst2022+lou2005",
               "Hill curve through p=0.08 at 1 mM and p=0.79 at 4 mM with m=4, "
               "evaluated at 2 mM"),
        "k_rep": ("substituted", "loebel2009",
                  "not measured at CA3-CA1; neocortical value used, flagged in the text"),
        "cv_q": ("measured", "silver1998", "quantal CV 0.37 +/- 0.01"),
        "f": ("excluded", None, "no independent measurement; set to zero"),
    },
    "I_basket": {
        "N": ("measured", "kraushaar2000", "3-7 release sites; midpoint used"),
        "p0": ("measured", "kraushaar2000", "about 0.5 per site at 2 mM Ca2+"),
        "k_rep": ("derived", "kraushaar2000", "1/tau with recovery tau = 2 s"),
        "cv_q": ("substituted", "silver1998", "no inhibitory quantal CV retrieved"),
        "f": ("calibrated", "kraushaar2000",
              "fitted to 37 % paired-pulse depression at a 10 ms interval"),
    },
}
