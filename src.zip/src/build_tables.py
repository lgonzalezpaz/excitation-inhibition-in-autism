"""
build_tables.py
===============
Generates every manuscript and supplementary table, and the figure captions,
directly from the saved result files, so that no number in the manuscript is
transcribed by hand.

Usage:  python build_tables.py
"""

from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd

RES = os.environ.get("VESICLE_RESULTS_DIR", "../results")
MAN = os.environ.get("VESICLE_MS_DIR", "../manuscript")
os.makedirs(MAN, exist_ok=True)

R = json.load(open(f"{RES}/results.json", encoding="utf-8"))
G = json.load(open(f"{RES}/genomics.json", encoding="utf-8"))

SYN_LABEL = {"E_cortical_L5": "Excitatory, neocortical L5 to L5",
             "E_hippocampal_SC": "Excitatory, Schaffer collateral to CA1",
             "I_basket": "Inhibitory, basket cell to granule cell"}
PAR_LABEL = {"N": "release sites N", "p0": "fusion probability p",
             "k_rep": "resupply rate k_rep (s^-1)",
             "cv_q": "quantal CV", "f": "facilitation increment f"}
SRC_SHORT = {
    "markram1997": "Markram et al. 1997", "loebel2009": "Loebel et al. 2009",
    "silver1998": "Silver et al. 1998", "durst2022": "Dürst et al. 2022",
    "kraushaar2000": "Kraushaar & Jonas 2000", "hanse2001": "Hanse & Gustafsson 2001",
    "lou2005": "Lou et al. 2005", "durst2022+lou2005": "Dürst et al. 2022; Lou et al. 2005",
}


def md_table(rows: list[list[str]], header: list[str]) -> str:
    out = ["| " + " | ".join(header) + " |",
           "|" + "|".join("---" for _ in header) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def table1() -> str:
    tp = pd.read_csv(f"{RES}/table_parameters.csv")
    rows = []
    for _, r in tp.iterrows():
        src = SRC_SHORT.get(str(r.source_key), str(r.source_key))
        if str(r.provenance) == "excluded":
            src = "not measured"
        val = f"{r.value:.3f}" if isinstance(r.value, float) else str(r.value)
        rows.append([SYN_LABEL.get(r.synapse, r.synapse),
                     PAR_LABEL.get(r.parameter, r.parameter), val,
                     str(r.provenance), src, str(r.note)])
    return md_table(rows, ["Synapse", "Parameter", "Value", "Status",
                           "Source", "Note"])


def table2() -> str:
    res = pd.read_csv(f"{RES}/table_residual_sectors.csv")
    res = res[res.synapse == "E_cortical_L5"]
    act = {"p0": "presynaptic (fusion probability)", "q": "postsynaptic (quantal size)"}
    rows = []
    for _, r in res.iterrows():
        if not r.ok:
            rows.append([r.lesion, act[r.actuator], "not reachable", "—", "—", "—"])
            continue
        norm = float(r.residual_norm)
        ang = "undefined" if norm < 1e-9 else f"{float(r.angle_deg):+.1f}"
        rows.append([r.lesion, act[r.actuator], f"{float(r.d_log_cv2):+.4f}",
                     f"{float(r.d_log_ppr):+.4f}", ang, f"{norm:.4f}"])
    return md_table(rows, ["Lesion (20% reduction)", "Compensating actuator",
                           "Δlog CV²", "Δlog PPR", "Direction (deg)",
                           "Residual norm"])


def table3() -> str:
    rows = []
    name = {"capacity": "Capacity axis", "actuator": "Actuator axis",
            "postsynaptic": "Postsynaptic (control)",
            "vesicle_endocytosis": "Vesicle endocytosis (control)"}
    oc = {"asd_sfari_12": "ASD risk gene (SFARI 1–2)",
          "asd_de": "Altered in ASD cortex",
          "asd_de_down": "Reduced in ASD cortex"}
    for o in oc:
        for p in name:
            lg = G["logistic"][f"{p}|{o}"]
            pm = G["permutation"].get(f"{p}|{o}")
            n = G["gene_sets"]["sizes_in_universe"][p]
            rows.append([oc[o], name[p], n,
                         f"{lg['or']:.2f} ({lg['ci95'][0]:.2f}–{lg['ci95'][1]:.2f})",
                         f"{lg['p']:.3g}",
                         f"{pm['enrichment']:.2f}" if pm else "—",
                         f"{pm['p_two_sided']:.4g}" if pm else "—"])
    return md_table(rows, ["Outcome", "Gene set", "n genes",
                           "Adjusted OR (95% CI)", "P", "Matched enrichment",
                           "P (permutation)"])


N_TRUE = {k: int(round(float(v)))
          for k, v in pd.read_csv(f"{RES}/table_parameters.csv")
          .query("parameter == 'N'").set_index("synapse").value.items()}


def table4() -> str:
    rows = []
    for k, v in R["design_extended"].items():
        ki = R.get("krep_information", {}).get(k, {})
        sd = pd.DataFrame(R["design"][k]["site_discrimination"]).set_index("n_alt")
        n_true = N_TRUE[k]
        def _t(alt):
            if alt in sd.index and np.isfinite(sd.loc[alt, "trials"]):
                return f"{sd.loc[alt, 'trials']:.0f}"
            return "—"
        one_site = f"{_t(n_true - 1)} / {_t(n_true + 1)}"
        rows.append([SYN_LABEL.get(k, k),
                     f"{1000*v['best_isi_for_krep_s']:.0f}",
                     f"{v['trials_20pct_p0']:.0f}", f"{v['trials_10pct_p0']:.0f}",
                     f"{v['trials_20pct_krep']:.0f}", f"{v['trials_10pct_krep']:.0f}",
                     f"{ki.get('trials_first_plus_ss_20pct_krep', float('nan')):.0f}",
                     one_site])
    return md_table(rows, ["Synapse", "Optimal interval for k_rep (ms)",
                           "Trials, p 20%", "Trials, p 10%",
                           "Trials, k_rep 20%", "Trials, k_rep 10%",
                           "Trials, k_rep 20% with steady state",
                           "Trials to resolve one fewer / one more site"])


def supp_s1() -> str:
    rows = []
    for axis, terms in G["gene_sets"]["go_terms_labels"].items():
        for t, lab in terms.items():
            rows.append([axis, t, lab])
    for axis, terms in G["gene_sets"]["control_terms"].items():
        for t, lab in terms.items():
            rows.append([f"{axis} (control)", t, lab])
    return md_table(rows, ["Axis", "GO identifier", "Term name"])


def supp_s2() -> str:
    mc = pd.read_csv(f"{RES}/table_monte_carlo_verification.csv")
    rows = []
    for syn, g in mc.groupby("synapse"):
        rows.append([syn, f"{g.rel_err_mean.max()*100:.3f}",
                     f"{g.rel_err_var.max()*100:.3f}", int(g.pulse.max())])
    return md_table(rows, ["Synapse", "Max relative error, mean (%)",
                           "Max relative error, variance (%)", "Pulses"])


def supp_s3() -> str:
    rows = [[f"{s['m']:.1f}", f"{s['p_max']:.4f}", f"{s['kd']:.3f}",
             f"{s['p_at_2mM']:.3f}",
             f"{(s['p_at_2mM']-0.43)/0.28:+.2f}"]
            for s in R["calcium"]["cooperativity_sensitivity"]]
    return md_table(rows, ["Assumed cooperativity m", "Fitted p_max",
                           "Fitted K_d (mM)", "Predicted p at 2 mM",
                           "Deviation from independent measurement (SD)"])


def supp_s4() -> str:
    rows = []
    for r in G["sensitivity_leave_one_term_out"]:
        rows.append([r["dropped_term"], r["label"][:60], r["n_genes"],
                     f"{r['or']:.2f} ({r['ci_lo']:.2f}–{r['ci_hi']:.2f})",
                     f"{r['p']:.3g}"])
    sn = G["sensitivity_nondisjoint"]
    out = ["**S4a. Leave-one-term-out, actuator axis against genes reduced in ASD cortex**", "",
           md_table(rows, ["Dropped term", "Term name", "n genes",
                           "Adjusted OR (95% CI)", "P"]), "",
           "**S4b. Non-disjoint gene sets (genes annotated to both axes retained in both)**", ""]
    rows2 = []
    for k, v in sn["logistic"].items():
        p, o = k.split("|")
        rows2.append([p, o, sn["sizes"][p], f"{v['or']:.2f}", f"{v['p']:.3g}"])
    out.append(md_table(rows2, ["Gene set", "Outcome", "n genes",
                                "Adjusted OR", "P"]))
    dd = G["double_dissociation"]["asd_sfari_12"]
    out += ["", "**S4c. Test of the predicted axis-by-outcome interaction (not supported)**", "",
            md_table([[f"{dd['log_or_genetic']:+.3f}",
                       f"{dd['log_or_transcriptional']:+.3f}",
                       f"{dd['delta']:+.3f}",
                       f"({dd['delta_ci95'][0]:+.3f}, {dd['delta_ci95'][1]:+.3f})",
                       f"{dd['p_one_sided_delta_gt_0']:.3g}"]],
                     ["log OR, genetic risk", "log OR, transcriptional",
                      "Δ", "95% CI (bootstrap)", "P"])]
    return "\n".join(out)


CAPTIONS = """
**Figure 1. The excitation–inhibition ratio has a rank-one sensitivity to presynaptic parameters.**
(**a**) The release model. A terminal carries *N* independent release sites supplied from a vesicle pool at rate *k*~rep~; each occupied site fuses with probability *p* on an action potential and produces a postsynaptic response of mean size *q*. The mean, the squared coefficient of variation and the failure probability of the response follow in closed form.
(**b**) Along the curve of parameter combinations that hold the mean fixed, the mean amplitude and therefore the excitation–inhibition ratio are constant by construction, while the squared coefficient of variation and the failure probability vary over more than an order of magnitude. Values are normalised to the literature-parameterised operating point (dotted line).
(**c**) Elasticity matrix of the five-component observable vector with respect to the four log-parameters, for the neocortical layer-5 connection. Entries are ∂(observable)/∂(log parameter). The first row alone has rank 1; the full matrix has rank 4.

**Figure 2. The model is exact and reproduces measurements it was not fitted to.**
(**a**, **b**) Mean quantal content and squared coefficient of variation through an eight-pulse 20 Hz train at three literature-parameterised synapses. Lines, exact recursions; open symbols, site-level Markov-chain simulation of 400,000 trials.
(**c**) Dependence of fusion probability on external calcium. Filled circles, the two measured Schaffer collateral release probabilities used as anchors; diamond, the value predicted at the physiological 2 mM with the cooperativity fixed at its independently measured value; open square with error bars, an independent measurement from a different laboratory and preparation (mean ± s.d., *n* = 43).
(**d**) A simulated multiple-probability fluctuation analysis with 60 trials at each of seven external calcium concentrations, fitted by weighted least squares.
(**e**) Recovery of the release-site number across 300 simulated experiments per condition. Symbols, median; bars, 95 per cent interval; dashed segments, the true value. A 30 per cent increase in fusion probability leaves the estimate numerically identical to wild type.
(**f**) Three quantities that entered no part of the parameterisation, compared with their published measurements.

**Figure 3. A mean-restoring controller leaves a residual, and presynaptic compensation saturates.**
(**a**) Schematic. A controller that restores the mean moves the system along the horizontal axis only, so any displacement along the orthogonal direction survives it.
(**b**) Residual trajectories in the plane of the two routine mean-invariant coordinates after exact restoration of the sustained drive by postsynaptic scaling, for lesions of increasing severity from 5 to 50 per cent. The three lesion axes lie on distinct rays.
(**c**) The same analysis with presynaptic compensation. The remaining axes collapse towards collinearity; a loss of release sites cannot be offset by this actuator at all (panels e, f).
(**d**) Direction of the residual for each lesion axis under postsynaptic compensation. A quantal-size lesion offset by quantal scaling leaves no residual and has no direction; it is omitted.
(**e**) The largest fractional loss of release sites that raising fusion probability can still offset, as a function of ongoing firing rate.
(**f**) Why the ceiling exists. Sustained drive approaches a bound that is proportional to the resupply rate and contains no fusion-probability term. Symbols mark the measured operating point of the excitatory layer-5 connection.

**Figure 4. A non-selective lesion produces an apparent imbalance.**
(**a**, **b**) Elasticity of sustained drive to fusion probability and to resupply rate across the physiological plane at 20 Hz, with the measured operating points of the excitatory and inhibitory reference synapses marked.
(**c**) Apparent change in the excitation–inhibition ratio produced by a 20 per cent reduction applied identically to both synapse classes, as a function of ongoing firing rate. A loss of release sites produces exactly no change at any rate.
(**d**) The same comparison at 20 Hz for two excitatory references. The sign of the shift identifies the lesioned parameter.

**Figure 5. In human cortex the actuator axis carries the transcriptional signature.**
(**a**) The two gene sets are matched on coding constraint and on gene length (two-sided Mann–Whitney).
(**b**) Enrichment of each gene set for three outcomes, by logistic regression adjusted for constraint, gene and transcript length and GC content. Points, odds ratio; bars, 95 per cent confidence interval. \\*P < 0.05, \\*\\*P < 0.01, \\*\\*\\*P < 0.001; n.s., not significant.
(**c**) Null distributions for the proportion of genes reduced in autistic cortex, built by resampling gene sets of matched size from the same joint deciles of constraint and gene length (20,000 permutations). Vertical lines, observed values.
(**d**) Direction of change among differentially expressed genes of each set, against the direction split of all differentially expressed genes (dashed line); exact binomial test.
(**e**) The same proportion resolved by individual annotation term. Symbol area is proportional to the number of genes.

**Figure 6. Measurement requirements for the decisive experiment.**
(**a**) Fisher information about the resupply rate carried by a paired-pulse protocol, as a function of inter-pulse interval, normalised to its maximum. Stars mark the optimum, which lies close to the reciprocal of the resupply rate.
(**b**) Trials per group needed to detect a given fractional difference with 80 per cent power at α = 0.05, at the allocation maximising the determinant of the information matrix.
(**c**) Trials needed to distinguish the true release-site number from a neighbouring integer at matched mean quantal content. The inset text reports maximum-likelihood recovery of the full parameter vector from a three-interval protocol.
"""


def main() -> None:
    parts = {
        "table1": table1(), "table2": table2(), "table3": table3(),
        "table4": table4(), "s1": supp_s1(), "s2": supp_s2(),
        "s3": supp_s3(), "s4": supp_s4(),
    }
    for k, v in parts.items():
        open(f"{MAN}/_{k}.md", "w", encoding="utf-8").write(v + "\n")
    open(f"{MAN}/_captions.md", "w", encoding="utf-8").write(CAPTIONS)
    print("wrote tables and captions to", MAN)


if __name__ == "__main__":
    main()
