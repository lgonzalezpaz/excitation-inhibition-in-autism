"""
release_model.py
================
Exact moment recursions and Monte-Carlo reference implementation for a
multi-site, depletion-and-facilitation model of stochastic vesicular release
at central synapses.

Model
-----
A synapse carries N independent release sites. Each site is either occupied
(a vesicle is docked and primed) or empty. On action potential k an occupied
site fuses with probability p_k. A site emptied by fusion is refilled as a
Poisson process with rate constant k_rep, so over an interval dt an empty
site is refilled with probability 1 - exp(-k_rep * dt).

Because sites are independent and statistically identical, the per-site
occupancy probability u_k obeys the exact scalar recursion. A site is
occupied immediately after pulse k with probability u_k * (1 - p_k); every
site that is empty after the pulse is refilled during dt_k with probability
1 - exp(-k_rep * dt_k). Writing b_k = exp(-k_rep * dt_k),

    u_{k+1} = (1 - b_k) + u_k * (1 - p_k) * b_k                         (M1)

whose fixed point for a regular train of interval dt (constant p, b) is

    u* = (1 - b) / (1 - (1 - p) * b)                                    (M1a)

and the number of quanta released on pulse k is exactly binomial

    R_k ~ Binomial(N, P_k),      P_k = u_k * p_k                        (M2)

Facilitation of the fusion probability by residual Ca2+ is implemented as a
multiplicative increment followed by exponential relaxation to baseline p0:

    p_{k+1} = p0 + (p_k + f * (1 - p_k) - p0) * exp(-dt_k / tau_f)      (M3)

With a quantal amplitude of mean q and coefficient of variation CVq, the
first two moments of the postsynaptic response amplitude A_k = sum of quanta
follow in closed form (law of total variance over R_k):

    mean(A_k)   = N * P_k * q                                           (M4)
    var(A_k)    = N * P_k * q^2 * (1 - P_k + CVq^2)                     (M5)
    CV^2(A_k)   = (1 - P_k + CVq^2) / (N * P_k)                         (M6)
    P_fail(k)   = (1 - P_k)^N                                           (M7)

Equations (M4)-(M5) imply the multiple-probability fluctuation analysis
(MPFA) parabola obtained by varying P at rest (u = 1):

    var = q * (1 + CVq^2) * mean - mean^2 / N                           (M8)

The baseline fusion probability depends on the presynaptic Ca2+ transient
with high apparent cooperativity m:

    p0([Ca]) = p_max * [Ca]^m / (Kd^m + [Ca]^m)                         (M9)

All recursions are O(number of pulses); no stochastic simulation is required
for any quantity used in the manuscript. The Monte-Carlo routine is provided
only to verify the analytic moments.

Author: see manuscript CRediT statement.
License: MIT (see LICENSE).
"""

from __future__ import annotations

from dataclasses import dataclass, replace, asdict
from typing import Sequence

import numpy as np

__all__ = [
    "SynapseParams",
    "p0_from_calcium",
    "simulate_moments",
    "steady_state_occupancy",
    "steady_state_mean",
    "paired_pulse_ratio",
    "cv2_first_pulse",
    "failure_probability",
    "mpfa_parabola",
    "monte_carlo_train",
    "observable_vector",
    "OBSERVABLE_NAMES",
]


# ----------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class SynapseParams:
    """Presynaptic parameter vector for one synapse class.

    Attributes
    ----------
    N : float
        Number of independent release sites (docking/priming slots) per
        connection. Treated as a continuous parameter for sensitivity
        analysis; rounded only inside the Monte-Carlo routine.
    p0 : float
        Baseline per-site fusion probability for a single action potential at
        the physiological external Ca2+ concentration.
    k_rep : float
        Vesicle replenishment (site-refilling) rate constant, s^-1.
    q : float
        Mean quantal amplitude (arbitrary units, e.g. pA).
    cv_q : float
        Coefficient of variation of the quantal amplitude.
    f : float
        Facilitation increment per action potential, dimensionless, in [0, 1).
    tau_f : float
        Facilitation decay time constant, s.
    u0 : float
        Per-site occupancy probability before the first pulse (1.0 for a
        fully recovered synapse at rest).
    label : str
        Human-readable name of the synapse class.
    """

    N: float
    p0: float
    k_rep: float
    q: float = 1.0
    cv_q: float = 0.30
    f: float = 0.0
    tau_f: float = 0.100
    u0: float = 1.0
    label: str = ""

    def perturb(self, **rel_changes: float) -> "SynapseParams":
        """Return a copy with multiplicative changes, e.g. perturb(N=0.8)."""
        updates = {}
        for key, factor in rel_changes.items():
            if not hasattr(self, key):
                raise KeyError(f"unknown parameter {key!r}")
            updates[key] = float(getattr(self, key)) * float(factor)
        return replace(self, **updates)

    def as_dict(self) -> dict:
        return asdict(self)


# ----------------------------------------------------------------------------
# Calcium dependence
# ----------------------------------------------------------------------------

def p0_from_calcium(ca: np.ndarray | float,
                    p_max: float,
                    kd: float,
                    m: float) -> np.ndarray | float:
    """Hill-type dependence of fusion probability on Ca2+ (equation M9)."""
    ca = np.asarray(ca, dtype=float)
    return p_max * ca ** m / (kd ** m + ca ** m)


# ----------------------------------------------------------------------------
# Exact moment recursions
# ----------------------------------------------------------------------------

def simulate_moments(prm: SynapseParams,
                     intervals: Sequence[float]) -> dict:
    """Propagate the exact moments through a stimulus train.

    Parameters
    ----------
    prm : SynapseParams
    intervals : sequence of float
        Inter-stimulus intervals (s). ``len(intervals)`` pulses follow the
        first pulse, so the train contains ``len(intervals) + 1`` pulses.

    Returns
    -------
    dict with keys 'u', 'p', 'P', 'mean', 'var', 'cv2', 'p_fail', each an
    array of length ``len(intervals) + 1``.
    """
    n_pulses = len(intervals) + 1
    u = np.empty(n_pulses)
    p = np.empty(n_pulses)

    u[0] = prm.u0
    p[0] = prm.p0

    for k, dt in enumerate(intervals):
        # occupancy: equation (M1)
        b = np.exp(-prm.k_rep * dt)
        u[k + 1] = (1.0 - b) + u[k] * (1.0 - p[k]) * b
        # facilitation: equation (M3)
        p_after = p[k] + prm.f * (1.0 - p[k])
        p[k + 1] = prm.p0 + (p_after - prm.p0) * np.exp(-dt / prm.tau_f)

    P = u * p
    mean = prm.N * P * prm.q
    var = prm.N * P * prm.q ** 2 * (1.0 - P + prm.cv_q ** 2)
    with np.errstate(divide="ignore", invalid="ignore"):
        cv2 = (1.0 - P + prm.cv_q ** 2) / (prm.N * P)
    p_fail = (1.0 - P) ** prm.N

    return {"u": u, "p": p, "P": P, "mean": mean, "var": var,
            "cv2": cv2, "p_fail": p_fail}


def steady_state_occupancy(prm: SynapseParams, rate_hz: float) -> float:
    """Joint fixed point of (M1) and (M3) for a regular train of given rate.

    Solved by direct iteration, which converges geometrically with ratio
    max(exp(-dt/tau_f), (1 - p) exp(-k_rep dt)) < 1. For f = 0 the occupancy
    fixed point reduces to the closed form (M1a).
    """
    dt = 1.0 / float(rate_hz)
    decay_f = np.exp(-dt / prm.tau_f)
    b = np.exp(-prm.k_rep * dt)

    p = prm.p0
    u = prm.u0
    for _ in range(20000):
        p_new = prm.p0 + (p + prm.f * (1.0 - p) - prm.p0) * decay_f
        u_new = (1.0 - b) + u * (1.0 - p_new) * b
        if abs(p_new - p) < 1e-15 and abs(u_new - u) < 1e-15:
            p, u = p_new, u_new
            break
        p, u = p_new, u_new
    return float(u), float(p)


def steady_state_mean(prm: SynapseParams, rate_hz: float) -> float:
    """Steady-state mean response amplitude during a regular train."""
    u, p = steady_state_occupancy(prm, rate_hz)
    return prm.N * u * p * prm.q


def paired_pulse_ratio(prm: SynapseParams, isi: float) -> float:
    """PPR = mean(A_2) / mean(A_1) for a single interval ``isi`` (s)."""
    mom = simulate_moments(prm, [isi])
    return float(mom["mean"][1] / mom["mean"][0])


def cv2_first_pulse(prm: SynapseParams) -> float:
    """CV^2 of the first response of a train (equation M6 at k = 1)."""
    P = prm.u0 * prm.p0
    return float((1.0 - P + prm.cv_q ** 2) / (prm.N * P))


def failure_probability(prm: SynapseParams) -> float:
    """Probability that the first stimulus evokes no quantum (equation M7)."""
    P = prm.u0 * prm.p0
    return float((1.0 - P) ** prm.N)


def mpfa_parabola(prm: SynapseParams,
                  ca_values: np.ndarray,
                  p_max: float,
                  kd: float,
                  m: float) -> tuple[np.ndarray, np.ndarray]:
    """Variance-mean pairs generated by varying external Ca2+ (equation M8)."""
    p_vals = np.asarray(p0_from_calcium(ca_values, p_max, kd, m), dtype=float)
    P = prm.u0 * p_vals
    mean = prm.N * P * prm.q
    var = prm.N * P * prm.q ** 2 * (1.0 - P + prm.cv_q ** 2)
    return mean, var


# ----------------------------------------------------------------------------
# Observable vector used for the identifiability / null-space geometry
# ----------------------------------------------------------------------------

OBSERVABLE_NAMES = (
    "log_mean_1",      # log mean amplitude of the first response
    "log_cv2_1",       # log CV^2 of the first response
    "log_ppr",         # log paired-pulse ratio at a reference interval
    "log_mean_ss",     # log steady-state mean during a reference train
    "logit_pfail",     # logit of the first-pulse failure probability
)


def observable_vector(prm: SynapseParams,
                      isi_ppr: float = 0.050,
                      rate_ss: float = 20.0) -> np.ndarray:
    """Map a parameter vector to the log-scaled observable vector Phi(theta).

    Log and logit scaling makes the Jacobian an elasticity matrix, so that
    the null-space geometry is invariant to the physical units of each
    observable.
    """
    mom = simulate_moments(prm, [isi_ppr])
    mean1 = mom["mean"][0]
    cv2_1 = mom["cv2"][0]
    ppr = mom["mean"][1] / mom["mean"][0]
    mean_ss = steady_state_mean(prm, rate_ss)
    pf = np.clip(mom["p_fail"][0], 1e-12, 1 - 1e-12)
    return np.array([
        np.log(mean1),
        np.log(cv2_1),
        np.log(ppr),
        np.log(mean_ss),
        np.log(pf / (1.0 - pf)),
    ], dtype=float)


# ----------------------------------------------------------------------------
# Monte-Carlo reference implementation (verification only)
# ----------------------------------------------------------------------------

def monte_carlo_train(prm: SynapseParams,
                      intervals: Sequence[float],
                      n_trials: int = 200_000,
                      seed: int = 0) -> dict:
    """Simulate the site-level Markov chain and return empirical moments.

    Used solely to verify equations (M1)-(M7). Vectorised over trials.
    """
    rng = np.random.default_rng(seed)
    n_sites = int(round(prm.N))
    n_pulses = len(intervals) + 1

    occupied = np.ones((n_trials, n_sites), dtype=bool)
    p = prm.p0
    amps = np.empty((n_trials, n_pulses))
    counts = np.empty((n_trials, n_pulses), dtype=np.int32)

    for k in range(n_pulses):
        fuse = occupied & (rng.random((n_trials, n_sites)) < p)
        r = fuse.sum(axis=1)
        counts[:, k] = r
        # quantal variability: gamma with mean q and CV cv_q
        if prm.cv_q > 0:
            shape = 1.0 / prm.cv_q ** 2
            scale = prm.q / shape
            tot = np.zeros(n_trials)
            nz = r > 0
            if nz.any():
                tot[nz] = rng.gamma(shape * r[nz], scale)
            amps[:, k] = tot
        else:
            amps[:, k] = r * prm.q

        occupied = occupied & ~fuse
        if k < len(intervals):
            dt = intervals[k]
            refill_p = 1.0 - np.exp(-prm.k_rep * dt)
            empty = ~occupied
            refill = empty & (rng.random((n_trials, n_sites)) < refill_p)
            occupied = occupied | refill
            p = prm.p0 + (p + prm.f * (1.0 - p) - prm.p0) * np.exp(-dt / prm.tau_f)

    mean = amps.mean(axis=0)
    var = amps.var(axis=0, ddof=1)
    return {
        "mean": mean,
        "var": var,
        "cv2": var / mean ** 2,
        "p_fail": (counts == 0).mean(axis=0),
        "mean_counts": counts.mean(axis=0),
        "var_counts": counts.var(axis=0, ddof=1),
    }
