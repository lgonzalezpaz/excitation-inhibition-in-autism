"""
make_figures.py
===============
Builds every figure of the manuscript from the saved result files. Outputs
vector PDF and 600 dpi PNG for each figure into ``figs/``.

Usage:  python make_figures.py     (after make_results.py and make_genomics.py)
"""

from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.patches import FancyArrowPatch, Circle, Rectangle, FancyBboxPatch
from matplotlib.lines import Line2D

from figstyle import (apply_style, PALETTE, INK, MUTED, GRID, W2,
                      MARKERS, LINESTYLES, panel_label, soft_grid, save)
from release_model import (SynapseParams, cv2_first_pulse, steady_state_mean)
from params_literature import SYNAPSES
from mpfa import parabola

apply_style()

RES = os.environ.get("VESICLE_RESULTS_DIR", "../results")
FIGS = os.environ.get("VESICLE_FIGS_DIR", "../figs")
os.makedirs(FIGS, exist_ok=True)

R = json.load(open(f"{RES}/results.json"))
G = json.load(open(f"{RES}/genomics.json"))

LES_COL = {"release sites (N)": PALETTE[0],
           "replenishment (k_rep)": PALETTE[1],
           "fusion probability (p)": PALETTE[2],
           "quantal size (q)": PALETTE[3]}
LES_LAB = {"release sites (N)": r"sites $N$",
           "replenishment (k_rep)": r"resupply $k_{rep}$",
           "fusion probability (p)": r"fusion prob. $p$",
           "quantal size (q)": r"quantal size $q$"}
LES_IDX = {k: i for i, k in enumerate(LES_COL)}
SYN_NAMES = ["E_cortical_L5", "E_hippocampal_SC", "I_basket"]
SYN_SHORT = ["excitatory L5", "excitatory Schaffer", "inhibitory basket"]

NOTE = dict(fontsize=5.6, color=MUTED,
            bbox=dict(fc="white", ec="none", alpha=0.82, pad=1.2))


def logx(ax, vals):
    ax.set_xscale("log")
    ax.xaxis.set_major_locator(mticker.FixedLocator(vals))
    ax.xaxis.set_major_formatter(mticker.FixedFormatter([f"{v:g}" for v in vals]))
    ax.xaxis.set_minor_locator(mticker.NullLocator())


# ===========================================================================
def figure1() -> None:
    fig = plt.figure(figsize=(W2, 0.46 * W2))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.18, 0.95, 1.05], wspace=0.50)

    ax = fig.add_subplot(gs[0]); panel_label(ax, "a", dx=-0.07)
    ax.set_xlim(0, 10); ax.set_ylim(0, 11.2); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0.3, 5.3), 9.4, 5.6, boxstyle="round,pad=0.12",
                                fc="#f2f5f7", ec=MUTED, lw=0.5))
    ax.text(0.55, 10.62, "presynaptic terminal", fontsize=6.2, color=MUTED)
    for (x, y) in [(1.3, 9.3), (2.1, 9.7), (2.95, 9.3), (1.72, 8.6),
                   (2.6, 8.65), (3.5, 9.7)]:
        ax.add_patch(Circle((x, y), 0.30, fc="#ffffff", ec=MUTED, lw=0.5))
    ax.text(2.35, 7.95, "vesicle pool", fontsize=6.0, ha="center", color=MUTED)
    for j, x in enumerate([5.3, 6.4, 7.5, 8.6]):
        ax.plot([x - 0.42, x + 0.42], [6.35, 6.35], color=INK, lw=1.5,
                solid_capstyle="butt")
        if j < 3:
            ax.add_patch(Circle((x, 6.85), 0.33, fc=PALETTE[0], ec=INK, lw=0.5,
                                alpha=0.85))
    ax.annotate("", xy=(5.05, 9.1), xytext=(4.0, 9.1),
                arrowprops=dict(arrowstyle="-|>", lw=1.0, color=PALETTE[1]))
    ax.text(4.5, 9.38, r"$k_{rep}$", fontsize=7.5, color=PALETTE[1], ha="center")
    ax.text(6.95, 7.72, r"$N$ release sites", fontsize=6.6, ha="center")
    ax.annotate("", xy=(6.4, 5.05), xytext=(6.4, 6.18),
                arrowprops=dict(arrowstyle="-|>", lw=1.0, color=PALETTE[2]))
    ax.text(6.66, 5.40, r"$p$", fontsize=7.5, color=PALETTE[2])
    ax.add_patch(FancyBboxPatch((4.6, 3.85), 5.1, 1.05, boxstyle="round,pad=0.10",
                                fc="#f7f3f5", ec=MUTED, lw=0.5))
    ax.text(7.15, 4.30, "postsynaptic density", fontsize=6.2, ha="center", color=MUTED)
    ax.text(9.62, 4.92, r"$q$", fontsize=7.5, color=PALETTE[4], ha="right")
    ax.plot([0.3, 9.7], [3.10, 3.10], color=GRID, lw=0.6)
    ax.text(0.3, 2.62, r"$\mu = N\,p\,q$", fontsize=7.2)
    ax.text(0.3, 1.80, r"$P_{fail}=(1-p)^N$", fontsize=7.2)
    ax.text(0.3, 0.55, r"$CV^2=\dfrac{1-p+CV_q^2}{N\,p}$", fontsize=7.2)
    ax.set_title("Four presynaptic parameters", pad=2)

    ax = fig.add_subplot(gs[1]); panel_label(ax, "b")
    prm = SYNAPSES["E_cortical_L5"]
    mu0 = prm.N * prm.p0 * prm.q
    n_vals = np.linspace(2.4, 16.0, 200)
    p_vals = mu0 / (n_vals * prm.q)
    ok = p_vals < 0.97
    n_vals, p_vals = n_vals[ok], p_vals[ok]
    ref = int(np.argmin(abs(n_vals - prm.N)))
    cv2 = np.array([cv2_first_pulse(SynapseParams(**{**prm.as_dict(), "N": n, "p0": p}))
                    for n, p in zip(n_vals, p_vals)])
    pfl = (1 - p_vals) ** n_vals
    ax.plot(n_vals, cv2 / cv2[ref], color=PALETTE[0], lw=1.4, label=r"$CV^2$")
    ax.plot(n_vals, pfl / pfl[ref], color=PALETTE[1], lw=1.4, ls="--",
            label=r"$P_{fail}$")
    ax.axhline(1.0, color=PALETTE[2], lw=1.4, ls="-.", label=r"$\mu$, E/I ratio")
    ax.axvline(prm.N, color=MUTED, lw=0.5, ls=":")
    ax.set_yscale("log")
    ax.set_xlabel(r"release sites $N$")
    ax.set_ylabel("value relative to reference")
    ax.legend(loc="lower left", fontsize=6.0)
    ax.text(0.97, 0.30, r"$p$ adjusted to" "\n" r"hold $\mu$ fixed",
            transform=ax.transAxes, ha="right", va="top", **NOTE)
    soft_grid(ax)
    ax.set_title("The mean is blind", pad=2)

    ax = fig.add_subplot(gs[2]); panel_label(ax, "c", dx=-0.34)
    J = np.array(R["identifiability"]["E_cortical_L5"]["jacobian_full"])
    obs = [r"$\log\mu_1$", r"$\log CV^2_1$", r"$\log$PPR",
           r"$\log\mu_{ss}$", r"logit $P_{fail}$"]
    par = [r"$\log N$", r"$\log p$", r"$\log k_{rep}$", r"$\log q$"]
    vmax = np.nanmax(np.abs(J))
    im = ax.imshow(J, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
    ax.set_xticks(range(len(par)), par)
    ax.set_yticks(range(len(obs)), obs)
    ax.tick_params(length=0)
    for i in range(J.shape[0]):
        for j in range(J.shape[1]):
            v = J[i, j]
            ax.text(j, i, f"{v:+.2f}", ha="center", va="center", fontsize=5.6,
                    color="white" if abs(v) > 0.55 * vmax else INK)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label("elasticity", fontsize=6.0)
    cb.ax.tick_params(labelsize=5.6, length=1.6)
    cb.outline.set_linewidth(0.4)
    rk = R["identifiability"]["E_cortical_L5"]
    ax.set_title("Release statistics restore rank", pad=2)
    ax.text(0.0, -0.26, f"mean alone: rank {rk['rank_mean_only']}, null space "
                        f"dimension {rk['null_dim_mean_only']}\n"
                        f"full vector: rank {rk['rank_full']} of 4, condition "
                        f"number {rk['cond_full']:.0f}",
            transform=ax.transAxes, fontsize=6.0, color=INK, va="top")
    print(" ", save(fig, "figure1_framework_identifiability", FIGS))


# ===========================================================================
def figure2() -> None:
    fig = plt.figure(figsize=(W2, 0.70 * W2))
    gs = fig.add_gridspec(2, 3, wspace=0.46, hspace=0.52)
    mc = pd.read_csv(f"{RES}/table_monte_carlo_verification.csv")
    order = {"Excitatory, neocortical L5 pyramidal to L5 pyramidal": 0,
             "Excitatory, hippocampal Schaffer collateral to CA1": 1,
             "Inhibitory, hippocampal basket cell to granule cell": 2}

    def _mc_panel(ax, acol, mcol, ylab):
        for lab, g in mc.groupby("synapse"):
            i = order[lab]
            ax.plot(g.pulse, g[acol], color=PALETTE[i], lw=1.1, ls=LINESTYLES[i],
                    zorder=2, label=SYN_SHORT[i])
            ax.plot(g.pulse, g[mcol], lw=0, marker=MARKERS[i], mfc="white",
                    mec=PALETTE[i], mew=0.7, ms=3.4, zorder=3)
        ax.set_xlabel("pulse number (50 ms intervals)")
        ax.set_ylabel(ylab)
        soft_grid(ax)

    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, "a")
    _mc_panel(ax, "mean_analytic", "mean_mc", r"mean quantal content $\mu_k/q$")
    ax.legend(fontsize=5.8, loc="upper right")
    ax.text(0.52, 0.50, "lines: exact recursions\nopen symbols: Monte Carlo\n"
                        f"max error {R['monte_carlo']['max_rel_err_mean']*100:.2f}%",
            transform=ax.transAxes, ha="center", va="top", **NOTE)
    ax.set_title("Exact moment recursions", pad=2)

    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, "b")
    _mc_panel(ax, "cv2_analytic", "cv2_mc", r"$CV^2$ of response amplitude")
    ax.text(0.03, 0.96, f"max error {mc.rel_err_var.max()*100:.2f}% on the variance",
            transform=ax.transAxes, va="top", **NOTE)
    ax.set_title("Second moments agree", pad=2)

    ax = fig.add_subplot(gs[0, 2]); panel_label(ax, "c")
    cv = pd.read_csv(f"{RES}/curve_calcium_hill.csv")
    ax.plot(cv.ca_mM, cv.p, color=PALETTE[0], lw=1.4, zorder=2)
    anc = R["calcium"]["anchor_points"]
    ax.plot([a["ca_mM"] for a in anc], [a["p"] for a in anc], "o", ms=4.8,
            mfc=PALETTE[0], mec=INK, mew=0.6, zorder=5, label="anchors (measured)")
    ax.plot([1.86], [R["calcium"]["prediction_at_2mM"]], marker="D", ms=4.8,
            mfc=PALETTE[1], mec=INK, mew=0.6, zorder=6, label="prediction, 2 mM")
    ax.errorbar([2.3], [0.43], yerr=[[0.28], [0.28]], fmt="s", ms=4.0,
                color=PALETTE[2], mfc="white", mec=PALETTE[2], mew=0.9,
                elinewidth=0.9, capsize=2.2, zorder=4, label="independent study")
    logx(ax, [0.5, 1, 2, 4, 8])
    ax.set_xlabel(r"external $[\mathrm{Ca}^{2+}]$ (mM)")
    ax.set_ylabel(r"fusion probability per site $p$")
    ax.legend(fontsize=5.6, loc="upper left")
    ax.text(0.97, 0.05, f"deviation {abs(R['calcium']['deviation_sd']):.2f} SD",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=6.2)
    soft_grid(ax)
    ax.set_title("Cooperativity fixed at 4", pad=2)

    ax = fig.add_subplot(gs[1, 0]); panel_label(ax, "d")
    ex = pd.read_csv(f"{RES}/example_mpfa_dataset.csv")
    mgrid = np.linspace(0, ex["mean"].max() * 1.10, 200)
    fp = R["mpfa"]["example_fit"]
    ax.plot(mgrid, parabola(mgrid, fp["A"], fp["N"]), color=PALETTE[0], lw=1.4,
            zorder=2)
    ax.plot(ex["mean"], ex["var"], "o", ms=4.2, mfc="white", mec=PALETTE[0],
            mew=0.9, zorder=3)
    ax.set_xlabel("mean amplitude (a.u.)")
    ax.set_ylabel(r"variance (a.u.$^2$)")
    ax.text(0.03, 0.96, rf"$\hat N$ = {fp['N']:.2f} (true 6.00)" "\n"
                        rf"$R^2$ = {fp['r2']:.3f}" "\n60 trials per level",
            transform=ax.transAxes, fontsize=6.0, va="top",
            bbox=dict(fc="white", ec="none", alpha=0.8, pad=1.2))
    soft_grid(ax)
    ax.set_title("Variance-mean parabola", pad=2)

    ax = fig.add_subplot(gs[1, 1]); panel_label(ax, "e")
    rec = R["mpfa"]["recovery"]
    labs = list(rec.keys())
    short = ["wild\ntype", "sites\n$-$20%", "quantal\n$-$20%", "fusion $p$\n$+$30%"]
    xs = np.arange(len(labs))
    med = [rec[l]["N_median"] for l in labs]
    lo = [med[i] - rec[l]["N_ci"][0] for i, l in enumerate(labs)]
    hi = [rec[l]["N_ci"][1] - med[i] for i, l in enumerate(labs)]
    cols = [PALETTE[5], PALETTE[0], PALETTE[3], PALETTE[2]]
    ax.errorbar(xs, med, yerr=[lo, hi], fmt="none", ecolor=MUTED, elinewidth=0.8,
                capsize=2.2, zorder=2)
    for x, m, c, mk in zip(xs, med, cols, MARKERS):
        ax.plot([x], [m], marker=mk, ms=5.0, mfc=c, mec=INK, mew=0.6, zorder=3)
    for i, l in enumerate(labs):
        ax.plot([i - 0.28, i + 0.28], [rec[l]["N_true"]] * 2, color=INK, lw=1.0,
                ls="--", zorder=1)
    ax.set_xticks(xs, short, fontsize=5.8)
    ax.set_xlim(-0.6, len(labs) - 0.4)
    ax.set_ylabel(r"estimated release sites $\hat N$")
    ax.text(0.5, 0.03, "dashed: true value\n"
                       r"a change in $p$ leaves $\hat N$ unmoved",
            transform=ax.transAxes, ha="center", va="bottom", **NOTE)
    soft_grid(ax)
    ax.set_title("Blind to the actuator", pad=2)

    ax = fig.add_subplot(gs[1, 2]); panel_label(ax, "f")
    lc = pd.read_csv(f"{RES}/table_literature_checks.csv")
    lc = lc[lc["independent"] == True].reset_index(drop=True)
    names = ["amplitude CV\n(L5 to L5)", "failure rate\n(L5 to L5)",
             "sites implied by\nfailure rate"]
    ys = np.arange(len(lc))[::-1]
    for y, pr, me in zip(ys, lc.predicted, lc.measured):
        ax.plot([pr, me], [y, y], color=MUTED, lw=0.8, zorder=1)
        ax.plot([pr], [y], marker="o", ms=5.0, mfc=PALETTE[0], mec=INK, mew=0.6,
                zorder=3)
        ax.plot([me], [y], marker="s", ms=5.0, mfc="white", mec=PALETTE[1],
                mew=1.0, zorder=3)
    ax.set_yticks(ys, names, fontsize=6.0)
    ax.set_xscale("log")
    ax.set_xlim(0.02, 14)
    ax.xaxis.set_major_locator(mticker.FixedLocator([0.03, 0.1, 0.3, 1, 3, 10]))
    ax.xaxis.set_major_formatter(mticker.FixedFormatter(
        ["0.03", "0.1", "0.3", "1", "3", "10"]))
    ax.xaxis.set_minor_locator(mticker.NullLocator())
    ax.set_xlabel("value (log scale)")
    ax.set_ylim(-0.7, len(lc) - 0.3)
    ax.legend(handles=[Line2D([], [], marker="o", lw=0, mfc=PALETTE[0], mec=INK,
                              mew=0.6, ms=4.4, label="model prediction"),
                       Line2D([], [], marker="s", lw=0, mfc="white", mec=PALETTE[1],
                              mew=1.0, ms=4.4, label="published measurement")],
              fontsize=5.6, loc="lower right")
    soft_grid(ax, axis="x")
    ax.set_title("Out-of-sample predictions", pad=2)

    print(" ", save(fig, "figure2_validation", FIGS))


# ===========================================================================
def figure3() -> None:
    fig = plt.figure(figsize=(W2, 0.72 * W2))
    gs = fig.add_gridspec(2, 3, wspace=0.52, hspace=0.46)
    res = pd.read_csv(f"{RES}/table_residual_sectors.csv")
    res = res[(res.synapse == "E_cortical_L5") & (res.ok == True)]
    sw = R["residual_sweeps"]

    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, "a", dx=-0.09)
    ax.set_xlim(-1.15, 1.15); ax.set_ylim(-1.25, 1.0); ax.axis("off")
    ax.annotate("", xy=(1.05, -0.25), xytext=(-1.05, -0.25),
                arrowprops=dict(arrowstyle="-|>", lw=0.6, color=MUTED))
    ax.annotate("", xy=(-0.05, 0.92), xytext=(-0.05, -0.85),
                arrowprops=dict(arrowstyle="-|>", lw=0.6, color=MUTED))
    ax.text(1.06, -0.18, "mean drive", fontsize=6.0, color=MUTED, ha="right")
    ax.text(0.00, 0.96, "release statistics", fontsize=6.0, color=MUTED)
    ax.plot([-0.05], [-0.25], "o", ms=5.5, mfc=PALETTE[5], mec=INK, mew=0.6, zorder=4)
    ax.text(-0.02, -0.46, "wild type", fontsize=6.2, ha="center")
    ax.plot([-0.72], [0.38], "o", ms=5.5, mfc=PALETTE[0], mec=INK, mew=0.6, zorder=4)
    ax.text(-0.74, 0.50, "after lesion", fontsize=6.2, ha="center")
    ax.plot([-0.05], [0.38], "o", ms=5.5, mfc=PALETTE[1], mec=INK, mew=0.6, zorder=4)
    ax.text(0.03, 0.50, "after compensation", fontsize=6.2)
    ax.add_patch(FancyArrowPatch((-0.05, -0.25), (-0.72, 0.38), arrowstyle="-|>",
                                 mutation_scale=7, lw=1.0, color=PALETTE[0],
                                 shrinkA=4, shrinkB=4))
    ax.add_patch(FancyArrowPatch((-0.72, 0.38), (-0.05, 0.38), arrowstyle="-|>",
                                 mutation_scale=7, lw=1.0, color=PALETTE[1],
                                 shrinkA=4, shrinkB=4))
    ax.annotate("", xy=(0.42, 0.38), xytext=(0.42, -0.25),
                arrowprops=dict(arrowstyle="<|-|>", lw=1.1, color=PALETTE[2]))
    ax.text(0.48, 0.07, "residual", fontsize=6.4, color=PALETTE[2], va="center")
    ax.text(-1.12, -0.78, "A mean-restoring controller moves the system\n"
                          "back along the horizontal axis only. Displacement\n"
                          "along the vertical axis survives it.", fontsize=6.0)
    ax.set_title("Why a residual remains", pad=2)

    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, "b")
    for par, lab in (("N", "release sites (N)"), ("k_rep", "replenishment (k_rep)"),
                     ("p0", "fusion probability (p)")):
        s = sw[f"{par}|q"]
        x, y = np.array(s["d_log_cv2"]), np.array(s["d_log_ppr"])
        m = np.isfinite(x) & np.isfinite(y)
        ax.plot(x[m], y[m], color=LES_COL[lab], lw=1.3, zorder=2)
        ax.plot(x[m][-1:], y[m][-1:], marker=MARKERS[LES_IDX[lab]], ms=4.8,
                mfc=LES_COL[lab], mec=INK, mew=0.6, zorder=3, label=LES_LAB[lab])
    ax.plot([0], [0], "o", ms=5.2, mfc="white", mec=INK, mew=1.0, zorder=4)
    ax.axhline(0, color=GRID, lw=0.5, zorder=0); ax.axvline(0, color=GRID, lw=0.5, zorder=0)
    ax.set_xlabel(r"$\Delta\log CV^2$"); ax.set_ylabel(r"$\Delta\log$ PPR")
    ax.legend(fontsize=6.0, loc="center right")
    ax.text(0.03, 0.96, "postsynaptic\ncompensation", transform=ax.transAxes,
            fontsize=6.4, va="top", fontweight="bold")
    soft_grid(ax, axis="both")
    ax.set_title("Axes separate exactly", pad=2)

    ax = fig.add_subplot(gs[0, 2]); panel_label(ax, "c")
    shown = 0
    for par, lab in (("k_rep", "replenishment (k_rep)"), ("q", "quantal size (q)")):
        s = sw[f"{par}|p0"]
        x, y = np.array(s["d_log_cv2"]), np.array(s["d_log_ppr"])
        m = np.isfinite(x) & np.isfinite(y)
        if not m.any():
            continue
        shown += 1
        ax.plot(x[m], y[m], color=LES_COL[lab], lw=1.3, zorder=2)
        ax.plot(x[m][-1:], y[m][-1:], marker=MARKERS[LES_IDX[lab]], ms=4.8,
                mfc=LES_COL[lab], mec=INK, mew=0.6, zorder=3, label=LES_LAB[lab])
    ax.plot([0], [0], "o", ms=5.2, mfc="white", mec=INK, mew=1.0, zorder=4)
    ax.axhline(0, color=GRID, lw=0.5, zorder=0); ax.axvline(0, color=GRID, lw=0.5, zorder=0)
    ax.set_xlabel(r"$\Delta\log CV^2$"); ax.set_ylabel(r"$\Delta\log$ PPR")
    if shown:
        ax.legend(fontsize=6.0, loc="lower right")
    ax.text(0.03, 0.96, "presynaptic\ncompensation", transform=ax.transAxes,
            fontsize=6.4, va="top", fontweight="bold")
    ax.text(0.97, 0.05, "a loss of release sites cannot\nbe offset this way at all\n"
                        "(panels e, f)",
            transform=ax.transAxes, ha="right", va="bottom", **NOTE)
    soft_grid(ax, axis="both")
    ax.set_title("Nearly collinear", pad=2)

    ax = fig.add_subplot(gs[1, 0]); panel_label(ax, "d", dx=-0.40)
    sub = res[res.actuator == "q"]
    ys, labels, vals, cols = [], [], [], []
    for lab in LES_COL:
        rr = sub[sub.lesion == lab]
        if rr.empty or abs(float(rr.residual_norm.iloc[0])) < 1e-9:
            continue
        ys.append(len(ys)); labels.append(LES_LAB[lab])
        vals.append(float(rr.angle_deg.iloc[0])); cols.append(LES_COL[lab])
    ax.barh(ys, vals, height=0.5, color=cols, ec=INK, lw=0.4)
    for y, v in zip(ys, vals):
        ax.text(v + (5 if v >= 0 else -5), y, f"{v:+.0f}$\\degree$", va="center",
                ha="left" if v >= 0 else "right", fontsize=6.4)
    ax.set_yticks(ys, labels); ax.invert_yaxis()
    ax.set_xlabel("direction of residual (degrees)")
    ax.set_xlim(-130, 75); ax.axvline(0, color=MUTED, lw=0.5)
    ax.text(0.02, 0.06, "capacity sub-axes exactly orthogonal:\n"
                        r"$\partial\log$PPR$/\partial\log N=0$,  "
                        r"$\partial\log CV^2_1/\partial\log k_{rep}=0$",
            transform=ax.transAxes, ha="left", va="bottom", fontsize=5.8,
            bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.2))
    soft_grid(ax, axis="x")
    ax.set_title("Orthogonal fingerprints", pad=2)

    ax = fig.add_subplot(gs[1, 1]); panel_label(ax, "e")
    cl = R.get("ceiling", {})
    for i, (n, s_) in enumerate(zip(SYN_NAMES, SYN_SHORT)):
        if n not in cl:
            continue
        rr = np.array(cl[n]["rates_hz"]); dd = 100 * np.array(cl[n]["delta_max"])
        ax.plot(rr, dd, color=PALETTE[i], lw=1.3, ls=LINESTYLES[i],
                marker=MARKERS[i], ms=2.8, label=s_)
    logx(ax, [0.5, 1, 2, 5, 10, 20, 50, 100])
    ax.set_xlabel("ongoing firing rate (Hz)")
    ax.set_ylabel("site loss that raising $p$\ncan still offset (%)")
    ax.legend(fontsize=5.8, loc="upper right")
    ax.text(0.03, 0.05, "above each curve no presynaptic\ngain restores the drive",
            transform=ax.transAxes, va="bottom", **NOTE)
    soft_grid(ax)
    ax.set_title("Compensation saturates", pad=2)

    ax = fig.add_subplot(gs[1, 2]); panel_label(ax, "f")
    prm = SYNAPSES["E_cortical_L5"]
    p_line = np.linspace(0.02, 0.999, 220)
    for i, rate in enumerate((2.0, 20.0)):
        d = np.array([steady_state_mean(SynapseParams(**{**prm.as_dict(), "p0": pp}),
                                        rate) for pp in p_line])
        b = np.exp(-prm.k_rep / rate)
        ceil_v = prm.N * prm.q * (1.0 - b)
        ax.plot(p_line, d / ceil_v, color=PALETTE[i], lw=1.3, ls=LINESTYLES[i],
                label=f"{rate:.0f} Hz")
        ax.plot([prm.p0], [steady_state_mean(prm, rate) / ceil_v],
                marker=MARKERS[i], ms=4.8, mfc=PALETTE[i], mec=INK, mew=0.6, zorder=4)
    ax.axhline(1.0, color=INK, lw=0.7, ls=":")
    ax.set_xlabel(r"fusion probability $p$")
    ax.set_ylabel("drive, as a fraction of the\nresupply-limited ceiling")
    ax.set_ylim(0, 1.16)
    ax.legend(fontsize=6.0, loc="lower right", title="train rate", title_fontsize=6.0)
    ax.text(0.03, 0.97, r"ceiling $=Nq(1-e^{-k_{rep}/r})$, free of $p$",
            transform=ax.transAxes, fontsize=6.0, va="top",
            bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.2))
    ax.text(0.52, 0.32, "symbols: measured\noperating point",
            transform=ax.transAxes, ha="center", **NOTE)
    soft_grid(ax)
    ax.set_title("Why the ceiling exists", pad=2)

    print(" ", save(fig, "figure3_residual_geometry", FIGS))


# ===========================================================================
def figure4() -> None:
    fig = plt.figure(figsize=(W2, 0.72 * W2))
    gs = fig.add_gridspec(2, 2, wspace=0.42, hspace=0.46)
    el = R["elasticity_landscape"]
    p_grid = np.array(el["p_grid"]); k_grid = np.array(el["k_grid"])
    Ex, Ib = SYNAPSES["E_cortical_L5"], SYNAPSES["I_basket"]

    def _landscape(ax, Z, title, cbl):
        im = ax.pcolormesh(p_grid, k_grid, Z, cmap="viridis", shading="auto",
                           vmin=0, vmax=1, rasterized=True)
        cs = ax.contour(p_grid, k_grid, Z, levels=[0.2, 0.4, 0.6, 0.8],
                        colors="white", linewidths=0.5)
        ax.clabel(cs, fmt="%.1f", fontsize=5.0, inline=True)
        ax.set_yscale("log")
        ax.plot([Ex.p0], [Ex.k_rep], marker="o", ms=5.6, mfc=PALETTE[0],
                mec="white", mew=1.0, zorder=5)
        ax.plot([Ib.p0], [Ib.k_rep], marker="s", ms=5.6, mfc=PALETTE[1],
                mec="white", mew=1.0, zorder=5)
        ax.annotate("excitatory", (Ex.p0, Ex.k_rep), (0.08, 9.0), fontsize=6.0,
                    color="white", arrowprops=dict(arrowstyle="-", lw=0.6, color="white"))
        ax.annotate("inhibitory", (Ib.p0, Ib.k_rep), (0.63, 0.28), fontsize=6.0,
                    color="white", arrowprops=dict(arrowstyle="-", lw=0.6, color="white"))
        ax.set_xlabel(r"fusion probability $p$")
        ax.set_ylabel(r"resupply rate $k_{rep}$ (s$^{-1}$)")
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
        cb.set_label(cbl, fontsize=6.0); cb.ax.tick_params(labelsize=5.6, length=1.6)
        cb.outline.set_linewidth(0.4)
        ax.set_title(title, pad=2)

    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, "a")
    _landscape(ax, np.array(el["S_p"]), "Sensitivity to $p$",
               r"$\partial\log D/\partial\log p$")
    ax = fig.add_subplot(gs[0, 1]); panel_label(ax, "b")
    _landscape(ax, np.array(el["S_k"]), "Sensitivity to $k_{rep}$",
               r"$\partial\log D/\partial\log k_{rep}$")

    ax = fig.add_subplot(gs[1, 0]); panel_label(ax, "c")
    ei = R["ei_asymmetry"]["E_cortical_L5"]
    for i, (par, lab) in enumerate((("k_rep", r"resupply $k_{rep}$"),
                                    ("p0", r"fusion prob. $p$"),
                                    ("N", r"sites $N$"))):
        rates = np.array(ei[par]["rates_hz"]); d = np.array(ei[par]["dlog_EI"])
        ax.plot(rates, 100 * (np.exp(d) - 1), color=PALETTE[i], lw=1.3,
                ls=LINESTYLES[i], marker=MARKERS[i], ms=2.8, label=lab)
    ax.axhline(0, color=INK, lw=0.6)
    logx(ax, [0.5, 1, 2, 5, 10, 20, 50, 100])
    ax.set_xlabel("ongoing presynaptic firing rate (Hz)")
    ax.set_ylabel("change in apparent E/I ratio (%)")
    ax.legend(fontsize=6.0, loc="lower right", title="20% reduction in",
              title_fontsize=6.0)
    ax.text(0.97, 0.96, "the same lesion is applied\nto both synapse classes",
            transform=ax.transAxes, va="top", ha="right", **NOTE)
    soft_grid(ax)
    ax.set_title("Imbalance without a selective defect", pad=2)

    ax = fig.add_subplot(gs[1, 1]); panel_label(ax, "d")
    enames = ["E_cortical_L5", "E_hippocampal_SC"]
    eshort = ["neocortical L5", "hippocampal Schaffer"]
    pars = ["N", "p0", "k_rep"]
    plabs = [r"sites $N$", r"fusion prob. $p$", r"resupply $k_{rep}$"]
    width = 0.34; xs = np.arange(len(pars))
    for i, en in enumerate(enames):
        vals = [100 * (np.exp(R["ei_asymmetry"][en][p]["at_20Hz"]["dlog_EI"]) - 1)
                for p in pars]
        ax.bar(xs + (i - 0.5) * width, vals, width=width * 0.9,
               color=PALETTE[i] if i == 0 else "white",
               ec=INK if i == 0 else PALETTE[1], lw=0.5 if i == 0 else 1.0,
               hatch="" if i == 0 else "////", label=eshort[i], zorder=2)
        for x, v in zip(xs + (i - 0.5) * width, vals):
            ax.text(x, v + (0.18 if v >= 0 else -0.18), f"{v:+.1f}", ha="center",
                    va="bottom" if v >= 0 else "top", fontsize=5.8)
    ax.axhline(0, color=INK, lw=0.6)
    ax.set_xticks(xs, plabs)
    ax.set_ylim(-6.2, 5.4)
    ax.set_ylabel("change in apparent E/I ratio\nat 20 Hz (%)")
    ax.legend(fontsize=6.0, loc="lower right", title="excitatory reference",
              title_fontsize=6.0)
    ax.text(0.03, 0.04, "sign identifies the\nlesioned parameter",
            transform=ax.transAxes, ha="left", va="bottom", **NOTE)
    soft_grid(ax)
    ax.set_title("Direction is diagnostic", pad=2)

    print(" ", save(fig, "figure4_ei_asymmetry", FIGS))


# ===========================================================================
def figure5() -> None:
    fig = plt.figure(figsize=(W2, 0.86 * W2))
    gs = fig.add_gridspec(2, 3, wspace=0.78, hspace=0.42,
                          height_ratios=[1.15, 1.0])
    gt = pd.read_csv(f"{RES}/gene_table.csv")

    # (a) covariate balance
    ax = fig.add_subplot(gs[0, 0]); panel_label(ax, "a")
    pos = 0; xticks, xlabs = [], []
    for ci, c in enumerate(("loeuf", "log_gene_length")):
        for axis, col in (("capacity", PALETTE[0]), ("actuator", PALETTE[1])):
            v = gt.loc[gt[axis] == 1, c].dropna()
            if ci == 1:
                v = (v - gt[c].median()) / gt[c].std()
            ax.boxplot([v], positions=[pos], widths=0.52, patch_artist=True,
                       showfliers=False, medianprops=dict(color=INK, lw=0.9),
                       boxprops=dict(facecolor=col, ec=INK, lw=0.45, alpha=0.75),
                       whiskerprops=dict(color=INK, lw=0.5),
                       capprops=dict(color=INK, lw=0.5))
            xticks.append(pos); xlabs.append(axis[:3]); pos += 1
        pos += 0.9
    ax.set_xticks(xticks, xlabs, fontsize=5.8)
    ax.set_ylabel("value (gene length z-scored)")
    ax.set_ylim(-2.9, 3.6)
    pv = G["covariate_balance"]
    ax.text(0.5, 1.13, f"LOEUF            gene length\n"
                       f"P = {pv['loeuf']['mannwhitney_p']:.2f}          "
                       f"P = {pv['log_gene_length']['mannwhitney_p']:.2f}",
            transform=ax.transAxes, fontsize=6.0, ha="center", va="top")
    ax.legend(handles=[Rectangle((0, 0), 1, 1, fc=PALETTE[0], ec=INK, lw=0.45,
                                 label="capacity axis"),
                       Rectangle((0, 0), 1, 1, fc=PALETTE[1], ec=INK, lw=0.45,
                                 label="actuator axis")],
              fontsize=5.8, loc="lower center", ncol=1)
    soft_grid(ax)
    ax.set_title("The axes are matched", pad=22)

    # (b) forest plot
    ax = fig.add_subplot(gs[0, 1:]); panel_label(ax, "b", dx=-0.055)
    preds = ["capacity", "actuator", "postsynaptic", "vesicle_endocytosis"]
    plabs = ["capacity axis", "actuator axis", "postsynaptic (control)",
             "endocytosis (control)"]
    pcols = [PALETTE[0], PALETTE[1], PALETTE[4], PALETTE[5]]
    ocls = [("asd_sfari_12", "ASD risk gene (SFARI 1-2)"),
            ("asd_de", "altered in ASD cortex"),
            ("asd_de_down", "reduced in ASD cortex")]
    y = 0; yt, yl = [], []
    for oc, ocl in ocls:
        ax.text(0.26, y - 0.95, ocl, fontsize=6.2, fontweight="bold",
                va="center", color=INK)
        for pi, pred in enumerate(preds):
            d = G["logistic"][f"{pred}|{oc}"]
            ax.plot([d["ci95"][0], d["ci95"][1]], [y, y], color=pcols[pi], lw=1.2,
                    solid_capstyle="round")
            ax.plot([d["or"]], [y], marker=MARKERS[pi], ms=4.4, mfc=pcols[pi],
                    mec=INK, mew=0.5)
            star = "***" if d["p"] < 1e-3 else ("**" if d["p"] < 1e-2 else
                                                ("*" if d["p"] < 0.05 else "n.s."))
            ax.text(min(d["ci95"][1] * 1.12, 10.5), y, star, fontsize=5.8, va="center")
            yt.append(y); yl.append(plabs[pi]); y += 1
        y += 1.6
    ax.axvline(1.0, color=MUTED, lw=0.7, ls="--")
    ax.set_xscale("log")
    ax.xaxis.set_major_locator(mticker.FixedLocator([0.3, 0.5, 1, 2, 4, 8]))
    ax.xaxis.set_major_formatter(mticker.FixedFormatter(
        ["0.3", "0.5", "1", "2", "4", "8"]))
    ax.xaxis.set_minor_locator(mticker.NullLocator())
    ax.set_yticks(yt, yl, fontsize=5.8)
    ax.invert_yaxis()
    ax.set_xlim(0.22, 18)
    ax.set_ylim(y - 1.2, -1.6)
    ax.set_xlabel("odds ratio, adjusted for LOEUF, gene and transcript length and GC")
    soft_grid(ax, axis="x")
    ax.set_title("Only the actuator axis tracks the cortical response", pad=2)

    # (c) permutation
    ax = fig.add_subplot(gs[1, 0]); panel_label(ax, "c")
    nd = pd.read_csv(f"{RES}/permutation_null_asd_de_down.csv")
    for i, pred in enumerate(("capacity", "actuator")):
        ax.hist(100 * nd[pred].dropna(), bins=38, color=PALETTE[i], alpha=0.5,
                ec="white", lw=0.25)
        ax.axvline(100 * G["permutation_observed_de_down"][pred], color=PALETTE[i],
                   lw=1.4, ls=LINESTYLES[i])
    ax.set_xlabel("genes reduced in ASD cortex (%)")
    ax.set_ylabel("permutations")
    ax.set_xlim(-0.6, 21)
    ytop = ax.get_ylim()[1]
    ax.set_ylim(0, ytop * 1.30)
    for i, pred in enumerate(("capacity", "actuator")):
        obs = 100 * G["permutation_observed_de_down"][pred]
        p_ = G["permutation"][f"{pred}|asd_de_down"]["p_two_sided"]
        ax.text(obs, ytop * (1.26 - 0.17 * i), f"{pred} {obs:.1f}%, P = {p_:.4f}",
                fontsize=5.8, color=PALETTE[i], va="top", ha="center" if i else "left")
    ax.text(0.97, 0.60, "null matched on LOEUF\nand gene-length deciles",
            transform=ax.transAxes, va="top", ha="right", **NOTE)
    soft_grid(ax)
    ax.set_title("Matched permutation", pad=2)

    # (d) direction coherence
    ax = fig.add_subplot(gs[1, 1]); panel_label(ax, "d")
    dc = G["direction_coherence"]
    preds2 = [p for p in ("capacity", "actuator", "postsynaptic") if p in dc]
    xs = np.arange(len(preds2))
    down = [dc[p]["n_down"] for p in preds2]; up = [dc[p]["n_up"] for p in preds2]
    tot = [d + u for d, u in zip(down, up)]
    fd = [100 * d / t for d, t in zip(down, tot)]
    ax.bar(xs, fd, width=0.54, color=PALETTE[0], ec=INK, lw=0.45, label="reduced")
    ax.bar(xs, [100 - f for f in fd], bottom=fd, width=0.54, color="white",
           ec=PALETTE[1], lw=1.0, hatch="////", label="increased")
    bgd = 100 * dc[preds2[0]]["background_down_fraction"]
    ax.axhline(bgd, color=INK, lw=1.0, ls="--")
    ax.text(len(preds2) - 0.55, bgd - 4.0, f"all ASD-altered genes ({bgd:.0f}%)",
            fontsize=5.4, ha="right", va="top")
    for x, p, t in zip(xs, preds2, tot):
        pv_ = dc[p]["p_vs_background"]
        ptxt = "P < 0.001" if pv_ < 1e-3 else f"P = {pv_:.3f}"
        ax.text(x, 102, f"n = {t}", ha="center", fontsize=5.6)
        ax.text(x, 111, ptxt, ha="center", fontsize=5.4)
    ax.set_xticks(xs, [p.replace("postsynaptic", "post-\nsynaptic") for p in preds2],
                  fontsize=5.8)
    ax.set_ylim(0, 126); ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_ylabel("direction of change (%)")
    ax.legend(fontsize=5.8, loc="lower center", ncol=2,
              bbox_to_anchor=(0.5, -0.30))
    soft_grid(ax)
    ax.set_title("Coherent downregulation", pad=2)

    # (e) per-term
    ax = fig.add_subplot(gs[1, 2]); panel_label(ax, "e", dx=-0.62)
    pt = pd.DataFrame(G["per_term"])
    pt = pt[pt.axis.isin(["capacity", "actuator"])].sort_values(
        ["axis", "pct_asd_de_down"]).reset_index(drop=True)
    ys = np.arange(len(pt))
    for y_, v, a, n in zip(ys, pt.pct_asd_de_down, pt.axis, pt.n_genes):
        c = PALETTE[0] if a == "capacity" else PALETTE[1]
        m = "o" if a == "capacity" else "s"
        ax.plot([0, v], [y_, y_], color=c, lw=0.7, alpha=0.5, zorder=1)
        ax.plot([v], [y_], marker=m, ms=2.0 + 0.8 * np.sqrt(n), mfc=c, mec=INK,
                mew=0.4, zorder=3)
    ax.set_yticks(ys, [l[:24] for l in pt.label], fontsize=4.3)
    ax.tick_params(axis="y", length=0, pad=1)
    ax.set_xlabel("genes reduced in ASD cortex (%)")
    ax.set_ylim(-0.9, len(pt) - 0.1)
    ax.set_xlim(-1, 30)
    ax.legend(handles=[Line2D([], [], marker="o", lw=0, mfc=PALETTE[0], mec=INK,
                              mew=0.4, ms=4, label="capacity"),
                       Line2D([], [], marker="s", lw=0, mfc=PALETTE[1], mec=INK,
                              mew=0.4, ms=4, label="actuator")],
              fontsize=5.6, loc="lower right")
    soft_grid(ax, axis="x")
    ax.set_title("Per annotation term", pad=2)

    print(" ", save(fig, "figure5_human_data", FIGS))


# ===========================================================================
def figure6() -> None:
    fig = plt.figure(figsize=(W2, 0.42 * W2))
    gs = fig.add_gridspec(1, 3, wspace=0.50)
    des = R["design_extended"]
    des_site = R["design"]

    ax = fig.add_subplot(gs[0]); panel_label(ax, "a")
    for i, (n, s_) in enumerate(zip(SYN_NAMES, SYN_SHORT)):
        d = des[n]
        isi = 1000 * np.array(d["isi_grid_s"]); y = np.array(d["I_krepkrep"])
        ax.plot(isi, y / y.max(), color=PALETTE[i], lw=1.2, ls=LINESTYLES[i],
                marker=MARKERS[i], ms=2.6, label=s_)
        ax.plot([1000 * d["best_isi_for_krep_s"]], [1.0], marker="*", ms=7.5,
                mfc=PALETTE[i], mec=INK, mew=0.5, zorder=4)
    logx(ax, [10, 100, 1000, 5000])
    ax.set_xlabel("inter-pulse interval (ms)")
    ax.set_ylabel("information about $k_{rep}$\n(fraction of its maximum)")
    ax.set_ylim(0, 1.30)
    ax.legend(fontsize=5.6, loc="upper left", bbox_to_anchor=(0.0, 0.93))
    ax.text(0.97, 0.97, r"stars: optimum, near $1/k_{rep}$", transform=ax.transAxes,
            va="top", ha="right", **NOTE)
    soft_grid(ax)
    ax.set_title("Optimal interval", pad=2)

    ax = fig.add_subplot(gs[1]); panel_label(ax, "b")
    labs = ["$p$\n20%", "$p$\n10%", "$k_{rep}$\n20%", "$k_{rep}$\n10%"]
    keys = ["trials_20pct_p0", "trials_10pct_p0", "trials_20pct_krep",
            "trials_10pct_krep"]
    xs = np.arange(len(labs)); width = 0.26
    for i, (n, s_) in enumerate(zip(SYN_NAMES, SYN_SHORT)):
        ax.bar(xs + (i - 1) * width, [des[n][k] for k in keys], width=width * 0.9,
               color=PALETTE[i], ec=INK, lw=0.4, label=s_, zorder=2)
    ax.set_yscale("log")
    ax.set_xticks(xs, labs, fontsize=6.0)
    ax.set_ylabel("trials per group\n(80% power, $\\alpha$ = 0.05)")
    ax.axhline(300, color=INK, lw=0.8, ls="--")
    ax.text(-0.48, 340, "300 trials", fontsize=5.6, color=INK)
    ax.legend(fontsize=5.4, loc="upper left")
    soft_grid(ax)
    ax.set_title("Sample size", pad=2)

    ax = fig.add_subplot(gs[2]); panel_label(ax, "c")
    for i, (n, s_) in enumerate(zip(SYN_NAMES, SYN_SHORT)):
        sd = pd.DataFrame(des_site[n]["site_discrimination"])
        sd["delta"] = sd.n_alt - int(round(SYNAPSES[n].N))
        sd = sd[np.isfinite(sd.trials)]
        ax.plot(sd.delta, sd.trials, color=PALETTE[i], lw=1.1, ls=LINESTYLES[i],
                marker=MARKERS[i], ms=3.0, label=s_)
    ax.set_yscale("log")
    ax.axhline(300, color=INK, lw=0.8, ls="--")
    ax.set_ylim(0.7, 3000)
    ax.text(-3.1, 360, "300 trials", fontsize=5.6, color=INK)
    ax.set_xlabel("difference from the true\nrelease-site number")
    ax.set_ylabel("trials to discriminate\n(quantal content matched)")
    ax.legend(fontsize=5.4, loc="upper right")
    md = R.get("mle_recovery_designs", {}).get("short_intervals")
    if md:
        ax.text(0.02, 0.03,
                f"maximum likelihood, {md['n_trials_per_isi']} trials at each of "
                f"{len(md['isis_s'])} intervals:\nsite number exact in "
                f"{100*md['N_correct_frac']:.0f}% of runs, bias "
                f"{100*md['p0_bias']:+.1f}% on $p$ and {100*md['k_rep_bias']:+.1f}% "
                f"on $k_{{rep}}$",
                transform=ax.transAxes, fontsize=5.2, color=INK, va="bottom",
                bbox=dict(fc="white", ec="none", alpha=0.88, pad=1.2))
    soft_grid(ax)
    ax.set_title("Resolving one release site", pad=2)

    print(" ", save(fig, "figure6_design_requirements", FIGS))


if __name__ == "__main__":
    for fn in (figure1, figure2, figure3, figure4, figure5, figure6):
        print(f"building {fn.__name__} ...")
        fn()
    print("done")
