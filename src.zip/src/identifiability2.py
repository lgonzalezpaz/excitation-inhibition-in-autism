"""
identifiability2.py
===================
Protocol-level identifiability: exact Fisher information for the continuous
presynaptic parameters, Kullback-Leibler discrimination for the discrete
number of release sites, D-optimal choice of inter-pulse intervals, and a
maximum-likelihood recovery test.

Rationale
---------
The number of release sites N is a count, not a continuous quantity, so a
Fisher information for log N obtained by smoothly continuing the binomial
coefficient is dominated by the artificial motion of the support boundary
r <= N. N is therefore treated as a discrete parameter and the sample size
required to distinguish N from a neighbouring value is obtained from the
Kullback-Leibler divergence between the corresponding count distributions,
which is the correct quantity for discriminating simple hypotheses. The
continuous parameters (p0, k_rep) retain an ordinary Fisher information.

Trials performed at different inter-pulse intervals are independent, so the
information of a composite protocol is the weighted sum of the per-interval
information matrices. Maximising the determinant of that sum over the
interval allocation is the standard D-optimality criterion and yields the
experimental design that best separates a release-probability lesion from a
replenishment lesion.

License: MIT (see LICENSE).
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.optimize import minimize
from scipy.stats import binom, norm

from release_model import SynapseParams
from identifiability import paired_pulse_count_pmf

__all__ = [
    "pulse_probabilities",
    "pmf_at_isi",
    "fim_continuous",
    "fim_protocol",
    "kl_divergence_sites",
    "trials_for_site_discrimination",
    "trials_for_continuous",
    "d_optimal_allocation",
    "mle_recovery",
]


def pulse_probabilities(prm: SynapseParams, isi: float) -> tuple[float, float, float]:
    """Return (p1, p2, rho) for a paired-pulse protocol at interval ``isi``."""
    rho = 1.0 - np.exp(-prm.k_rep * isi)
    p1 = prm.u0 * prm.p0
    p_after = prm.p0 + prm.f * (1.0 - prm.p0)
    p2 = prm.p0 + (p_after - prm.p0) * np.exp(-isi / prm.tau_f)
    return float(p1), float(np.clip(p2, 1e-9, 1 - 1e-9)), float(rho)


def pmf_at_isi(prm: SynapseParams, isi: float, n_sites: int | None = None) -> np.ndarray:
    """Exact joint count pmf at one interval."""
    n = int(round(prm.N)) if n_sites is None else int(n_sites)
    p1, p2, rho = pulse_probabilities(prm, isi)
    return paired_pulse_count_pmf(n, p1, p2, rho)


# ----------------------------------------------------------------------------
# Fisher information for the continuous parameters, N held fixed
# ----------------------------------------------------------------------------

def fim_continuous(prm: SynapseParams,
                   isi: float,
                   names: Sequence[str] = ("p0", "k_rep"),
                   h: float = 1e-4) -> np.ndarray:
    """Per-trial Fisher information in log-parameters at fixed integer N."""
    n = int(round(prm.N))
    base = pmf_at_isi(prm, isi, n)
    grads = []
    for nm in names:
        up = prm.perturb(**{nm: np.exp(h)})
        dn = prm.perturb(**{nm: np.exp(-h)})
        gu = pmf_at_isi(up, isi, n)
        gd = pmf_at_isi(dn, isi, n)
        grads.append((gu - gd) / (2.0 * h))
    mask = base > 1e-13
    k = len(names)
    fim = np.empty((k, k))
    for i in range(k):
        for j in range(k):
            fim[i, j] = np.sum(grads[i][mask] * grads[j][mask] / base[mask])
    return fim


def fim_protocol(prm: SynapseParams,
                 isis: Sequence[float],
                 weights: Sequence[float] | None = None,
                 names: Sequence[str] = ("p0", "k_rep")) -> np.ndarray:
    """Information of a composite protocol (weighted sum over intervals)."""
    isis = np.asarray(isis, dtype=float)
    if weights is None:
        weights = np.ones_like(isis) / len(isis)
    weights = np.asarray(weights, dtype=float)
    weights = weights / weights.sum()
    total = np.zeros((len(names), len(names)))
    for isi, w in zip(isis, weights):
        total += w * fim_continuous(prm, float(isi), names)
    return total


# ----------------------------------------------------------------------------
# Discrete number of release sites
# ----------------------------------------------------------------------------

def kl_divergence_sites(prm: SynapseParams,
                        isi: float,
                        n_true: int,
                        n_alt: int,
                        match_mean: bool = True) -> float:
    """KL divergence between count distributions for two site numbers.

    With ``match_mean`` the alternative hypothesis rescales p0 so that the
    mean quantal content N * p0 is preserved. This is the relevant comparison
    because the mean is exactly the quantity a homeostatic mechanism (or an
    amplitude-matched experimental design) holds fixed, so any remaining
    divergence comes solely from higher-order structure.
    """
    p_true = pmf_at_isi(prm, isi, n_true)
    prm_alt = prm
    if match_mean:
        scale = float(n_true) / float(n_alt)
        prm_alt = prm.perturb(p0=scale)
        if prm_alt.p0 >= 1.0:
            # the alternative cannot reproduce the mean quantal content at all,
            # so it is excluded on the mean alone
            return {"kl_common_support": np.inf, "p_excluded": 1.0,
                    "unreachable_mean": True}
    p_alt = pmf_at_isi(prm_alt, isi, n_alt)

    k = max(p_true.shape[0], p_alt.shape[0])
    a = np.zeros((k, k)); a[:p_true.shape[0], :p_true.shape[1]] = p_true
    b = np.zeros((k, k)); b[:p_alt.shape[0], :p_alt.shape[1]] = p_alt

    # Outcomes that are possible under the truth but impossible under the
    # alternative falsify the alternative outright; they are reported
    # separately rather than being allowed to send the KL to infinity.
    tol = 1e-13
    possible_true = a > tol
    excluded = possible_true & (b <= tol)
    p_excluded = float(a[excluded].sum())

    common = possible_true & ~excluded
    if common.any():
        a_c = a[common] / a[common].sum()
        b_c = b[common] / max(b[common].sum(), 1e-300)
        kl_common = float(np.sum(a_c * np.log(a_c / np.clip(b_c, 1e-300, None))))
    else:
        kl_common = np.inf
    return {"kl_common_support": kl_common, "p_excluded": p_excluded}


def trials_for_site_discrimination(kl_result: dict | float,
                                   alpha: float = 0.05,
                                   power: float = 0.80) -> float:
    """Trials needed to distinguish two site numbers at given error rates.

    Two routes to rejection are combined and the smaller requirement is
    returned.

    (i) Support falsification. If the alternative assigns zero probability to
        a set of outcomes that occurs with probability q under the truth,
        observing a single such outcome rejects it. The number of trials for
        the stated power is n = log(1 - power) / log(1 - q).

    (ii) Statistical discrimination on the common support. For i.i.d. trials
         the log-likelihood ratio has mean n * KL and, to leading order,
         standard deviation sqrt(n * KL), so n = (z_alpha + z_beta)^2 / KL.
    """
    if isinstance(kl_result, dict):
        kl = kl_result["kl_common_support"]
        q = kl_result["p_excluded"]
    else:
        kl, q = float(kl_result), 0.0

    n_support = np.inf
    if q > 0:
        n_support = np.log(1.0 - power) / np.log(1.0 - min(q, 1 - 1e-15))

    n_stat = np.inf
    if np.isfinite(kl) and kl > 0:
        z_a, z_b = norm.ppf(1.0 - alpha), norm.ppf(power)
        n_stat = (z_a + z_b) ** 2 / kl

    n = min(n_support, n_stat)
    return float(np.ceil(n)) if np.isfinite(n) else np.inf


def trials_for_continuous(fim: np.ndarray,
                          index: int,
                          frac_change: float,
                          alpha: float = 0.05,
                          power: float = 0.80) -> float:
    """Trials per group for a two-sample Wald test on one log-parameter."""
    effect = abs(np.log1p(-abs(frac_change)))
    var1 = np.linalg.pinv(fim)[index, index]
    z_a, z_b = norm.ppf(1.0 - alpha / 2.0), norm.ppf(power)
    return float(2.0 * var1 * (z_a + z_b) ** 2 / effect ** 2)


# ----------------------------------------------------------------------------
# D-optimal interval allocation
# ----------------------------------------------------------------------------

def d_optimal_allocation(prm: SynapseParams,
                         candidate_isis: Sequence[float],
                         names: Sequence[str] = ("p0", "k_rep"),
                         seed: int = 0) -> dict:
    """Allocate a fixed trial budget across candidate intervals (D-optimal).

    Maximises log det of the protocol information matrix over the simplex of
    allocation weights, using a multiplicative-update start followed by
    SLSQP refinement. Cost is a handful of exact pmf evaluations per step.
    """
    isis = np.asarray(candidate_isis, dtype=float)
    per_isi = [fim_continuous(prm, float(t), names) for t in isis]

    def neg_logdet(w_raw: np.ndarray) -> float:
        w = np.abs(w_raw); s = w.sum()
        if s <= 0:
            return 1e9
        w = w / s
        m = sum(wi * fi for wi, fi in zip(w, per_isi))
        sign, ld = np.linalg.slogdet(m)
        return 1e9 if sign <= 0 else -ld

    rng = np.random.default_rng(seed)
    best = None
    for _ in range(5):
        w0 = rng.dirichlet(np.ones(len(isis)))
        res = minimize(neg_logdet, w0, method="SLSQP",
                       bounds=[(0.0, 1.0)] * len(isis),
                       constraints=[{"type": "eq",
                                     "fun": lambda w: np.sum(np.abs(w)) - 1.0}],
                       options={"maxiter": 400, "ftol": 1e-12})
        if best is None or res.fun < best.fun:
            best = res
    w = np.abs(best.x); w = w / w.sum()
    fim = sum(wi * fi for wi, fi in zip(w, per_isi))
    return {"isis": isis, "weights": w, "fim": fim,
            "logdet": float(np.linalg.slogdet(fim)[1]),
            "per_isi_fim": per_isi}


# ----------------------------------------------------------------------------
# Maximum-likelihood recovery test
# ----------------------------------------------------------------------------

def mle_recovery(prm_true: SynapseParams,
                 isis: Sequence[float],
                 n_trials_per_isi: int,
                 n_reps: int = 200,
                 n_grid: Sequence[int] | None = None,
                 seed: int = 0) -> dict:
    """Simulate the protocol and recover (N, p0, k_rep) by maximum likelihood.

    N is profiled over a grid of integers; (p0, k_rep) are optimised by
    Nelder-Mead on the exact multinomial log-likelihood of the count pairs.
    Returns the empirical distribution of estimates, which both validates the
    Cramer-Rao predictions and quantifies finite-sample bias.
    """
    rng = np.random.default_rng(seed)
    n_true = int(round(prm_true.N))
    if n_grid is None:
        n_grid = list(range(max(1, n_true - 4), n_true + 5))

    # pre-compute true pmfs for sampling
    true_pmfs = {t: pmf_at_isi(prm_true, float(t), n_true) for t in isis}

    def loglik(theta: np.ndarray, counts: dict, n_sites: int) -> float:
        lp0, lk = theta
        p0, k = np.exp(lp0), np.exp(lk)
        if not (1e-6 < p0 < 0.999) or not (1e-4 < k < 1e4):
            return 1e12
        cand = prm_true.perturb(p0=p0 / prm_true.p0, k_rep=k / prm_true.k_rep)
        tot = 0.0
        for t, obs in counts.items():
            pmf = pmf_at_isi(cand, float(t), n_sites)
            # Pad the candidate pmf out to the full observed support instead of
            # truncating the data. Outcomes that the candidate cannot produce
            # must falsify it, so they are penalised rather than discarded;
            # truncation would silently favour models with too few sites.
            k_obs = obs.shape[0]
            padded = np.zeros((k_obs, k_obs))
            k_fit = min(pmf.shape[0], k_obs)
            padded[:k_fit, :k_fit] = pmf[:k_fit, :k_fit]
            impossible = (obs > 0) & (padded <= 0.0)
            if impossible.any():
                return 1e12
            pm = np.clip(padded, 1e-300, None)
            tot += np.sum(obs * np.log(pm))
        return -tot

    rows = []
    for _ in range(n_reps):
        counts = {}
        for t in isis:
            pmf = true_pmfs[t]
            flat = pmf.ravel() / pmf.sum()
            draw = rng.multinomial(n_trials_per_isi, flat)
            counts[t] = draw.reshape(pmf.shape).astype(float)
        best = (np.inf, None, None)
        for ns in n_grid:
            res = minimize(loglik, np.array([np.log(prm_true.p0), np.log(prm_true.k_rep)]),
                           args=(counts, ns), method="Nelder-Mead",
                           options={"xatol": 1e-5, "fatol": 1e-7, "maxiter": 800})
            if res.fun < best[0]:
                best = (res.fun, ns, res.x)
        _, ns_hat, th_hat = best
        rows.append((ns_hat, float(np.exp(th_hat[0])), float(np.exp(th_hat[1]))))

    arr = np.array(rows)
    return {
        "N_hat": arr[:, 0], "p0_hat": arr[:, 1], "k_rep_hat": arr[:, 2],
        "N_true": n_true, "p0_true": prm_true.p0, "k_rep_true": prm_true.k_rep,
        "N_correct_frac": float(np.mean(arr[:, 0] == n_true)),
        "p0_bias": float(np.mean(arr[:, 1]) / prm_true.p0 - 1.0),
        "k_rep_bias": float(np.mean(arr[:, 2]) / prm_true.k_rep - 1.0),
        "p0_se_log": float(np.std(np.log(arr[:, 1]), ddof=1)),
        "k_rep_se_log": float(np.std(np.log(arr[:, 2]), ddof=1)),
    }
