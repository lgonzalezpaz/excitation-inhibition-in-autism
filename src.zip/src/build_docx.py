"""
build_docx.py
=============
Converts the final Markdown manuscript into a Word document that follows the
journal style required by the brief: A4, 2.54 cm margins, Times New Roman,
double-spaced black body text, 16 pt bold title, bold sentence-case headings,
smaller abstract, keywords and reference list, page numbers top right, and
continuous line numbers in the left margin.

Equations are carried through Pandoc as native Office Math (OMML) objects, so
they remain editable in Word rather than being images.

Usage:  python build_docx.py
"""

from __future__ import annotations

import os
import re
import subprocess
import sys

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Cm, RGBColor

MAN = os.environ.get("VESICLE_MS_DIR", "../manuscript")
SRC = os.path.join(MAN, "manuscript_final.md")
TMP = os.path.join(MAN, "_pandoc.docx")
OUT = os.path.join(MAN, "manuscript.docx")

BODY_FONT = "Times New Roman"
BLACK = RGBColor(0, 0, 0)


def run_pandoc() -> None:
    cmd = ["pandoc", SRC, "-o", TMP,
           "--from", "markdown+tex_math_dollars+pipe_tables+smart",
           "--to", "docx"]
    subprocess.run(cmd, check=True)


def set_font(run, size: float, bold: bool | None = None,
             italic: bool | None = None) -> None:
    run.font.name = BODY_FONT
    run.font.size = Pt(size)
    run.font.color.rgb = BLACK
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), BODY_FONT)


def space(par, line_rule: float, before: float = 0, after: float = 6) -> None:
    pf = par.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
    pf.line_spacing = line_rule
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.first_line_indent = Pt(0)


def add_line_numbers(section) -> None:
    sect_pr = section._sectPr
    for existing in sect_pr.findall(qn("w:lnNumType")):
        sect_pr.remove(existing)
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:start"), "1")
    ln.set(qn("w:restart"), "continuous")
    ln.set(qn("w:distance"), "360")
    sect_pr.append(ln)


def add_page_numbers(section) -> None:
    header = section.header
    header.is_linked_to_previous = False
    par = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
    par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    for r in list(par.runs):
        r._element.getparent().remove(r._element)
    run = par.add_run()
    set_font(run, 10)
    fld_begin = OxmlElement("w:fldChar"); fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_end = OxmlElement("w:fldChar"); fld_end.set(qn("w:fldCharType"), "end")
    run._element.append(fld_begin)
    run._element.append(instr)
    run._element.append(fld_end)


BACK_MATTER = {
    "crédit", "credit authorship contribution statement", "ethics statement",
    "funding", "declaration of competing interest", "data availability statement",
    "declaration of generative ai and ai-assisted technologies in the writing process",
    "references", "tables", "figure captions", "supplementary material",
}


def style_document() -> None:
    doc = Document(TMP)

    for section in doc.sections:
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        for attr in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
            setattr(section, attr, Cm(2.54))
        add_line_numbers(section)
        add_page_numbers(section)

    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(12)
    normal.font.color.rgb = BLACK

    state = "front"       # front -> abstract -> keywords -> body -> refs
    seen_title = False

    for par in doc.paragraphs:
        text = par.text.strip()
        low = text.lower().rstrip(":")
        style = par.style.name

        if style.startswith("Heading"):
            level = int(style[-1]) if style[-1].isdigit() else 1
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            if level == 1 and not seen_title:
                # the document title
                for r in par.runs:
                    set_font(r, 16, bold=True)
                space(par, 1.15, before=0, after=12)
                seen_title = True
                continue
            size = 13 if level <= 2 else 12
            for r in par.runs:
                set_font(r, size, bold=True, italic=(level >= 3))
            space(par, 1.15, before=14, after=6)
            if low == "abstract":
                state = "abstract"
            elif low == "references":
                state = "refs"
            elif low in BACK_MATTER or low in ("introduction", "methods", "results",
                                               "discussion", "conclusions"):
                if state == "abstract":
                    state = "body"
                if low == "references":
                    state = "refs"
            continue

        if not text:
            continue

        if state == "abstract":
            if low.startswith("keywords"):
                for r in par.runs:
                    set_font(r, 10)
                space(par, 1.15, after=10)
                state = "body"
                continue
            for r in par.runs:
                set_font(r, 11)
            space(par, 1.15, after=8)
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            continue

        if state == "refs":
            for r in par.runs:
                set_font(r, 10)
            space(par, 1.15, after=3)
            par.paragraph_format.left_indent = Cm(0.75)
            par.paragraph_format.first_line_indent = Cm(-0.75)
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            continue

        # author line and affiliations sit before the abstract heading
        if state == "front":
            size = 12 if not seen_title or len(text) < 120 else 10
            for r in par.runs:
                set_font(r, size)
            par.alignment = WD_ALIGN_PARAGRAPH.LEFT
            space(par, 1.15, after=4)
            continue

        for r in par.runs:
            set_font(r, 12)
        par.alignment = WD_ALIGN_PARAGRAPH.LEFT
        space(par, 2.0, after=0)

    # tables: 9 pt, single spaced, black
    for tbl in doc.tables:
        try:
            tbl.style = doc.styles["Table Grid"]
        except KeyError:
            pass
        for row in tbl.rows:
            for cell in row.cells:
                for par in cell.paragraphs:
                    space(par, 1.0, after=0)
                    for r in par.runs:
                        set_font(r, 9)

    doc.save(OUT)


def main() -> int:
    if not os.path.exists(SRC):
        print(f"missing {SRC}; run build_manuscript.py first", file=sys.stderr)
        return 1
    run_pandoc()
    style_document()
    os.remove(TMP)
    print(f"wrote {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
