"""
mpfa.py
=======
Multiple-probability fluctuation analysis (MPFA): recovery of the number of
release sites and the mean quantal size from the variance-mean relationship
obtained by varying the external Ca2+ concentration.

Theory
------
At rest every site is occupied (u = 1), so varying the fusion probability p
by changing external Ca2+ traces out the exact parabola

    var = q (1 + CVq^2) * mean - mean^2 / N                             (P1)

obtained by eliminating p from mean = N p q and
var = N p q^2 (1 - p + CVq^2). Fitting (P1) therefore returns the curvature
-1/N and the initial slope A = q (1 + CVq^2). Crucially, the parabola is a
property of (N, q, CVq) alone: changing p moves the operating point along
the curve but does not change the curve. A homeostatic mechanism that
rescales fusion probability is therefore invisible to the parabola, whereas
a change in release-site number or quantal size changes it. MPFA thus
supplies exactly the measurement dimension that breaks the near-collinearity
of the lesion axes when compensation is presynaptic.

This module simulates a realistic MPFA experiment (finite trials per Ca2+
level, empirical variance), fits (P1) by weighted least squares, and returns
bootstrap confidence intervals for N and q.

License: MIT (see LICENSE).
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.optimize import curve_fit

from release_model import SynapseParams, p0_from_calcium

__all__ = ["parabola", "simulate_mpfa_dataset", "fit_mpfa", "mpfa_recovery_test"]


def parabola(mean: np.ndarray, a: float, n_sites: float) -> np.ndarray:
    """Variance-mean parabola, equation (P1)."""
    return a * mean - mean ** 2 / n_sites


def simulate_mpfa_dataset(prm: SynapseParams,
                          ca_levels: Sequence[float],
                          p_max: float,
                          kd: float,
                          m: float,
                          n_trials: int = 60,
                          seed: int = 0) -> dict:
    """Simulate single-pulse amplitudes at several external Ca2+ levels.

    Quanta are drawn as a binomial count followed by a gamma-distributed
    amplitude per quantum (mean q, coefficient of variation cv_q), which is
    the standard quantal model used in fluctuation analysis.
    """
    rng = np.random.default_rng(seed)
    n_sites = int(round(prm.N))
    means, variances, ps = [], [], []
    for ca in ca_levels:
        p = float(np.clip(p0_from_calcium(ca, p_max, kd, m), 1e-6, 1 - 1e-6))
        r = rng.binomial(n_sites, p, size=n_trials)
        if prm.cv_q > 0:
            shape = 1.0 / prm.cv_q ** 2
            scale = prm.q / shape
            amp = np.zeros(n_trials)
            nz = r > 0
            if nz.any():
                amp[nz] = rng.gamma(shape * r[nz], scale)
        else:
            amp = r * prm.q
        means.append(amp.mean())
        variances.append(amp.var(ddof=1))
        ps.append(p)
    return {"mean": np.asarray(means), "var": np.asarray(variances),
            "p": np.asarray(ps), "ca": np.asarray(ca_levels, dtype=float),
            "n_trials": n_trials}


def fit_mpfa(mean: np.ndarray, var: np.ndarray,
             n_trials: int | None = None) -> dict:
    """Weighted least-squares fit of the variance-mean parabola.

    The sampling variance of an empirical variance scales as var^2, so the
    weights are taken proportional to 1/var, which is the correct relative
    weighting and avoids over-weighting the high-release-probability points.
    """
    sigma = np.maximum(var, np.max(var) * 1e-3)
    p_init = [max(var.max() / max(mean.max(), 1e-9), 1e-6), max(mean.max(), 1.0)]
    popt, pcov = curve_fit(parabola, mean, var, p0=p_init, sigma=sigma,
                           absolute_sigma=False, maxfev=40000)
    a_hat, n_hat = popt
    perr = np.sqrt(np.diag(pcov))
    resid = var - parabola(mean, *popt)
    ss_tot = np.sum((var - var.mean()) ** 2)
    return {"A": float(a_hat), "N": float(n_hat),
            "A_se": float(perr[0]), "N_se": float(perr[1]),
            "r2": float(1.0 - np.sum(resid ** 2) / ss_tot) if ss_tot > 0 else np.nan}


def mpfa_recovery_test(prm: SynapseParams,
                       ca_levels: Sequence[float],
                       p_max: float,
                       kd: float,
                       m: float,
                       n_trials: int = 60,
                       n_reps: int = 300,
                       seed: int = 0) -> dict:
    """Repeat the simulated MPFA experiment and summarise parameter recovery."""
    n_hat, a_hat = [], []
    for rep in range(n_reps):
        d = simulate_mpfa_dataset(prm, ca_levels, p_max, kd, m,
                                  n_trials=n_trials, seed=seed + rep)
        try:
            fit = fit_mpfa(d["mean"], d["var"], n_trials)
        except Exception:
            continue
        if 0 < fit["N"] < 100 * prm.N:
            n_hat.append(fit["N"]); a_hat.append(fit["A"])
    n_hat = np.asarray(n_hat); a_hat = np.asarray(a_hat)
    a_true = prm.q * (1.0 + prm.cv_q ** 2)
    return {
        "N_hat": n_hat, "A_hat": a_hat,
        "N_true": float(prm.N), "A_true": float(a_true),
        "N_median": float(np.median(n_hat)),
        "N_ci": (float(np.percentile(n_hat, 2.5)), float(np.percentile(n_hat, 97.5))),
        "A_median": float(np.median(a_hat)),
        "A_ci": (float(np.percentile(a_hat, 2.5)), float(np.percentile(a_hat, 97.5))),
        "N_rel_bias": float(np.median(n_hat) / prm.N - 1.0),
        "A_rel_bias": float(np.median(a_hat) / a_true - 1.0),
        "n_converged": int(n_hat.size),
    }
