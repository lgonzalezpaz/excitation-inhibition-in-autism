"""
ceiling.py
==========
Two consequences of resupply-limited release that the main analysis exposed.

1. The presynaptic compensation ceiling.
   During a regular train of rate r (interval dt, b = exp(-k_rep dt)) the
   steady-state per-site occupancy is u* = (1 - b)/(1 - (1 - p) b), so the
   steady-state drive is

       D(p) = N q p (1 - b) / (1 - (1 - p) b)                          (C1)

   which is monotonically increasing in p but bounded:

       lim_{p -> 1} D = N q (1 - b)                                    (C2)

   The ceiling does not contain p at all. Raising the fusion probability
   therefore cannot raise the sustained drive above the rate at which sites
   are resupplied. A loss of release sites of fractional size delta can be
   compensated presynaptically only if

       1 - delta  >=  p / (1 - (1 - p) b)                              (C3)

   and the right-hand side approaches 1 as the synapse becomes
   resupply-limited. Capacity lesions are thus not merely detectable after
   compensation: during ongoing activity they are largely uncompensable by
   the presynaptic actuator at all, which is consistent with the observation
   that mammalian presynaptic homeostasis acts first by enlarging the
   releasable pool, with release probability unchanged.

2. Information about the resupply rate.
   Paired pulses carry little information about k_rep, because the
   paired-pulse ratio depends on it only weakly. The steady-state response
   during a train depends on it with an elasticity approaching one. Adding a
   steady-state measurement to the protocol is therefore far more efficient
   than adding paired-pulse trials. The joint information of a first-pulse
   count and a steady-state count is computed here exactly; treating the two
   as independent is conservative, since their correlation can only add
   information.

License: MIT (see LICENSE).
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.stats import binom, norm

from release_model import SynapseParams, steady_state_occupancy, steady_state_mean

__all__ = [
    "compensable_fraction", "ceiling_vs_rate", "max_presynaptic_drive",
    "fim_first_plus_steady_state", "trials_from_fim",
]


# ---------------------------------------------------------------------------
# 1. Compensation ceiling
# ---------------------------------------------------------------------------

def max_presynaptic_drive(prm: SynapseParams, rate_hz: float) -> float:
    """Ceiling (C2) on the steady-state drive reachable by raising p alone."""
    b = np.exp(-prm.k_rep / float(rate_hz))
    return float(prm.N * prm.q * (1.0 - b))


def compensable_fraction(prm: SynapseParams, rate_hz: float) -> float:
    """Largest fractional loss of release sites that p can still compensate.

    Returns delta_max from condition (C3). A value of 0 means that no loss at
    all can be offset; a value near 1 means the synapse is far from its
    resupply limit and the actuator has ample range.
    """
    b = np.exp(-prm.k_rep / float(rate_hz))
    p = prm.p0
    rhs = p / (1.0 - (1.0 - p) * b)
    return float(max(0.0, 1.0 - rhs))


def ceiling_vs_rate(prm: SynapseParams, rates: Sequence[float]) -> dict:
    """Compensable fraction and headroom across firing rates."""
    rates = np.asarray(rates, dtype=float)
    delta = np.array([compensable_fraction(prm, float(r)) for r in rates])
    drive = np.array([steady_state_mean(prm, float(r)) for r in rates])
    ceil = np.array([max_presynaptic_drive(prm, float(r)) for r in rates])
    return {"rates_hz": rates, "delta_max": delta, "drive": drive,
            "ceiling": ceil, "headroom": ceil / drive}


# ---------------------------------------------------------------------------
# 2. Information from adding a steady-state measurement
# ---------------------------------------------------------------------------

def _first_pulse_pmf(prm: SynapseParams, n: int) -> np.ndarray:
    return binom.pmf(np.arange(n + 1), n, prm.u0 * prm.p0)


def _steady_state_pmf(prm: SynapseParams, rate_hz: float, n: int) -> np.ndarray:
    u, p = steady_state_occupancy(prm, rate_hz)
    return binom.pmf(np.arange(n + 1), n, np.clip(u * p, 1e-12, 1 - 1e-12))


def fim_first_plus_steady_state(prm: SynapseParams,
                                rate_hz: float = 20.0,
                                names: Sequence[str] = ("p0", "k_rep"),
                                h: float = 1e-4) -> np.ndarray:
    """Per-trial information of (first-pulse count, steady-state count).

    The two counts are treated as independent observations, which under-
    states the available information and is therefore conservative.
    """
    n = int(round(prm.N))
    k = len(names)
    fim = np.zeros((k, k))
    for pmf_fn in (lambda q: _first_pulse_pmf(q, n),
                   lambda q: _steady_state_pmf(q, rate_hz, n)):
        base = pmf_fn(prm)
        grads = []
        for nm in names:
            up, dn = prm.perturb(**{nm: np.exp(h)}), prm.perturb(**{nm: np.exp(-h)})
            grads.append((pmf_fn(up) - pmf_fn(dn)) / (2.0 * h))
        mask = base > 1e-13
        for i in range(k):
            for j in range(k):
                fim[i, j] += np.sum(grads[i][mask] * grads[j][mask] / base[mask])
    return fim


def trials_from_fim(fim: np.ndarray, index: int, frac_change: float,
                    alpha: float = 0.05, power: float = 0.80) -> float:
    """Trials per group for a two-sample Wald test on a log-parameter."""
    effect = abs(np.log1p(-abs(frac_change)))
    var1 = np.linalg.pinv(fim)[index, index]
    z_a, z_b = norm.ppf(1.0 - alpha / 2.0), norm.ppf(power)
    return float(2.0 * var1 * (z_a + z_b) ** 2 / effect ** 2)
