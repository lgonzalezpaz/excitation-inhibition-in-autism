"""
make_results.py
===============
Computes every numerical result reported in the manuscript and writes them to
``results/`` as JSON and CSV. Run before make_figures.py.

Usage:  python make_results.py
"""

from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd

from release_model import (
    SynapseParams, simulate_moments, monte_carlo_train, cv2_first_pulse,
    paired_pulse_ratio, failure_probability, steady_state_mean,
    observable_vector, OBSERVABLE_NAMES, p0_from_calcium,
)
from identifiability import (
    elasticity_matrix, mean_only_jacobian, actuator_jacobian,
    orthogonal_projector, LOG_PARAMS,
)
from identifiability2 import (
    fim_continuous, fim_protocol, kl_divergence_sites,
    trials_for_site_discrimination, trials_for_continuous,
    d_optimal_allocation, mle_recovery,
)
from analysis_core import (
    elasticities_analytic, elasticities_numeric, apparent_ei_shift,
    ei_shift_vs_rate, residual_coordinates, residual_phase_diagram,
    lesion_magnitude_sweep, LESION_AXES,
)
from mpfa import simulate_mpfa_dataset, fit_mpfa, mpfa_recovery_test, parabola
from params_literature import (
    SYNAPSES, PARAM_PROVENANCE, SOURCES, CA_COOPERATIVITY, CA3_CA1_HILL,
    fit_hill_two_points,
)

OUT = os.environ.get("VESICLE_RESULTS_DIR", "../results")
os.makedirs(OUT, exist_ok=True)
SEED = 20261029
R: dict = {"seed": SEED}


def _j(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.floating, np.integer)):
        return x.item()
    if isinstance(x, SynapseParams):
        return x.as_dict()
    if isinstance(x, dict):
        return {k: _j(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_j(v) for v in x]
    return x


# ---------------------------------------------------------------------------
print("[1/8] Monte-Carlo verification of the moment recursions")
# ---------------------------------------------------------------------------
mc_rows = []
for prm in (SYNAPSES["E_cortical_L5"], SYNAPSES["E_hippocampal_SC"], SYNAPSES["I_basket"]):
    pr = SynapseParams(**{**prm.as_dict(), "N": float(round(prm.N))})
    isis = [0.05] * 7
    an = simulate_moments(pr, isis)
    mc = monte_carlo_train(pr, isis, n_trials=400_000, seed=SEED)
    for k in range(len(isis) + 1):
        mc_rows.append({
            "synapse": pr.label, "pulse": k + 1,
            "mean_analytic": an["mean"][k], "mean_mc": mc["mean"][k],
            "var_analytic": an["var"][k], "var_mc": mc["var"][k],
            "cv2_analytic": an["cv2"][k], "cv2_mc": mc["cv2"][k],
            "pfail_analytic": an["p_fail"][k], "pfail_mc": mc["p_fail"][k],
        })
mc_df = pd.DataFrame(mc_rows)
mc_df["rel_err_mean"] = (mc_df.mean_mc - mc_df.mean_analytic).abs() / mc_df.mean_analytic
mc_df["rel_err_var"] = (mc_df.var_mc - mc_df.var_analytic).abs() / mc_df.var_analytic
mc_df.to_csv(f"{OUT}/table_monte_carlo_verification.csv", index=False)
R["monte_carlo"] = {"max_rel_err_mean": float(mc_df.rel_err_mean.max()),
                    "max_rel_err_var": float(mc_df.rel_err_var.max()),
                    "n_trials": 400_000}

# ---------------------------------------------------------------------------
print("[2/8] Structural identifiability")
# ---------------------------------------------------------------------------
ident = {}
for name, prm in SYNAPSES.items():
    jm = mean_only_jacobian(prm)
    jf = elasticity_matrix(prm)
    ident[name] = {
        "params": list(LOG_PARAMS),
        "observables": list(OBSERVABLE_NAMES),
        "jacobian_mean_only": jm,
        "rank_mean_only": int(np.linalg.matrix_rank(jm, tol=1e-8)),
        "jacobian_full": jf,
        "rank_full": int(np.linalg.matrix_rank(jf, tol=1e-8)),
        "cond_full": float(np.linalg.cond(jf)),
        "null_dim_mean_only": int(len(LOG_PARAMS) - np.linalg.matrix_rank(jm, tol=1e-8)),
    }
R["identifiability"] = ident

# structural zeros, verified over random parameter draws
rng = np.random.default_rng(SEED)
z1 = z2 = 0.0
for _ in range(500):
    pr = SynapseParams(N=float(rng.integers(2, 25)), p0=float(rng.uniform(0.05, 0.9)),
                       k_rep=float(rng.uniform(0.5, 40)), q=float(rng.uniform(5, 40)),
                       cv_q=float(rng.uniform(0.1, 0.6)), f=float(rng.uniform(0, 0.5)),
                       tau_f=float(rng.uniform(0.02, 0.4)))
    isi = float(rng.uniform(0.01, 0.5))
    h = 1e-5
    a = (np.log(paired_pulse_ratio(pr.perturb(N=np.exp(h)), isi))
         - np.log(paired_pulse_ratio(pr.perturb(N=np.exp(-h)), isi))) / (2 * h)
    b = (np.log(cv2_first_pulse(pr.perturb(k_rep=np.exp(h))))
         - np.log(cv2_first_pulse(pr.perturb(k_rep=np.exp(-h))))) / (2 * h)
    z1, z2 = max(z1, abs(a)), max(z2, abs(b))
R["structural_zeros"] = {"max_abs_dlogPPR_dlogN": float(z1),
                         "max_abs_dlogCV2_dlogkrep": float(z2),
                         "n_random_draws": 500}

# ---------------------------------------------------------------------------
print("[3/8] Calcium dependence and literature validation")
# ---------------------------------------------------------------------------
hill = CA3_CA1_HILL
ca_grid = np.logspace(np.log10(0.3), np.log10(8.0), 200)
R["calcium"] = {
    "cooperativity": CA_COOPERATIVITY,
    "hill_fit": hill,
    "anchor_points": [{"ca_mM": 1.0, "p": 0.08, "source": "durst2022"},
                      {"ca_mM": 4.0, "p": 0.79, "source": "durst2022"}],
    "prediction_at_2mM": float(p0_from_calcium(2.0, hill["p_max"], hill["kd"], hill["m"])),
    "independent_measurement_2mM": {"mean": 0.43, "sd": 0.28, "n": 43,
                                    "source": "hanse2001"},
}
R["calcium"]["deviation_sd"] = float(
    (R["calcium"]["prediction_at_2mM"] - 0.43) / 0.28)
pd.DataFrame({"ca_mM": ca_grid,
              "p": p0_from_calcium(ca_grid, hill["p_max"], hill["kd"], hill["m"])}
             ).to_csv(f"{OUT}/curve_calcium_hill.csv", index=False)

# sensitivity of the prediction to the assumed cooperativity
sens = []
for m in (3.0, 3.5, 4.0, 4.5, 5.0):
    h2 = fit_hill_two_points(1.0, 0.08, 4.0, 0.79, m)
    sens.append({"m": m, "p_max": h2["p_max"], "kd": h2["kd"],
                 "p_at_2mM": float(p0_from_calcium(2.0, h2["p_max"], h2["kd"], m))})
R["calcium"]["cooperativity_sensitivity"] = sens

# predicted vs measured release statistics
lit_checks = []
E5 = SYNAPSES["E_cortical_L5"]
lit_checks.append({"quantity": "amplitude CV, L5 to L5",
                   "predicted": float(np.sqrt(cv2_first_pulse(E5))),
                   "measured": 0.52, "measured_note": "unitary EPSP CV, mean (median 0.41)",
                   "source": "markram1997", "independent": True})
lit_checks.append({"quantity": "failure probability, L5 to L5",
                   "predicted": float(failure_probability(E5)),
                   "measured": 0.14, "measured_note": "mean failure rate",
                   "source": "markram1997", "independent": True})
Ib = SYNAPSES["I_basket"]
lit_checks.append({"quantity": "PPR at 10 ms, basket to granule",
                   "predicted": float(paired_pulse_ratio(Ib, 0.010)),
                   "measured": 0.63, "measured_note": "37 % paired-pulse depression",
                   "source": "kraushaar2000", "independent": False,
                   "note": "facilitation increment calibrated to this value"})
# effective site number implied by the measured failure rate
p_eff = E5.p0
n_implied = np.log(0.14) / np.log(1 - p_eff)
lit_checks.append({"quantity": "release sites implied by measured failure rate",
                   "predicted": float(n_implied), "measured": 5.5,
                   "measured_note": "anatomical contacts per connection",
                   "source": "markram1997", "independent": True})
R["literature_checks"] = lit_checks
pd.DataFrame(lit_checks).to_csv(f"{OUT}/table_literature_checks.csv", index=False)

# ---------------------------------------------------------------------------
print("[4/8] MPFA recovery")
# ---------------------------------------------------------------------------
ca_levels = [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0]
E_mpfa = SynapseParams(**{**E5.as_dict(), "N": 6.0, "q": 20.0})
mpfa_res = {}
for lab, prm in (("WT", E_mpfa),
                 ("capacity lesion (N -20%)", E_mpfa.perturb(N=0.8)),
                 ("quantal lesion (q -20%)", E_mpfa.perturb(q=0.8)),
                 ("presynaptic compensation (p +30%)", E_mpfa.perturb(p0=1.3))):
    rec = mpfa_recovery_test(prm, ca_levels, hill["p_max"], hill["kd"], hill["m"],
                             n_trials=60, n_reps=300, seed=SEED)
    mpfa_res[lab] = {k: v for k, v in rec.items() if k not in ("N_hat", "A_hat")}
    mpfa_res[lab]["N_true"] = float(prm.N)
R["mpfa"] = {"ca_levels_mM": ca_levels, "n_trials_per_level": 60,
             "n_simulated_experiments": 300, "recovery": mpfa_res}
# one example dataset for plotting
ex = simulate_mpfa_dataset(E_mpfa, ca_levels, hill["p_max"], hill["kd"], hill["m"],
                           n_trials=60, seed=SEED)
ex_fit = fit_mpfa(ex["mean"], ex["var"])
pd.DataFrame({"ca_mM": ex["ca"], "p": ex["p"], "mean": ex["mean"], "var": ex["var"]}
             ).to_csv(f"{OUT}/example_mpfa_dataset.csv", index=False)
R["mpfa"]["example_fit"] = ex_fit

# ---------------------------------------------------------------------------
print("[5/8] Compensation-invariant residual")
# ---------------------------------------------------------------------------
res_rows = []
for name, prm in SYNAPSES.items():
    for lesion_label, lesion in LESION_AXES.items():
        for act in ("p0", "q"):
            r = residual_coordinates(prm, lesion, act, rate_ss=20.0, isi_ppr=0.050)
            row = {"synapse": name, "lesion": lesion_label, "actuator": act,
                   "ok": r.get("ok", False)}
            if r.get("ok"):
                row.update({"d_log_cv2": r["d_log_cv2"], "d_log_ppr": r["d_log_ppr"],
                            "d_log_drive": r["d_log_drive"],
                            "actuator_scale": r["actuator_scale"],
                            "angle_deg": float(np.degrees(np.arctan2(r["d_log_ppr"],
                                                                     r["d_log_cv2"]))),
                            "residual_norm": float(np.hypot(r["d_log_cv2"],
                                                            r["d_log_ppr"]))})
            res_rows.append(row)
res_df = pd.DataFrame(res_rows)
res_df.to_csv(f"{OUT}/table_residual_sectors.csv", index=False)
R["residual_sectors"] = res_df.to_dict(orient="records")

# severity sweeps for the trajectory plot
fr = [0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.6, 0.5]
sweeps = {}
for par in ("N", "k_rep", "p0", "q"):
    for act in ("p0", "q"):
        s = lesion_magnitude_sweep(SYNAPSES["E_cortical_L5"], par, act, fr)
        sweeps[f"{par}|{act}"] = {"fractions": s["fractions"],
                                  "d_log_cv2": s["d_log_cv2"],
                                  "d_log_ppr": s["d_log_ppr"]}
R["residual_sweeps"] = sweeps

# separation angles between lesion axes, by compensation route
def _vec(prm, lesion, act, isis=(0.02, 0.05, 0.20)):
    from identifiability import compensate
    target = steady_state_mean(prm, 20.0)
    les = prm.perturb(**lesion)
    cmp_ = compensate(les, target, actuator=act, control_variable="mean_ss", rate_ss=20.0)
    if cmp_ is None:
        return None
    v = [np.log(cv2_first_pulse(cmp_) / cv2_first_pulse(prm))]
    for t in isis:
        v.append(np.log(paired_pulse_ratio(cmp_, t) / paired_pulse_ratio(prm, t)))
    return np.array(v)


def _ang(a, b):
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na < 1e-12 or nb < 1e-12:
        return float("nan")      # a null residual has no direction
    c = a @ b / (na * nb)
    return float(np.degrees(np.arccos(np.clip(c, -1, 1))))


sep = {}
for act in ("p0", "q"):
    vN = _vec(SYNAPSES["E_cortical_L5"], {"N": 0.8}, act)
    vK = _vec(SYNAPSES["E_cortical_L5"], {"k_rep": 0.8}, act)
    vQ = _vec(SYNAPSES["E_cortical_L5"], {"q": 0.8}, act)
    if vN is None or vK is None:
        continue
    sep[act] = {
        "angle_N_vs_krep_2D": _ang(vN[[0, 2]], vK[[0, 2]]),
        "angle_N_vs_krep_multiISI": _ang(vN, vK),
        "angle_N_vs_q_multiISI": _ang(vN, vQ) if vQ is not None else None,
        "vectors": {"N": vN, "k_rep": vK, "q": vQ},
        "isis_s": [0.02, 0.05, 0.20],
    }
R["axis_separation"] = sep

# ---------------------------------------------------------------------------
print("[6/8] Emergent excitation-inhibition asymmetry")
# ---------------------------------------------------------------------------
Ical = SYNAPSES["I_basket"]
ei = {}
rates = np.array([0.5, 1, 2, 3, 5, 8, 10, 15, 20, 30, 40, 60, 80, 100], dtype=float)
for ename in ("E_cortical_L5", "E_hippocampal_SC"):
    Ex = SYNAPSES[ename]
    per_axis = {}
    for par in ("N", "p0", "k_rep"):
        at20 = apparent_ei_shift(Ex, Ical, 20.0, par, np.log(0.8))
        vs = ei_shift_vs_rate(Ex, Ical, rates, par, np.log(0.8))
        per_axis[par] = {"at_20Hz": at20, "rates_hz": rates,
                         "dlog_EI": vs["dlog_EI"], "S_E": vs["S_E"], "S_I": vs["S_I"],
                         "peak_rate_hz": float(rates[np.argmax(np.abs(vs["dlog_EI"]))]),
                         "peak_dlog_EI": float(vs["dlog_EI"][np.argmax(np.abs(vs["dlog_EI"]))])}
    ei[ename] = per_axis
R["ei_asymmetry"] = ei

# elasticity landscape
p_grid = np.linspace(0.05, 0.95, 60)
k_grid = np.logspace(np.log10(0.2), np.log10(40), 60)
Sp = np.empty((len(k_grid), len(p_grid)))
Sk = np.empty_like(Sp)
for i, k in enumerate(k_grid):
    for j, p in enumerate(p_grid):
        a = elasticities_analytic(SynapseParams(N=5, p0=p, k_rep=k), 20.0)
        Sp[i, j], Sk[i, j] = a["S_p"], a["S_k"]
R["elasticity_landscape"] = {"p_grid": p_grid, "k_grid": k_grid, "S_p": Sp, "S_k": Sk,
                             "rate_hz": 20.0}
# verify the identity S_p == u*
idn = []
for _ in range(200):
    p = float(rng.uniform(0.02, 0.98)); k = float(rng.uniform(0.2, 50))
    a = elasticities_analytic(SynapseParams(N=5, p0=p, k_rep=k), float(rng.uniform(1, 100)))
    idn.append(abs(a["S_p"] - a["u_star"]))
R["identity_Sp_equals_ustar_max_abs_dev"] = float(max(idn))

# ---------------------------------------------------------------------------
print("[7/8] Experimental design requirements")
# ---------------------------------------------------------------------------
design = {}
isi_grid = np.array([0.01, 0.02, 0.03, 0.05, 0.075, 0.1, 0.15, 0.2, 0.3, 0.4, 0.6, 0.8, 1.2])
for name, prm in SYNAPSES.items():
    pr = SynapseParams(**{**prm.as_dict(), "N": float(round(prm.N))})
    fim_by_isi = [fim_continuous(pr, float(t)) for t in isi_grid]
    dopt = d_optimal_allocation(pr, list(isi_grid))
    kl_rows = []
    n_int = int(round(pr.N))
    for alt in range(max(1, n_int - 3), n_int + 4):
        if alt == n_int:
            continue
        kl = kl_divergence_sites(pr, 0.050, n_int, alt)
        kl_rows.append({"n_alt": alt, **kl,
                        "trials": trials_for_site_discrimination(kl)})
    design[name] = {
        "isi_grid_s": isi_grid,
        "I_p0p0": np.array([f[0, 0] for f in fim_by_isi]),
        "I_krepkrep": np.array([f[1, 1] for f in fim_by_isi]),
        "logdet": np.array([float(np.linalg.slogdet(f)[1]) for f in fim_by_isi]),
        "best_isi_for_krep_s": float(isi_grid[int(np.argmax([f[1, 1] for f in fim_by_isi]))]),
        "d_optimal_weights": dopt["weights"],
        "d_optimal_logdet": dopt["logdet"],
        "trials_20pct_p0": trials_for_continuous(dopt["fim"], 0, 0.20),
        "trials_20pct_krep": trials_for_continuous(dopt["fim"], 1, 0.20),
        "trials_10pct_p0": trials_for_continuous(dopt["fim"], 0, 0.10),
        "trials_10pct_krep": trials_for_continuous(dopt["fim"], 1, 0.10),
        "site_discrimination": kl_rows,
    }
R["design"] = design

print("      maximum-likelihood recovery check")
prE = SynapseParams(**{**SYNAPSES["E_cortical_L5"].as_dict(), "N": 6.0})
mle = mle_recovery(prE, isis=(0.02, 0.05, 0.20), n_trials_per_isi=200,
                   n_reps=60, n_grid=list(range(3, 10)), seed=SEED)
R["mle_recovery"] = {k: v for k, v in mle.items()
                     if k not in ("N_hat", "p0_hat", "k_rep_hat")}
pd.DataFrame({"N_hat": mle["N_hat"], "p0_hat": mle["p0_hat"],
              "k_rep_hat": mle["k_rep_hat"]}).to_csv(
    f"{OUT}/mle_recovery_draws.csv", index=False)

# ---------------------------------------------------------------------------
print("[8/8] Parameter table with provenance")
# ---------------------------------------------------------------------------
rows = []
for name, prm in SYNAPSES.items():
    prov = PARAM_PROVENANCE[name]
    for key in ("N", "p0", "k_rep", "cv_q", "f"):
        p, src, note = prov.get(key, ("unspecified", None, ""))
        rows.append({"synapse": name, "label": prm.label, "parameter": key,
                     "value": getattr(prm, key), "provenance": p,
                     "source_key": src, "note": note,
                     "reference": SOURCES.get(src, "") if src and "+" not in str(src)
                     else " | ".join(SOURCES.get(s, s) for s in str(src).split("+"))})
pd.DataFrame(rows).to_csv(f"{OUT}/table_parameters.csv", index=False)
R["sources"] = SOURCES

with open(f"{OUT}/results.json", "w") as fh:
    json.dump(_j(R), fh, indent=1)
print(f"\nWrote {OUT}/results.json and tables.")
