"""
analysis_core.py
================
The two central analyses of the manuscript.

A. Analytic elasticities of the steady-state synaptic drive.
   For a regular train of rate r (interval dt = 1/r) and constant fusion
   probability p, the steady-state per-site occupancy is

     u* = (1 - b) / (1 - (1 - p) b),      b = exp(-k_rep * dt)

   so the steady-state mean drive is D = N q p u* and

     S_N = d log D / d log N     = 1                                  (E1)
     S_p = d log D / d log p     = (1 - b) / (1 - (1 - p) b)          (E2)
     S_k = d log D / d log k_rep = k_rep dt b p
                                   / [(1 - b)(1 - (1 - p) b)]         (E3)

   S_p is strictly decreasing in p and S_k is strictly increasing in p
   (both proved in the Supplementary derivation and verified numerically
   here). Consequently a lesion that is identical in every synapse produces
   a *different* fractional change in excitatory and inhibitory drive purely
   because the two synapse classes operate at different release
   probabilities. The apparent change in the excitation-inhibition ratio is

     d log(E/I) = (S_x^E - S_x^I) * d log x                           (E4)

   whose sign identifies the lesioned parameter x, and whose magnitude grows
   with the rate of ongoing activity because b -> 0 as r -> 0.

B. The compensation-invariant residual.
   A homeostatic controller restores the mean drive by scaling one actuator
   (presynaptic fusion probability, or postsynaptic quantal size). Because
   the map from parameters to the vector of release statistics is not
   collinear, restoring the mean cannot restore CV^2 and the paired-pulse
   ratio simultaneously. The displacement that survives compensation,
   measured in the experimentally routine coordinates (d log CV^2,
   d log PPR), falls in a distinct sector for each combination of lesioned
   parameter and actuator, and therefore identifies the primary lesion.

License: MIT (see LICENSE).
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from release_model import (
    SynapseParams,
    simulate_moments,
    steady_state_mean,
    steady_state_occupancy,
    cv2_first_pulse,
    paired_pulse_ratio,
)
from identifiability import compensate

__all__ = [
    "elasticities_analytic",
    "elasticities_numeric",
    "apparent_ei_shift",
    "ei_shift_vs_rate",
    "residual_coordinates",
    "residual_phase_diagram",
    "lesion_magnitude_sweep",
]


# ----------------------------------------------------------------------------
# A. Elasticities of the steady-state drive
# ----------------------------------------------------------------------------

def elasticities_analytic(prm: SynapseParams, rate_hz: float) -> dict:
    """Closed-form elasticities (E1)-(E3); valid for f = 0."""
    dt = 1.0 / float(rate_hz)
    b = np.exp(-prm.k_rep * dt)
    p = prm.p0
    denom = 1.0 - (1.0 - p) * b
    s_p = (1.0 - b) / denom
    s_k = prm.k_rep * dt * b * p / ((1.0 - b) * denom) if b < 1.0 else 0.0
    return {"S_N": 1.0, "S_p": float(s_p), "S_k": float(s_k),
            "u_star": float((1.0 - b) / denom), "b": float(b)}


def elasticities_numeric(prm: SynapseParams, rate_hz: float,
                         h: float = 1e-5) -> dict:
    """Central-difference elasticities of log steady-state drive."""
    out = {}
    for name, key in (("N", "S_N"), ("p0", "S_p"), ("k_rep", "S_k")):
        up = prm.perturb(**{name: np.exp(h)})
        dn = prm.perturb(**{name: np.exp(-h)})
        out[key] = float((np.log(steady_state_mean(up, rate_hz))
                          - np.log(steady_state_mean(dn, rate_hz))) / (2.0 * h))
    return out


def apparent_ei_shift(prm_e: SynapseParams,
                      prm_i: SynapseParams,
                      rate_hz: float,
                      parameter: str,
                      log_change: float) -> dict:
    """Apparent change in log(E/I) produced by an identical lesion (E4).

    ``log_change`` is d log x, e.g. np.log(0.8) for a 20 % reduction.
    """
    key = {"N": "S_N", "p0": "S_p", "k_rep": "S_k"}[parameter]
    e = elasticities_numeric(prm_e, rate_hz)[key]
    i = elasticities_numeric(prm_i, rate_hz)[key]
    return {"S_E": e, "S_I": i, "dlog_EI": float((e - i) * log_change),
            "dlog_E": float(e * log_change), "dlog_I": float(i * log_change)}


def ei_shift_vs_rate(prm_e: SynapseParams,
                     prm_i: SynapseParams,
                     rates: Sequence[float],
                     parameter: str,
                     log_change: float) -> dict:
    """Activity dependence of the apparent E/I shift."""
    rates = np.asarray(rates, dtype=float)
    out = {k: np.empty_like(rates) for k in ("S_E", "S_I", "dlog_EI")}
    for n, r in enumerate(rates):
        res = apparent_ei_shift(prm_e, prm_i, float(r), parameter, log_change)
        for k in out:
            out[k][n] = res[k]
    out["rates"] = rates
    return out


# ----------------------------------------------------------------------------
# B. Compensation-invariant residual
# ----------------------------------------------------------------------------

def residual_coordinates(prm_wt: SynapseParams,
                         lesion: dict,
                         actuator: str,
                         rate_ss: float = 20.0,
                         isi_ppr: float = 0.050,
                         control_variable: str = "mean_ss") -> dict:
    """Residual in the (d log CV^2, d log PPR) plane after compensation.

    Both coordinates are mean-invariant: they are unchanged by any uniform
    rescaling of the response amplitude, so they are exactly the part of the
    release-statistics vector that a mean-restoring controller cannot touch
    by construction of the measurement, in addition to being displaced by
    the geometry of the parameter-to-observable map.
    """
    target = (steady_state_mean(prm_wt, rate_ss) if control_variable == "mean_ss"
              else simulate_moments(prm_wt, [])["mean"][0])
    prm_les = prm_wt.perturb(**lesion)
    prm_cmp = compensate(prm_les, target, actuator=actuator,
                         control_variable=control_variable, rate_ss=rate_ss)
    if prm_cmp is None:
        return {"ok": False, "reason": "actuator saturated"}

    cv2_wt, cv2_cmp = cv2_first_pulse(prm_wt), cv2_first_pulse(prm_cmp)
    ppr_wt = paired_pulse_ratio(prm_wt, isi_ppr)
    ppr_cmp = paired_pulse_ratio(prm_cmp, isi_ppr)
    drive_wt = steady_state_mean(prm_wt, rate_ss)
    drive_cmp = steady_state_mean(prm_cmp, rate_ss)
    return {
        "ok": True,
        "d_log_cv2": float(np.log(cv2_cmp / cv2_wt)),
        "d_log_ppr": float(np.log(ppr_cmp / ppr_wt)),
        "d_log_drive": float(np.log(drive_cmp / drive_wt)),
        "actuator_scale": float(getattr(prm_cmp, actuator) / getattr(prm_les, actuator)),
        "params_compensated": prm_cmp,
        "cv2_wt": cv2_wt, "cv2_cmp": cv2_cmp,
        "ppr_wt": ppr_wt, "ppr_cmp": ppr_cmp,
    }


LESION_AXES = {
    "release sites (N)": {"N": 0.80},
    "replenishment (k_rep)": {"k_rep": 0.80},
    "fusion probability (p)": {"p0": 0.80},
    "quantal size (q)": {"q": 0.80},
}

ACTUATORS = ("p0", "q")


def residual_phase_diagram(prm_wt: SynapseParams,
                           lesion_axes: dict | None = None,
                           actuators: Sequence[str] = ACTUATORS,
                           rate_ss: float = 20.0,
                           isi_ppr: float = 0.050) -> list[dict]:
    """Residual coordinates for every lesion-axis x actuator combination."""
    if lesion_axes is None:
        lesion_axes = LESION_AXES
    rows = []
    for name, lesion in lesion_axes.items():
        for act in actuators:
            res = residual_coordinates(prm_wt, lesion, act,
                                       rate_ss=rate_ss, isi_ppr=isi_ppr)
            rows.append({"lesion": name, "lesion_spec": lesion,
                         "actuator": act, **res})
    return rows


def lesion_magnitude_sweep(prm_wt: SynapseParams,
                           lesion_param: str,
                           actuator: str,
                           fractions: Sequence[float],
                           rate_ss: float = 20.0,
                           isi_ppr: float = 0.050) -> dict:
    """Residual trajectory as the lesion severity is increased."""
    cv2, ppr, ok = [], [], []
    for fr in fractions:
        res = residual_coordinates(prm_wt, {lesion_param: fr}, actuator,
                                   rate_ss=rate_ss, isi_ppr=isi_ppr)
        ok.append(res["ok"])
        cv2.append(res.get("d_log_cv2", np.nan))
        ppr.append(res.get("d_log_ppr", np.nan))
    return {"fractions": np.asarray(fractions, dtype=float),
            "d_log_cv2": np.asarray(cv2), "d_log_ppr": np.asarray(ppr),
            "ok": np.asarray(ok)}
