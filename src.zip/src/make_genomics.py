"""
make_genomics.py
================
Runs the human-data validation and writes all results to ``results/``.

Usage:  python make_genomics.py
"""

from __future__ import annotations

import json
import os

import numpy as np
import pandas as pd
from scipy.stats import binomtest, mannwhitneyu

from genomics import (
    AXIS_TERMS, CONTROL_TERMS, build_table, load_go, genes_for_terms,
    axis_contingency, logistic_enrichment, matched_permutation_test,
    double_dissociation,
)

OUT = os.environ.get("VESICLE_RESULTS_DIR", "../results")
os.makedirs(OUT, exist_ok=True)
SEED = 20261029
G: dict = {"seed": SEED}

PREDICTORS = ("capacity", "actuator", "postsynaptic", "vesicle_endocytosis")
GENETIC = ("asd_sfari_hc", "asd_sfari_12", "asd_sfari_any")
TRANSCRIPTIONAL = ("asd_de", "asd_de_up", "asd_de_down")


def _j(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.floating, np.integer)):
        return x.item()
    if isinstance(x, dict):
        return {k: _j(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_j(v) for v in x]
    return x


print("[1/6] building gene table")
df = build_table(strict_disjoint=True)
df.to_csv(f"{OUT}/gene_table.csv", index=False)
G["gene_sets"] = {
    "go_terms": {a: list(t.keys()) for a, t in AXIS_TERMS.items()},
    "go_terms_labels": {a: t for a, t in AXIS_TERMS.items()},
    "control_terms": {a: t for a, t in CONTROL_TERMS.items()},
    "sizes_raw": df.attrs["set_sizes_raw"],
    "overlap_excluded_n": df.attrs["n_overlap_excluded"],
    "overlap_excluded_genes": df.attrs["overlap_genes"],
    "sizes_in_universe": {p: int(df[p].sum()) for p in PREDICTORS},
    "universe_n": int(len(df)),
}
G["outcome_counts"] = {o: int(df[o].sum()) for o in GENETIC + TRANSCRIPTIONAL}

print("[2/6] covariate balance")
bal = {}
for cov in ("loeuf", "pli", "mis_z", "log_gene_length", "log_tx_length", "gc"):
    a = df.loc[df.capacity == 1, cov].dropna()
    b = df.loc[df.actuator == 1, cov].dropna()
    u, p = mannwhitneyu(a, b) if len(a) > 5 and len(b) > 5 else (np.nan, np.nan)
    bal[cov] = {"capacity_median": float(a.median()), "actuator_median": float(b.median()),
                "capacity_n": int(len(a)), "actuator_n": int(len(b)),
                "mannwhitney_p": float(p)}
G["covariate_balance"] = bal

print("[3/6] axis contingency tests")
G["axis_contingency"] = {o: _j(axis_contingency(df, o))
                         for o in GENETIC + TRANSCRIPTIONAL}

print("[4/6] logistic enrichment vs background")
G["logistic"] = {}
for pred in PREDICTORS:
    for oc in GENETIC + TRANSCRIPTIONAL:
        G["logistic"][f"{pred}|{oc}"] = _j(logistic_enrichment(df, oc, pred))

print("[5/6] constraint- and length-matched permutation (this is the slow step)")
G["permutation"] = {}
perm_draws = {}
for pred in PREDICTORS:
    for oc in ("asd_sfari_12", "asd_de", "asd_de_down", "asd_de_up"):
        r = matched_permutation_test(df, oc, pred, n_perm=20000, seed=SEED)
        G["permutation"][f"{pred}|{oc}"] = _j(r)

# keep one null distribution per axis for plotting
for pred in ("capacity", "actuator"):
    rng = np.random.default_rng(SEED)
    sub = df[["asd_de_down", pred, "loeuf", "log_gene_length"]].dropna().copy()
    sub["bin"] = (pd.qcut(sub["loeuf"], 10, labels=False, duplicates="drop").astype(str)
                  + "_" + pd.qcut(sub["log_gene_length"], 10, labels=False,
                                  duplicates="drop").astype(str))
    tgt = sub[sub[pred] == 1]
    counts = tgt["bin"].value_counts().to_dict()
    pools = {b: g["asd_de_down"].to_numpy(float)
             for b, g in sub[sub[pred] == 0].groupby("bin")}
    null = []
    for _ in range(20000):
        vals = [rng.choice(pools[b], size=k, replace=True)
                for b, k in counts.items() if b in pools and pools[b].size]
        if vals:
            null.append(np.concatenate(vals).mean())
    perm_draws[pred] = {"null": np.asarray(null),
                        "observed": float(tgt["asd_de_down"].mean())}
pd.DataFrame({k: pd.Series(v["null"]) for k, v in perm_draws.items()}).to_csv(
    f"{OUT}/permutation_null_asd_de_down.csv", index=False)
G["permutation_observed_de_down"] = {k: v["observed"] for k, v in perm_draws.items()}

print("[6/6] direction coherence, double dissociation, per-term decomposition")
dirc = {}
allde = df[df.asd_de == 1]
bg_down = float(allde.asd_de_down.sum() / len(allde))
for pred in PREDICTORS:
    s = df[(df[pred] == 1) & (df.asd_de == 1)]
    nd, nu = int(s.asd_de_down.sum()), int(s.asd_de_up.sum())
    if nd + nu == 0:
        continue
    dirc[pred] = {
        "n_down": nd, "n_up": nu,
        "p_vs_half": float(binomtest(nd, nd + nu, 0.5).pvalue),
        "p_vs_background": float(binomtest(nd, nd + nu, bg_down).pvalue),
        "background_down_fraction": bg_down,
    }
G["direction_coherence"] = dirc

G["double_dissociation"] = {
    og: _j(double_dissociation(df, outcome_genetic=og, n_boot=20000, seed=SEED))
    for og in ("asd_sfari_12", "asd_sfari_hc")
}

go = load_go()
cache: dict = {}
uni = set(df.gene_name)
rows = []
for axis, terms in list(AXIS_TERMS.items()) + list(CONTROL_TERMS.items()):
    for t, lab in terms.items():
        g = genes_for_terms(None, go, [t], gaf_cache=cache) & uni
        if len(g) < 5:
            continue
        sub = df[df.gene_name.isin(g)]
        rows.append({"axis": axis, "go_id": t, "label": lab, "n_genes": len(g),
                     "pct_asd_de": float(sub.asd_de.mean() * 100),
                     "pct_asd_de_down": float(sub.asd_de_down.mean() * 100),
                     "pct_sfari_12": float(sub.asd_sfari_12.mean() * 100),
                     "median_loeuf": float(sub.loeuf.median())})
per_term = pd.DataFrame(rows)
per_term.to_csv(f"{OUT}/table_per_go_term.csv", index=False)
G["per_term"] = per_term.to_dict(orient="records")

print("    sensitivity: non-disjoint gene sets")
df2 = build_table(strict_disjoint=False)
G["sensitivity_nondisjoint"] = {
    "sizes": {p: int(df2[p].sum()) for p in ("capacity", "actuator")},
    "axis_contingency": {o: _j(axis_contingency(df2, o))
                         for o in ("asd_sfari_12", "asd_de", "asd_de_down")},
    "logistic": {f"{p}|{o}": _j(logistic_enrichment(df2, o, p))
                 for p in ("capacity", "actuator")
                 for o in ("asd_sfari_12", "asd_de", "asd_de_down")},
}

print("    sensitivity: leave-one-GO-term-out for the actuator axis")
loo = []
for drop in AXIS_TERMS["actuator"]:
    keep = [t for t in AXIS_TERMS["actuator"] if t != drop]
    g = genes_for_terms(None, go, keep, gaf_cache=cache)
    gcap = genes_for_terms(None, go, AXIS_TERMS["capacity"].keys(), gaf_cache=cache)
    ov = g & gcap
    tmp = df.copy()
    tmp["actuator_loo"] = tmp.gene_name.isin(g - ov).astype(int)
    r = logistic_enrichment(tmp, "asd_de_down", "actuator_loo")
    loo.append({"dropped_term": drop, "label": AXIS_TERMS["actuator"][drop],
                "n_genes": int(tmp.actuator_loo.sum()),
                "or": r["or"], "ci_lo": r["ci95"][0], "ci_hi": r["ci95"][1], "p": r["p"]})
G["sensitivity_leave_one_term_out"] = loo
pd.DataFrame(loo).to_csv(f"{OUT}/table_leave_one_term_out.csv", index=False)

with open(f"{OUT}/genomics.json", "w") as fh:
    json.dump(_j(G), fh, indent=1)
print(f"\nWrote {OUT}/genomics.json and tables.")
