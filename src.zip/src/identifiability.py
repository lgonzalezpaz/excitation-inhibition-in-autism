"""
identifiability.py
==================
Structural identifiability of presynaptic parameters from synaptic
observables, and the geometry of the homeostatic null space.

Three results are implemented.

1. Structural non-identifiability of the mean.
   The mean amplitude of the first response is mu = N * u0 * p0 * q, so the
   elasticities of log mu with respect to log N, log p0 and log q are all
   exactly 1. Any observable that is a function of the mean alone therefore
   has a Jacobian of rank 1 with respect to (log N, log p0, log q) and a
   two-dimensional null space. The excitation-inhibition ratio is such an
   observable; it cannot, even in principle, identify which presynaptic
   parameter has changed.

2. Exact Fisher information of the paired-pulse quantal count distribution.
   With all sites occupied before the first pulse, the joint distribution of
   the quantal counts (R1, R2) is exactly

     P(R1 = r1) = Binom(r1; N, p1)
     P(R2 = r2 | R1 = r1) = sum_j Binom(j; r1, rho) Binom(r2; N - r1 + j, p2)

   where rho = 1 - exp(-k_rep * dt) is the per-site refilling probability and
   p2 is the (possibly facilitated) fusion probability on the second pulse.
   The Fisher information matrix is obtained by exact enumeration, which is
   O(N^3) and therefore negligible in cost for physiological N. Rank and
   Cramer-Rao bounds follow directly, giving the number of trials needed to
   resolve a given fractional parameter change.

3. The homeostatic null space and the compensation-invariant residual.
   Let Phi(theta) be the log-scaled observable vector and let the homeostatic
   controller act only on the actuator parameters theta_A (release
   probability presynaptically, quantal size postsynaptically). The columns
   of the actuator Jacobian J_A = d Phi / d log theta_A span the subspace H
   of observable displacements that homeostasis can generate. The orthogonal
   projector

     P_perp = I - J_A (J_A^T J_A)^{-1} J_A^T

   annihilates every displacement homeostasis can produce. The residual
   r = P_perp (Phi(theta_lesion+comp) - Phi(theta_WT)) is therefore invariant
   to the amount of compensation and reports only the primary lesion.

License: MIT (see LICENSE).
"""

from __future__ import annotations

from itertools import product
from typing import Callable, Sequence

import numpy as np
from scipy.optimize import brentq
from scipy.stats import binom

from release_model import (
    SynapseParams,
    observable_vector,
    simulate_moments,
    steady_state_mean,
)

__all__ = [
    "elasticity_matrix",
    "mean_only_jacobian",
    "paired_pulse_count_pmf",
    "fisher_information_counts",
    "cramer_rao_se",
    "trials_for_detection",
    "actuator_jacobian",
    "orthogonal_projector",
    "compensate",
    "residual_fingerprint",
]

LOG_PARAMS = ("N", "p0", "k_rep", "q")


# ----------------------------------------------------------------------------
# 1. Elasticity (log-log Jacobian) matrices
# ----------------------------------------------------------------------------

def elasticity_matrix(prm: SynapseParams,
                      params: Sequence[str] = LOG_PARAMS,
                      observables: Callable[[SynapseParams], np.ndarray] | None = None,
                      h: float = 1e-4) -> np.ndarray:
    """Central-difference Jacobian d Phi / d log theta.

    Returns an array of shape (n_observables, n_params).
    """
    if observables is None:
        observables = observable_vector
    cols = []
    for name in params:
        up = prm.perturb(**{name: np.exp(h)})
        dn = prm.perturb(**{name: np.exp(-h)})
        cols.append((observables(up) - observables(dn)) / (2.0 * h))
    return np.column_stack(cols)


def mean_only_jacobian(prm: SynapseParams,
                       params: Sequence[str] = LOG_PARAMS,
                       h: float = 1e-4) -> np.ndarray:
    """Jacobian of the single observable log(mean of first response)."""
    def obs(p: SynapseParams) -> np.ndarray:
        return np.array([np.log(simulate_moments(p, [])["mean"][0])])
    return elasticity_matrix(prm, params, obs, h)


# ----------------------------------------------------------------------------
# 2. Exact paired-pulse count distribution and Fisher information
# ----------------------------------------------------------------------------

def paired_pulse_count_pmf(n_sites: int,
                           p1: float,
                           p2: float,
                           rho: float) -> np.ndarray:
    """Exact joint pmf of (R1, R2) for a paired-pulse protocol.

    Parameters
    ----------
    n_sites : int
        Integer number of release sites, all occupied before pulse 1.
    p1, p2 : float
        Fusion probabilities on pulses 1 and 2.
    rho : float
        Per-site probability of refilling during the inter-pulse interval.

    Returns
    -------
    pmf : ndarray, shape (n_sites + 1, n_sites + 1)
        pmf[r1, r2] = P(R1 = r1, R2 = r2).
    """
    n = int(n_sites)
    r_all = np.arange(n + 1)
    pmf = np.zeros((n + 1, n + 1))
    p_r1 = binom.pmf(r_all, n, p1)

    for r1 in r_all:
        if p_r1[r1] <= 0.0:
            continue
        # j of the r1 emptied sites are refilled
        j_all = np.arange(r1 + 1)
        p_j = binom.pmf(j_all, r1, rho)
        avail = (n - r1) + j_all                      # sites occupied before pulse 2
        # P(R2 = r2) = sum_j p_j * Binom(r2; avail_j, p2)
        contrib = np.zeros(n + 1)
        for j, pj in zip(j_all, p_j):
            if pj <= 0.0:
                continue
            a = int(avail[j])
            contrib[: a + 1] += pj * binom.pmf(np.arange(a + 1), a, p2)
        pmf[r1, :] = p_r1[r1] * contrib
    return pmf


def _pmf_from_params(theta_log: np.ndarray,
                     prm: SynapseParams,
                     isi: float,
                     names: Sequence[str]) -> np.ndarray:
    """Build the paired-pulse pmf at log-parameters ``theta_log``."""
    kwargs = {}
    for name, lv in zip(names, theta_log):
        kwargs[name] = float(np.exp(lv))
    p = prm
    p = type(prm)(**{**prm.as_dict(), **kwargs})
    n_round = int(round(p.N))
    rho = 1.0 - np.exp(-p.k_rep * isi)
    p1 = p.u0 * p.p0
    p_after = p.p0 + p.f * (1.0 - p.p0)
    p2 = p.p0 + (p_after - p.p0) * np.exp(-isi / p.tau_f)
    return paired_pulse_count_pmf(n_round, p1, p2, rho)


def fisher_information_counts(prm: SynapseParams,
                              isi: float = 0.050,
                              names: Sequence[str] = ("N", "p0", "k_rep"),
                              h: float = 1e-3,
                              continuous_N: bool = True) -> np.ndarray:
    """Per-trial Fisher information matrix of the paired-pulse count data.

    The expectation E[ d log P / d log theta_i * d log P / d log theta_j ] is
    evaluated by exact summation over the (N+1)^2 outcomes. ``continuous_N``
    uses a smooth binomial-coefficient continuation (via gamma functions) so
    that the derivative with respect to log N is well defined.
    """
    theta0 = np.array([np.log(float(getattr(prm, nm))) for nm in names])

    def pmf_at(tl: np.ndarray) -> np.ndarray:
        if continuous_N and "N" in names:
            return _pmf_continuous_N(tl, prm, isi, names)
        return _pmf_from_params(tl, prm, isi, names)

    p0 = pmf_at(theta0)
    n_out = p0.shape
    grads = np.zeros((len(names),) + n_out)
    for i in range(len(names)):
        tu = theta0.copy(); tu[i] += h
        td = theta0.copy(); td[i] -= h
        pu, pd = pmf_at(tu), pmf_at(td)
        ku = min(pu.shape[0], p0.shape[0]); kd = min(pd.shape[0], p0.shape[0])
        g = np.zeros(n_out)
        g[:ku, :ku] += pu[:ku, :ku]
        g[:kd, :kd] -= pd[:kd, :kd]
        grads[i] = g / (2.0 * h)

    mask = p0 > 1e-14
    fim = np.zeros((len(names), len(names)))
    for i in range(len(names)):
        for j in range(len(names)):
            fim[i, j] = np.sum(grads[i][mask] * grads[j][mask] / p0[mask])
    return fim


def _pmf_continuous_N(theta_log: np.ndarray,
                      prm: SynapseParams,
                      isi: float,
                      names: Sequence[str]) -> np.ndarray:
    """Paired-pulse pmf with a smooth continuation in N.

    The binomial coefficient is continued through the gamma function so that
    N can be differentiated. The support is truncated at ceil(N) + 4 sites,
    beyond which the mass is numerically zero for the parameter ranges used.
    """
    from scipy.special import gammaln

    kwargs = {nm: float(np.exp(lv)) for nm, lv in zip(names, theta_log)}
    p = type(prm)(**{**prm.as_dict(), **kwargs})
    nmax = int(np.ceil(p.N)) + 6
    rho = 1.0 - np.exp(-p.k_rep * isi)
    p1 = p.u0 * p.p0
    p_after = p.p0 + p.f * (1.0 - p.p0)
    p2 = p.p0 + (p_after - p.p0) * np.exp(-isi / p.tau_f)

    def cbinom(nn: float, kk: np.ndarray, pp: float) -> np.ndarray:
        kk = np.asarray(kk, dtype=float)
        ok = kk <= nn
        out = np.zeros_like(kk, dtype=float)
        lg = (gammaln(nn + 1.0) - gammaln(kk[ok] + 1.0) - gammaln(nn - kk[ok] + 1.0)
              + kk[ok] * np.log(pp) + (nn - kk[ok]) * np.log1p(-pp))
        out[ok] = np.exp(lg)
        return out

    r_all = np.arange(nmax + 1)
    p_r1 = cbinom(p.N, r_all, p1)
    p_r1 = p_r1 / p_r1.sum()
    pmf = np.zeros((nmax + 1, nmax + 1))
    for r1 in r_all:
        if p_r1[r1] <= 1e-16:
            continue
        j_all = np.arange(r1 + 1)
        p_j = binom.pmf(j_all, r1, rho)
        contrib = np.zeros(nmax + 1)
        for j, pj in zip(j_all, p_j):
            if pj <= 1e-16:
                continue
            a = p.N - r1 + j
            kk = np.arange(nmax + 1)
            bb = cbinom(a, kk, p2)
            s = bb.sum()
            if s > 0:
                contrib += pj * bb / s
        pmf[r1, :] = p_r1[r1] * contrib
    return pmf / pmf.sum()


def cramer_rao_se(fim: np.ndarray, n_trials: int) -> np.ndarray:
    """Cramer-Rao lower bounds on the standard errors of log-parameters."""
    cov = np.linalg.pinv(fim * float(n_trials))
    return np.sqrt(np.diag(cov))


def trials_for_detection(fim: np.ndarray,
                         index: int,
                         frac_change: float,
                         alpha: float = 0.05,
                         power: float = 0.80) -> float:
    """Trials per group needed to detect a fractional change in one parameter.

    Two-sample, two-sided Wald test on the log-parameter, assuming the
    Cramer-Rao bound is attained. ``frac_change`` is the relative change
    (e.g. 0.20 for a 20 % reduction).
    """
    from scipy.stats import norm
    effect = abs(np.log1p(-abs(frac_change)))
    var1 = np.linalg.pinv(fim)[index, index]
    z_a = norm.ppf(1.0 - alpha / 2.0)
    z_b = norm.ppf(power)
    return 2.0 * var1 * (z_a + z_b) ** 2 / effect ** 2


# ----------------------------------------------------------------------------
# 3. Homeostatic null space
# ----------------------------------------------------------------------------

def actuator_jacobian(prm: SynapseParams,
                      actuators: Sequence[str] = ("p0", "q"),
                      **kw) -> np.ndarray:
    """Jacobian of the observable vector with respect to actuator parameters."""
    return elasticity_matrix(prm, actuators, **kw)


def orthogonal_projector(j_a: np.ndarray) -> np.ndarray:
    """Projector onto the orthogonal complement of the column space of J_A."""
    q, _ = np.linalg.qr(j_a)
    return np.eye(j_a.shape[0]) - q @ q.T


def compensate(prm_lesion: SynapseParams,
               target: float,
               actuator: str = "p0",
               control_variable: str = "mean_ss",
               rate_ss: float = 20.0,
               bounds: tuple[float, float] = (1e-3, 1e3)) -> SynapseParams | None:
    """Scale one actuator so the controlled variable returns to ``target``.

    ``control_variable`` is either 'mean_ss' (steady-state mean amplitude
    during a reference train, i.e. mean synaptic drive during activity) or
    'mean_1' (mean amplitude of an isolated response).

    Returns None when the target is unreachable within ``bounds`` (for
    example when the actuator saturates because p0 cannot exceed 1).
    """
    def controlled(p: SynapseParams) -> float:
        if control_variable == "mean_ss":
            return steady_state_mean(p, rate_ss)
        return simulate_moments(p, [])["mean"][0]

    def gap(scale: float) -> float:
        cand = prm_lesion.perturb(**{actuator: scale})
        if actuator == "p0" and cand.p0 >= 1.0:
            return np.inf
        return controlled(cand) - target

    lo, hi = bounds
    if actuator == "p0":
        hi = min(hi, 0.999 / prm_lesion.p0)
    try:
        g_lo, g_hi = gap(lo), gap(hi)
    except Exception:
        return None
    if not np.isfinite(g_lo) or not np.isfinite(g_hi) or g_lo * g_hi > 0:
        return None
    scale = brentq(gap, lo, hi, xtol=1e-12, rtol=1e-13, maxiter=500)
    return prm_lesion.perturb(**{actuator: scale})


def residual_fingerprint(prm_wt: SynapseParams,
                         lesion: dict,
                         actuator: str = "p0",
                         control_variable: str = "mean_ss",
                         rate_ss: float = 20.0,
                         isi_ppr: float = 0.050) -> dict:
    """Full lesion-then-compensate pipeline and the resulting residual.

    Returns a dictionary with the raw observable displacement before and
    after compensation, the projected (compensation-invariant) residual, and
    the two experimentally routine coordinates d log CV^2 and d log PPR.
    """
    phi_wt = observable_vector(prm_wt, isi_ppr=isi_ppr, rate_ss=rate_ss)
    target = steady_state_mean(prm_wt, rate_ss) if control_variable == "mean_ss" \
        else simulate_moments(prm_wt, [])["mean"][0]

    prm_les = prm_wt.perturb(**lesion)
    phi_les = observable_vector(prm_les, isi_ppr=isi_ppr, rate_ss=rate_ss)

    prm_cmp = compensate(prm_les, target, actuator=actuator,
                         control_variable=control_variable, rate_ss=rate_ss)
    if prm_cmp is None:
        return {"compensated": False, "lesion": lesion, "actuator": actuator,
                "d_phi_lesion": phi_les - phi_wt}

    phi_cmp = observable_vector(prm_cmp, isi_ppr=isi_ppr, rate_ss=rate_ss)
    j_a = actuator_jacobian(prm_wt, actuators=(actuator,))
    proj = orthogonal_projector(j_a)
    d_phi = phi_cmp - phi_wt
    return {
        "compensated": True,
        "lesion": lesion,
        "actuator": actuator,
        "params_wt": prm_wt,
        "params_lesion": prm_les,
        "params_compensated": prm_cmp,
        "d_phi_lesion": phi_les - phi_wt,
        "d_phi_compensated": d_phi,
        "residual_projected": proj @ d_phi,
        "residual_norm": float(np.linalg.norm(proj @ d_phi)),
        "d_log_cv2": float(d_phi[1]),
        "d_log_ppr": float(d_phi[2]),
        "actuator_scale": float(getattr(prm_cmp, actuator) / getattr(prm_les, actuator)),
    }
