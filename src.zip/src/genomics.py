"""
genomics.py
===========
Independent validation of the framework against real public human data.

Prediction under test
---------------------
The framework separates presynaptic parameters into a *capacity* axis
(the number of release sites and the rate at which they are resupplied,
set by active-zone scaffolding, vesicle docking, priming and recycling)
and an *actuator* axis (the per-site fusion probability, set by
voltage-gated Ca2+ entry, the Ca2+ sensor and presynaptic modulation of
release). The analysis of the model gives two structural results:

  * a lesion on the actuator axis that is compensated on the same axis is
    erased exactly, leaving no residual in any release statistic;
  * a lesion on the capacity axis can never be erased by a mean-restoring
    controller.

If idiopathic autism involves a primary presynaptic lesion that is then
partially compensated, these results predict a double dissociation in human
data:

  (H1) inherited and de novo risk for autism should concentrate on
       capacity-axis genes rather than actuator-axis genes, because only
       non-compensable lesions produce a persistent phenotype;
  (H2) the transcriptional response measured in autistic cortex should
       concentrate on actuator-axis genes, because those are the genes a
       compensatory mechanism must mobilise.

The two gene sets act as each other's control: both are presynaptic, both
are brain-enriched and both have comparable length and expression
distributions, so the axis-by-outcome interaction is robust to the
confounders that afflict any single enrichment test. Enrichment against the
genome background is reported as a secondary analysis with explicit
adjustment for coding constraint and gene length, and with
constraint-matched permutation.

Data sources (all public, no registration)
------------------------------------------
* Gene Ontology annotations and ontology, current release
  https://current.geneontology.org/annotations/goa_human.gaf.gz
  https://current.geneontology.org/ontology/go-basic.obo
* gnomAD v4.1 gene constraint metrics
  https://storage.googleapis.com/gcp-public-data--gnomad/release/4.1/constraint/gnomad.v4.1.constraint_metrics.tsv
* SFARI Gene human gene module (gene scores)
  https://gene.sfari.org/database/human-gene/
* PsychENCODE cross-disorder differential expression (DER-13) and the
  analysed gene universe with gene-level covariates (DER-16)
  http://resource.psychencode.org/

License: MIT (see LICENSE).
"""

from __future__ import annotations

import csv
import gzip
import os
from collections import defaultdict
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

DATA_DIR = os.environ.get("VESICLE_DATA_DIR", "../data")

__all__ = [
    "AXIS_TERMS", "CONTROL_TERMS",
    "load_go", "propagate", "genes_for_terms",
    "load_universe", "load_constraint", "load_sfari", "load_asd_de",
    "build_table", "axis_contingency", "logistic_enrichment",
    "matched_permutation_test", "double_dissociation",
]


# ----------------------------------------------------------------------------
# Pre-specified Gene Ontology terms defining the two model axes
# ----------------------------------------------------------------------------
# Each term is chosen because it maps onto a single parameter of the release
# model. Terms are fixed before any association test is run.

AXIS_TERMS: dict[str, dict[str, str]] = {
    "capacity": {
        # number of release sites N: active-zone structure and scaffolding
        "GO:0048786": "presynaptic active zone",
        "GO:0098831": "presynaptic active zone cytoplasmic component",
        "GO:0098882": "structural constituent of presynaptic active zone",
        "GO:1904071": "presynaptic active zone assembly",
        "GO:0048790": "maintenance of presynaptic active zone structure",
        "GO:0048789": "cytoskeletal matrix organization at active zone",
        "GO:0031629": "synaptic vesicle fusion to presynaptic active zone membrane",
        # replenishment rate k_rep: priming, recycling, pool maintenance
        "GO:0016082": "synaptic vesicle priming",
        "GO:0010807": "regulation of synaptic vesicle priming",
        "GO:0036465": "synaptic vesicle recycling",
        "GO:0016188": "synaptic vesicle maturation",
        "GO:0097091": "synaptic vesicle clustering",
        "GO:1990474": "synaptic vesicle, readily releasable pool",
    },
    "actuator": {
        # fusion probability p: presynaptic Ca2+ entry
        "GO:0099626": "voltage-gated calcium channel activity, presynaptic Ca levels",
        "GO:0099635": "voltage-gated calcium channel activity, positive reg. presynaptic Ca",
        "GO:0099509": "regulation of presynaptic cytosolic calcium ion concentration",
        "GO:0099533": "positive regulation of presynaptic cytosolic calcium concentration",
        "GO:0099113": "negative regulation of presynaptic cytosolic calcium concentration",
        "GO:0099534": "calcium ion binding, reg. presynaptic cytosolic calcium",
        "GO:0099585": "release of sequestered calcium ion into presynaptic cytosol",
        # fusion probability p: Ca2+ sensing and its regulation
        "GO:0099502": "calcium-dependent activation of synaptic vesicle fusion",
        "GO:0150037": "regulation of calcium-dependent activation of synaptic vesicle fusion",
        # fusion probability p: presynaptic modulation and excitability
        "GO:0099171": "presynaptic modulation of chemical synaptic transmission",
        "GO:0099505": "regulation of presynaptic membrane potential",
        "GO:1903233": "regulation of calcium ion-dependent exocytosis of neurotransmitter",
        "GO:0046928": "regulation of neurotransmitter secretion",
    },
}

CONTROL_TERMS: dict[str, dict[str, str]] = {
    "postsynaptic": {
        "GO:0098794": "postsynapse",
        "GO:0014069": "postsynaptic density",
    },
    "vesicle_endocytosis": {
        "GO:0048488": "synaptic vesicle endocytosis",
        "GO:0016191": "synaptic vesicle uncoating",
    },
}


# ----------------------------------------------------------------------------
# Gene Ontology
# ----------------------------------------------------------------------------

def load_go(obo_path: str | None = None) -> dict:
    """Parse go-basic.obo and return parents, names and namespaces."""
    obo_path = obo_path or os.path.join(DATA_DIR, "go-basic.obo")
    parents: dict[str, set[str]] = defaultdict(set)
    names: dict[str, str] = {}
    namespaces: dict[str, str] = {}
    alt_to_main: dict[str, str] = {}

    cur = None
    obsolete = False
    with open(obo_path) as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if line == "[Term]":
                cur, obsolete = {"id": None}, False
            elif line.startswith("[") and line != "[Term]":
                cur = None
            elif cur is None:
                continue
            elif line.startswith("id: GO:") and cur.get("id") is None:
                cur["id"] = line[4:]
            elif line.startswith("name: "):
                names[cur["id"]] = line[6:]
            elif line.startswith("namespace: "):
                namespaces[cur["id"]] = line[11:]
            elif line.startswith("alt_id: GO:"):
                alt_to_main[line[8:]] = cur["id"]
            elif line.startswith("is_obsolete: true"):
                obsolete = True
            elif line.startswith("is_a: GO:") and not obsolete:
                parents[cur["id"]].add(line[6:16])
            elif line.startswith("relationship: part_of GO:") and not obsolete:
                parents[cur["id"]].add(line[22:32])
    return {"parents": dict(parents), "names": names,
            "namespaces": namespaces, "alt_to_main": alt_to_main}


def _descendants(go: dict, roots: Iterable[str]) -> set[str]:
    """All terms whose ancestor closure contains any of ``roots``."""
    children: dict[str, set[str]] = defaultdict(set)
    for child, pars in go["parents"].items():
        for par in pars:
            children[par].add(child)
    out: set[str] = set()
    stack = list(roots)
    while stack:
        t = stack.pop()
        if t in out:
            continue
        out.add(t)
        stack.extend(children.get(t, ()))
    return out


def propagate(go: dict, terms: Iterable[str]) -> set[str]:
    """Expand a set of terms to include all of their descendants."""
    return _descendants(go, list(terms))


def genes_for_terms(gaf_path: str | None,
                    go: dict,
                    terms: Iterable[str],
                    evidence_exclude: Sequence[str] = ("ND",),
                    gaf_cache: dict | None = None) -> set[str]:
    """Human gene symbols annotated to any descendant of ``terms``.

    Annotations qualified with NOT are discarded, as are annotations with the
    excluded evidence codes. Annotations are propagated up the ontology by
    expanding the query terms to their full descendant set, which is
    equivalent and much cheaper than propagating every gene annotation.
    """
    wanted = propagate(go, terms)
    if gaf_cache is not None and "rows" in gaf_cache:
        rows = gaf_cache["rows"]
    else:
        path = gaf_path or os.path.join(DATA_DIR, "goa_human.gaf.gz")
        rows = []
        with gzip.open(path, "rt") as fh:
            for line in fh:
                if line.startswith("!"):
                    continue
                f = line.rstrip("\n").split("\t")
                if len(f) < 15:
                    continue
                rows.append((f[2], f[3], f[4], f[6]))  # symbol, qualifier, go_id, evidence
        if gaf_cache is not None:
            gaf_cache["rows"] = rows

    out = set()
    for symbol, qualifier, go_id, evidence in rows:
        if "NOT" in qualifier:
            continue
        if evidence in evidence_exclude:
            continue
        gid = go["alt_to_main"].get(go_id, go_id)
        if gid in wanted:
            out.add(symbol)
    return out


# ----------------------------------------------------------------------------
# Human datasets
# ----------------------------------------------------------------------------

def load_universe(path: str | None = None) -> pd.DataFrame:
    """PsychENCODE analysed gene universe with gene-level covariates."""
    path = path or os.path.join(DATA_DIR, "DER-16_Disorder_Gene_Modules.csv")
    use = ["ensembl_gene_id", "gene_name", "gene_type", "chr",
           "transcript_length", "gene_length", "percentage_gene_gc_content"]
    df = pd.read_csv(path, usecols=use, low_memory=False)
    df = df[df["gene_type"] == "protein_coding"].copy()
    df["gene_name"] = df["gene_name"].astype(str)
    return df.drop_duplicates(subset="gene_name")


def load_constraint(path: str | None = None) -> pd.DataFrame:
    """gnomAD v4.1 constraint: LOEUF, pLI and missense z for canonical MANE."""
    path = path or os.path.join(DATA_DIR, "gnomad_v4.1_constraint.tsv")
    cols = ["gene", "mane_select", "canonical",
            "lof.oe_ci.upper", "lof.pLI", "mis.z_score", "lof.obs", "lof.exp"]
    df = pd.read_csv(path, sep="\t", usecols=cols, low_memory=False)
    for flag in ("mane_select", "canonical"):
        df[flag] = df[flag].astype(str).str.lower().isin(("true", "1", "yes"))
    sel = df[df["mane_select"]]
    if sel["gene"].nunique() < 15000:
        sel = pd.concat([sel, df[df["canonical"] & ~df["gene"].isin(sel["gene"])]])
    sel = sel.rename(columns={"gene": "gene_name",
                              "lof.oe_ci.upper": "loeuf",
                              "lof.pLI": "pli",
                              "mis.z_score": "mis_z"})
    return sel[["gene_name", "loeuf", "pli", "mis_z"]].drop_duplicates("gene_name")


def load_sfari(path: str | None = None) -> pd.DataFrame:
    """SFARI Gene scores. Score 1 is the highest-confidence category."""
    path = path or os.path.join(DATA_DIR, "sfari_genes.csv")
    df = pd.read_csv(path)
    df = df.rename(columns={"gene-symbol": "gene_name", "gene-score": "sfari_score",
                            "syndromic": "sfari_syndromic",
                            "number-of-reports": "sfari_reports"})
    df["sfari_score"] = pd.to_numeric(df["sfari_score"], errors="coerce")
    return df[["gene_name", "sfari_score", "sfari_syndromic", "sfari_reports"]]\
        .drop_duplicates("gene_name")


def load_asd_de(path: str | None = None) -> pd.DataFrame:
    """PsychENCODE DER-13 differentially expressed genes, by disorder."""
    path = path or os.path.join(DATA_DIR, "DER-13_Disorder_DEX_Genes.csv")
    df = pd.read_csv(path)
    df.columns = ["gene_name", "ensembl_gene_id", "call"]
    df["disorder"] = df["call"].str.split(".").str[0]
    df["direction"] = df["call"].str.split("_").str[-1]
    asd = df[df["disorder"] == "ASD"].copy()
    return asd[["gene_name", "direction"]].drop_duplicates("gene_name")


# ----------------------------------------------------------------------------
# Analysis table
# ----------------------------------------------------------------------------

def build_table(strict_disjoint: bool = True) -> pd.DataFrame:
    """Assemble the per-gene analysis table."""
    go = load_go()
    cache: dict = {}
    sets = {}
    for axis, terms in AXIS_TERMS.items():
        sets[axis] = genes_for_terms(None, go, terms.keys(), gaf_cache=cache)
    for name, terms in CONTROL_TERMS.items():
        sets[name] = genes_for_terms(None, go, terms.keys(), gaf_cache=cache)

    overlap = sets["capacity"] & sets["actuator"]
    if strict_disjoint:
        cap = sets["capacity"] - overlap
        act = sets["actuator"] - overlap
    else:
        cap, act = sets["capacity"], sets["actuator"]

    uni = load_universe()
    con = load_constraint()
    sfari = load_sfari()
    de = load_asd_de()

    df = uni.merge(con, on="gene_name", how="left") \
            .merge(sfari, on="gene_name", how="left") \
            .merge(de, on="gene_name", how="left")

    df["capacity"] = df["gene_name"].isin(cap).astype(int)
    df["actuator"] = df["gene_name"].isin(act).astype(int)
    df["postsynaptic"] = df["gene_name"].isin(sets["postsynaptic"]).astype(int)
    df["vesicle_endocytosis"] = df["gene_name"].isin(sets["vesicle_endocytosis"]).astype(int)

    df["asd_sfari_any"] = df["sfari_score"].notna().astype(int)
    df["asd_sfari_hc"] = (df["sfari_score"] <= 1).fillna(False).astype(int)
    df["asd_sfari_12"] = (df["sfari_score"] <= 2).fillna(False).astype(int)
    df["asd_de"] = df["direction"].notna().astype(int)
    df["asd_de_up"] = (df["direction"] == "up").astype(int)
    df["asd_de_down"] = (df["direction"] == "down").astype(int)

    df["log_gene_length"] = np.log10(pd.to_numeric(df["gene_length"], errors="coerce"))
    df["log_tx_length"] = np.log10(pd.to_numeric(df["transcript_length"], errors="coerce"))
    df["gc"] = pd.to_numeric(df["percentage_gene_gc_content"], errors="coerce")

    df.attrs["n_overlap_excluded"] = len(overlap)
    df.attrs["overlap_genes"] = sorted(overlap)
    df.attrs["set_sizes_raw"] = {k: len(v) for k, v in sets.items()}
    return df


# ----------------------------------------------------------------------------
# Tests
# ----------------------------------------------------------------------------

def axis_contingency(df: pd.DataFrame, outcome: str) -> dict:
    """Two-by-two table comparing the two axes on one outcome."""
    from scipy.stats import fisher_exact
    sub = df[(df["capacity"] == 1) | (df["actuator"] == 1)]
    cap = sub[sub["capacity"] == 1][outcome]
    act = sub[sub["actuator"] == 1][outcome]
    table = np.array([[int(cap.sum()), int((1 - cap).sum())],
                      [int(act.sum()), int((1 - act).sum())]])
    odds, p = fisher_exact(table)
    # Haldane-Anscombe corrected log odds ratio and its standard error
    t = table + 0.5
    lor = np.log((t[0, 0] * t[1, 1]) / (t[0, 1] * t[1, 0]))
    se = np.sqrt((1.0 / t).sum())
    return {"outcome": outcome, "table": table,
            "n_capacity": int(len(cap)), "n_actuator": int(len(act)),
            "frac_capacity": float(cap.mean()), "frac_actuator": float(act.mean()),
            "odds_ratio": float(odds), "p_fisher": float(p),
            "log_or": float(lor), "log_or_se": float(se),
            "ci95": (float(np.exp(lor - 1.96 * se)), float(np.exp(lor + 1.96 * se)))}


def logistic_enrichment(df: pd.DataFrame, outcome: str, predictor: str,
                        covariates: Sequence[str] = ("loeuf", "log_gene_length",
                                                     "log_tx_length", "gc")) -> dict:
    """Logistic regression of an outcome on axis membership plus covariates."""
    import statsmodels.api as sm
    cols = [outcome, predictor, *covariates]
    sub = df[cols].dropna()
    y = sub[outcome].to_numpy(dtype=float)
    x = sm.add_constant(sub[[predictor, *covariates]].to_numpy(dtype=float))
    model = sm.Logit(y, x).fit(disp=0, maxiter=200)
    idx = 1
    return {"outcome": outcome, "predictor": predictor, "n": int(len(sub)),
            "beta": float(model.params[idx]), "se": float(model.bse[idx]),
            "or": float(np.exp(model.params[idx])),
            "ci95": (float(np.exp(model.conf_int()[idx][0])),
                     float(np.exp(model.conf_int()[idx][1]))),
            "p": float(model.pvalues[idx]),
            "covariates": list(covariates)}


def matched_permutation_test(df: pd.DataFrame, outcome: str, predictor: str,
                             n_perm: int = 20000, n_bins: int = 10,
                             seed: int = 0) -> dict:
    """Permutation test with background matched on constraint and gene length.

    The null distribution is built by resampling gene sets of the same size
    from the same joint deciles of LOEUF and log gene length, so that the
    test cannot be driven by the well-known tendency of long, constrained
    genes to appear in disease gene lists.
    """
    rng = np.random.default_rng(seed)
    sub = df[[outcome, predictor, "loeuf", "log_gene_length"]].dropna().copy()
    sub["bin"] = (pd.qcut(sub["loeuf"], n_bins, labels=False, duplicates="drop").astype(str)
                  + "_" +
                  pd.qcut(sub["log_gene_length"], n_bins, labels=False, duplicates="drop").astype(str))

    target = sub[sub[predictor] == 1]
    obs = float(target[outcome].mean())
    counts = target["bin"].value_counts().to_dict()
    pools = {b: g[outcome].to_numpy(dtype=float)
             for b, g in sub[sub[predictor] == 0].groupby("bin")}

    null = np.empty(n_perm)
    for i in range(n_perm):
        vals = []
        for b, k in counts.items():
            pool = pools.get(b)
            if pool is None or pool.size == 0:
                continue
            vals.append(rng.choice(pool, size=k, replace=True))
        null[i] = np.concatenate(vals).mean() if vals else np.nan

    null = null[np.isfinite(null)]
    p_hi = (1.0 + np.sum(null >= obs)) / (1.0 + null.size)
    p_lo = (1.0 + np.sum(null <= obs)) / (1.0 + null.size)
    return {"outcome": outcome, "predictor": predictor,
            "observed": obs, "null_mean": float(null.mean()),
            "null_sd": float(null.std(ddof=1)),
            "enrichment": float(obs / null.mean()) if null.mean() > 0 else np.nan,
            "p_two_sided": float(min(1.0, 2.0 * min(p_hi, p_lo))),
            "n_target": int(len(target)), "n_perm": int(null.size)}


def double_dissociation(df: pd.DataFrame,
                        outcome_genetic: str = "asd_sfari_12",
                        outcome_transcriptional: str = "asd_de",
                        n_boot: int = 20000, seed: int = 0) -> dict:
    """Formal test of the predicted axis-by-outcome interaction.

    The contrast is
        Delta = [log OR(capacity vs actuator | genetic risk)]
              - [log OR(capacity vs actuator | transcriptional change)]
    A positive Delta means genetic risk is shifted towards the capacity axis
    relative to the transcriptional response, which is the prediction. The
    confidence interval is obtained by a stratified bootstrap over genes,
    which respects the fact that the same genes contribute to both outcomes.
    """
    rng = np.random.default_rng(seed)
    sub = df[(df["capacity"] == 1) | (df["actuator"] == 1)][
        ["capacity", "actuator", outcome_genetic, outcome_transcriptional]].copy()

    def log_or(d: pd.DataFrame, outcome: str) -> float:
        c = d[d["capacity"] == 1][outcome]
        a = d[d["actuator"] == 1][outcome]
        t = np.array([[c.sum(), len(c) - c.sum()],
                      [a.sum(), len(a) - a.sum()]], dtype=float) + 0.5
        return float(np.log((t[0, 0] * t[1, 1]) / (t[0, 1] * t[1, 0])))

    obs_g = log_or(sub, outcome_genetic)
    obs_t = log_or(sub, outcome_transcriptional)
    obs_d = obs_g - obs_t

    cap_idx = np.flatnonzero(sub["capacity"].to_numpy() == 1)
    act_idx = np.flatnonzero(sub["actuator"].to_numpy() == 1)
    boot = np.empty(n_boot)
    for i in range(n_boot):
        pick = np.concatenate([rng.choice(cap_idx, cap_idx.size, replace=True),
                               rng.choice(act_idx, act_idx.size, replace=True)])
        d = sub.iloc[pick]
        boot[i] = log_or(d, outcome_genetic) - log_or(d, outcome_transcriptional)

    p = (1.0 + np.sum(boot <= 0.0)) / (1.0 + n_boot)
    return {"log_or_genetic": obs_g, "log_or_transcriptional": obs_t,
            "delta": obs_d,
            "delta_ci95": (float(np.percentile(boot, 2.5)),
                           float(np.percentile(boot, 97.5))),
            "p_one_sided_delta_gt_0": float(p),
            "or_genetic": float(np.exp(obs_g)),
            "or_transcriptional": float(np.exp(obs_t))}
