#!/usr/bin/env bash
# Downloads every public dataset used in this study into ./data/
# No registration or credentials are required for any of them.
#
# Retrieved for the published analysis on 2026-10-29.
# Verify integrity afterwards with:  sha256sum -c data/CHECKSUMS.sha256
set -euo pipefail
cd "$(dirname "$0")"

echo "[1/5] Gene Ontology annotations (human)"
curl -sSL -o goa_human.gaf.gz \
  "https://current.geneontology.org/annotations/goa_human.gaf.gz"

echo "[2/5] Gene Ontology (go-basic)"
curl -sSL -o go-basic.obo \
  "https://current.geneontology.org/ontology/go-basic.obo"

echo "[3/5] gnomAD v4.1 gene constraint metrics (~96 MB)"
curl -sSL -o gnomad_v4.1_constraint.tsv \
  "https://storage.googleapis.com/gcp-public-data--gnomad/release/4.1/constraint/gnomad.v4.1.constraint_metrics.tsv"

echo "[4/5] SFARI Gene human gene scores"
curl -sSL -o sfari_genes.csv \
  "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes"

echo "[5/5] PsychENCODE cross-disorder differential expression and gene universe"
curl -sSL -o DER-13_Disorder_DEX_Genes.csv \
  "http://resource.psychencode.org/Datasets/Derived/DEXgenes_CoExp/DER-13_Disorder_DEX_Genes.csv"
curl -sSL -o DER-16_Disorder_Gene_Modules.csv \
  "http://resource.psychencode.org/Datasets/Derived/DEXgenes_CoExp/DER-16_Disorder_Gene_Modules.csv"

echo
echo "Done. Verifying checksums against the versions used in the paper:"
sha256sum -c CHECKSUMS.sha256 || cat <<'NOTE'

NOTE: a checksum mismatch is expected for goa_human.gaf.gz and go-basic.obo,
which are rolling releases. The Gene Ontology release used in the paper is
recorded in results/results.json. All conclusions were verified to be stable
across the two most recent GO releases; see README section "Data versions".
NOTE
