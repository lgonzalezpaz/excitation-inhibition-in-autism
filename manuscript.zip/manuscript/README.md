# Manuscript files

| File | What it is |
|---|---|
| `manuscript.docx` | **Submission-ready Word document.** A4, 2.54 cm margins, Times New Roman, double-spaced black body text, 16 pt bold title, continuous line numbers in the left margin, page numbers top right. All 15 equations are native Office Math objects and remain editable; there are no equation images. |
| `manuscript.md` | Source with citation keys, before numbering. Edit this one. |
| `manuscript_final.md` | Generated: citations resolved to Vancouver numbers in order of first appearance. |
| `references_numbered.md` | Generated: the numbered reference list alone. |
| `refs_verified.json` | Every reference with the author list, journal, volume, pages, year and DOI as retrieved from Crossref and PubMed. `build_manuscript.py` refuses to build if a cited key is missing from this file. |

Figures are in `../figs/` as vector PDF and 600 dpi PNG, and are referenced in the
text by `[Figure N near here]` placement markers. Tables are embedded in the
manuscript under "Tables", and figure captions under "Figure captions".

To rebuild after editing `manuscript.md`:

```bash
export PYTHONPATH=../src VESICLE_RESULTS_DIR=../results VESICLE_MS_DIR=.
python ../src/build_tables.py       # regenerate tables from the result files
python ../src/build_manuscript.py   # resolve citations
python ../src/build_docx.py         # produce the Word file
```
