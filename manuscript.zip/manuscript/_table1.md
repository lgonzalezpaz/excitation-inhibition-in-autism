| Synapse | Parameter | Value | Status | Source | Note |
|---|---|---|---|---|---|
| Excitatory, neocortical L5 to L5 | release sites N | 5.500 | measured | Markram et al. 1997 | 5.5 +/- 1.1 anatomical contacts per connection (n=19) |
| Excitatory, neocortical L5 to L5 | fusion probability p | 0.460 | measured | Loebel et al. 2009 | utilisation parameter U = 0.46 +/- 0.1 (n=20) |
| Excitatory, neocortical L5 to L5 | resupply rate k_rep (s^-1) | 1.905 | derived | Loebel et al. 2009 | 1/tau_rec with tau_rec = 525 +/- 134 ms |
| Excitatory, neocortical L5 to L5 | quantal CV | 0.370 | measured | Silver et al. 1998 | quantal CV 0.37 +/- 0.01 by direct resolution |
| Excitatory, neocortical L5 to L5 | facilitation increment f | 0.000 | excluded | not measured | no independent measurement; set to zero |
| Excitatory, Schaffer collateral to CA1 | release sites N | 3.000 | measured | Dürst et al. 2022 | median 3 release sites, IQR 2-4 (n=27 boutons) |
| Excitatory, Schaffer collateral to CA1 | fusion probability p | 0.519 | derived | Dürst et al. 2022; Lou et al. 2005 | Hill curve through p=0.08 at 1 mM and p=0.79 at 4 mM with m=4, evaluated at 2 mM |
| Excitatory, Schaffer collateral to CA1 | resupply rate k_rep (s^-1) | 1.905 | substituted | Loebel et al. 2009 | not measured at CA3-CA1; neocortical value used, flagged in the text |
| Excitatory, Schaffer collateral to CA1 | quantal CV | 0.370 | measured | Silver et al. 1998 | quantal CV 0.37 +/- 0.01 |
| Excitatory, Schaffer collateral to CA1 | facilitation increment f | 0.000 | excluded | not measured | no independent measurement; set to zero |
| Inhibitory, basket cell to granule cell | release sites N | 5.000 | measured | Kraushaar & Jonas 2000 | 3-7 release sites; midpoint used |
| Inhibitory, basket cell to granule cell | fusion probability p | 0.500 | measured | Kraushaar & Jonas 2000 | about 0.5 per site at 2 mM Ca2+ |
| Inhibitory, basket cell to granule cell | resupply rate k_rep (s^-1) | 0.500 | derived | Kraushaar & Jonas 2000 | 1/tau with recovery tau = 2 s |
| Inhibitory, basket cell to granule cell | quantal CV | 0.370 | substituted | Silver et al. 1998 | no inhibitory quantal CV retrieved |
| Inhibitory, basket cell to granule cell | facilitation increment f | 0.283 | calibrated | Kraushaar & Jonas 2000 | fitted to 37 % paired-pulse depression at a 10 ms interval |
