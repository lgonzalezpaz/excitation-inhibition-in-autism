1. Rubenstein JLR, Merzenich MM. Model of autism: increased ratio of excitation/inhibition in key neural systems. Genes Brain Behav. 2003;2:255-267. doi:10.1034/j.1601-183X.2003.00037.x
2. Bozzi Y, Provenzano G, Casarosa S. Neurobiological bases of autism–epilepsy comorbidity: a focus on excitation/inhibition imbalance. Eur J Neurosci. 2018;47:534-548. doi:10.1111/ejn.13595
3. Specchio N, Di Micco V, Trivisano M, Ferretti A, Curatolo P. The epilepsy–autism spectrum disorder phenotype in the era of molecular genetics and precision therapy. Epilepsia. 2022;63:6-21. doi:10.1111/epi.17115
4. Contractor A, Ethell IM, Portera-Cailliau C. Cortical interneurons in autism. Nat Neurosci. 2021;24:1648-1659. doi:10.1038/s41593-021-00967-6
5. Sohal VS, Rubenstein JLR. Excitation-inhibition balance as a framework for investigating mechanisms in neuropsychiatric disorders. Mol Psychiatry. 2019;24:1248-1257. doi:10.1038/s41380-019-0426-0
6. Nelson SB, Valakh V. Excitatory/Inhibitory Balance and Circuit Homeostasis in Autism Spectrum Disorders. Neuron. 2015;87:684-698. doi:10.1016/j.neuron.2015.07.033
7. Noel JP, Angelaki DE. A theory of autism bridging across levels of description. Trends Cogn Sci. 2023;27:631-641. doi:10.1016/j.tics.2023.04.010
8. Avramiea AE, Juarez-Martinez EL, Garcés P, Hipp JF, Poil SS, Diachenko M, et al. Qualitative EEG abnormalities in ASD reflect inhibition-dominated brain dynamics. Sci Rep. 2026;16:16055. doi:10.1038/s41598-026-42120-y
9. Antoine MW, Langberg T, Schnepel P, Feldman DE. Increased Excitation-Inhibition Ratio Stabilizes Synapse and Circuit Excitability in Four Autism Mouse Models. Neuron. 2019;101:648-661.e4. doi:10.1016/j.neuron.2018.12.026
10. Luo Y, Wang L, Cao Y, Shen Y, Gu Y, Wang L. Reduced excitatory activity in the developing mPFC mediates a PVH-to-PVL transition and impaired social cognition in autism spectrum disorders. Transl Psychiatry. 2024;14:325. doi:10.1038/s41398-024-03043-2
11. Arutiunian V, Sullivan CAW, Santhosh M, Neuhaus E, Borland H, Bernier RA, et al. Excitation/inhibition balance subtypes in autism and their genetic, neural, and clinical profiles. J Neural Transm (Vienna). 2026. doi:10.1007/s00702-026-03283-0
12. del Castillo J, Katz B. Quantal components of the end‐plate potential. J Physiol. 1954;124:560-573. doi:10.1113/jphysiol.1954.sp005129
13. Katz B, Miledi R. The role of calcium in neuromuscular facilitation. J Physiol. 1968;195:481-492. doi:10.1113/jphysiol.1968.sp008469
14. Turrigiano GG, Leslie KR, Desai NS, Rutherford LC, Nelson SB. Activity-dependent scaling of quantal amplitude in neocortical neurons. Nature. 1998;391:892-896. doi:10.1038/36103
15. Marder E, Goaillard JM. Variability, compensation and homeostasis in neuron and network function. Nat Rev Neurosci. 2006;7:563-574. doi:10.1038/nrn1949
16. Gutenkunst RN, Waterfall JJ, Casey FP, Brown KS, Myers CR, Sethna JP. Universally Sloppy Parameter Sensitivities in Systems Biology Models. PLoS Comput Biol. 2007;3:e189. doi:10.1371/journal.pcbi.0030189
17. Raue A, Kreutz C, Maiwald T, Bachmann J, Schilling M, Klingmüller U, et al. Structural and practical identifiability analysis of partially observed dynamical models by exploiting the profile likelihood. Bioinformatics. 2009;25:1923-1929. doi:10.1093/bioinformatics/btp358
18. O’Leary T, Williams AH, Franci A, Marder E. Cell Types, Network Homeostasis, and Pathological Compensation from a Biologically Plausible Ion Channel Expression Model. Neuron. 2014;82:809-821. doi:10.1016/j.neuron.2014.04.002
19. Silver RA, Momiyama A, Cull‐Candy SG. Locus of frequency‐dependent depression identified with multiple‐probability fluctuation analysis at rat climbing fibre‐Purkinje cell synapses. J Physiol. 1998;510:881-902. doi:10.1111/j.1469-7793.1998.881bj.x
20. Clements JD, Silver R. Unveiling synaptic plasticity: a new graphical and analytical approach. Trends Neurosci. 2000;23:105-113. doi:10.1016/S0166-2236(99)01520-9
21. Branco T, Staras K. The probability of neurotransmitter release: variability and feedback control at single synapses. Nat Rev Neurosci. 2009;10:373-383. doi:10.1038/nrn2634
22. Silver R. Estimation of nonuniform quantal parameters with multiple-probability fluctuation analysis: theory, application and limitations. J Neurosci Methods. 2003;130:127-141. doi:10.1016/j.jneumeth.2003.09.030
23. Dobrunz LE, Stevens CF. Heterogeneity of Release Probability, Facilitation, and Depletion at Central Synapses. Neuron. 1997;18:995-1008. doi:10.1016/S0896-6273(00)80338-4
24. Tsodyks MV, Markram H. The neural code between neocortical pyramidal neurons depends on neurotransmitter release probability. Proc Natl Acad Sci U S A. 1997;94:719-723. doi:10.1073/pnas.94.2.719
25. Neher E, Sakaba T. Multiple Roles of Calcium Ions in the Regulation of Neurotransmitter Release. Neuron. 2008;59:861-872. doi:10.1016/j.neuron.2008.08.019
26. Scheuss V, Neher E. Estimating Synaptic Parameters from Mean, Variance, and Covariance in Trains of Synaptic Responses. Biophys J. 2001;81:1970-1989. doi:10.1016/S0006-3495(01)75848-1
27. Markram H, Lübke J, Frotscher M, Roth A, Sakmann B. Physiology and anatomy of synaptic connections between thick tufted pyramidal neurones in the developing rat neocortex. J Physiol. 1997;500:409-440. doi:10.1113/jphysiol.1997.sp022031
28. Loebel A, Silberberg G, Helbig D, Markram H, Tsodyks M, Richardson MJ. Multiquantal release underlies the distribution of synaptic efficacies in the neocortex. Front Comput Neurosci. 2009;3:27. doi:10.3389/neuro.10.027.2009
29. Dürst CD, Wiegert JS, Schulze C, Helassa N, Török K, Oertner TG. Vesicular release probability sets the strength of individual Schaffer collateral synapses. Nat Commun. 2022;13:6126. doi:10.1038/s41467-022-33565-6
30. Kraushaar U, Jonas P. Efficacy and Stability of Quantal GABA Release at a Hippocampal Interneuron–Principal Neuron Synapse. J Neurosci. 2000;20:5594-5607. doi:10.1523/JNEUROSCI.20-15-05594.2000
31. Lou X, Scheuss V, Schneggenburger R. Allosteric modulation of the presynaptic Ca2+ sensor for vesicle fusion. Nature. 2005;435:497-501. doi:10.1038/nature03568
32. Schneggenburger R, Neher E. Intracellular calcium dependence of transmitter release rates at a fast central synapse. Nature. 2000;406:889-893. doi:10.1038/35022702
33. Schikorski T, Stevens CF. Quantitative Ultrastructural Analysis of Hippocampal Excitatory Synapses. J Neurosci. 1997;17:5858-5867. doi:10.1523/JNEUROSCI.17-15-05858.1997
34. Meyer AC, Neher E, Schneggenburger R. Estimation of Quantal Size and Number of Functional Active Zones at the Calyx of Held Synapse by Nonstationary EPSC Variance Analysis. J Neurosci. 2001;21:7889-7900. doi:10.1523/JNEUROSCI.21-20-07889.2001
35. Hanse E, Gustafsson B. Vesicle release probability and pre‐primed pool at glutamatergic synapses in area CA1 of the rat neonatal hippocampus. J Physiol. 2001;531:481-493. doi:10.1111/j.1469-7793.2001.0481i.x
36. Davis GW, Müller M. Homeostatic Control of Presynaptic Neurotransmitter Release. Annu Rev Physiol. 2015;77:251-270. doi:10.1146/annurev-physiol-021014-071740
37. Delvendahl I, Kita K, Müller M. Rapid and sustained homeostatic control of presynaptic exocytosis at a central synapse. Proc Natl Acad Sci U S A. 2019;116:23783-23789. doi:10.1073/pnas.1909675116
38. Müller M, Davis GW. Transsynaptic Control of Presynaptic Ca2+ Influx Achieves Homeostatic Potentiation of Neurotransmitter Release. Curr Biol. 2012;22:1102-1108. doi:10.1016/j.cub.2012.04.018
39. Ashburner M, Ball CA, Blake JA, Botstein D, Butler H, Cherry JM, et al. Gene Ontology: tool for the unification of biology. Nat Genet. 2000;25:25-29. doi:10.1038/75556
40. The Gene Ontology Consortium. The Gene Ontology knowledgebase in 2023. Genetics. 2023;224:iyad031. doi:10.1093/genetics/iyad031
41. Koopmans F, van Nierop P, Andres-Alonso M, Byrnes A, Cijsouw T, Coba MP, et al. SynGO: An Evidence-Based, Expert-Curated Knowledge Base for the Synapse. Neuron. 2019;103:217-234.e4. doi:10.1016/j.neuron.2019.05.002
42. Gandal MJ, Zhang P, Hadjimichael E, Walker RL, Chen C, Liu S, et al. Transcriptome-wide isoform-level dysregulation in ASD, schizophrenia, and bipolar disorder. Science. 2018;362:eaat8127. doi:10.1126/science.aat8127
43. Karczewski KJ, Francioli LC, Tiao G, Cummings BB, Alföldi J, Wang Q, et al. The mutational constraint spectrum quantified from variation in 141,456 humans. Nature. 2020;581:434-443. doi:10.1038/s41586-020-2308-7
44. Abrahams BS, Arking DE, Campbell DB, Mefford HC, Morrow EM, Weiss LA, et al. SFARI Gene 2.0: a community-driven knowledgebase for the autism spectrum disorders (ASDs). Mol Autism. 2013;4:36. doi:10.1186/2040-2392-4-36
45. Satterstrom FK, Kosmicki JA, Wang J, Breen MS, De Rubeis S, An JY, et al. Large-Scale Exome Sequencing Study Implicates Both Developmental and Functional Changes in the Neurobiology of Autism. Cell. 2020;180:568-584.e23. doi:10.1016/j.cell.2019.12.036
46. Fu JM, Satterstrom FK, Peng M, Brand H, Collins RL, Dong S, et al. Rare coding variation provides insight into the genetic architecture and phenotypic context of autism. Nat Genet. 2022;54:1320-1331. doi:10.1038/s41588-022-01104-0
47. Parikshak NN, Swarup V, Belgard TG, Irimia M, Ramaswami G, Gandal MJ, et al. Genome-wide changes in lncRNA, splicing, and regional gene expression patterns in autism. Nature. 2016;540:423-427. doi:10.1038/nature20612
48. Bucurenciu I, Kulik A, Schwaller B, Frotscher M, Jonas P. Nanodomain Coupling between Ca2+ Channels and Ca2+ Sensors Promotes Fast and Efficient Transmitter Release at a Cortical GABAergic Synapse. Neuron. 2008;57:536-545. doi:10.1016/j.neuron.2007.12.026
49. Vyleta NP, Jonas P. Loose Coupling Between Ca
            <sup>2+</sup>
            Channels and Release Sensors at a Plastic Hippocampal Synapse. Science. 2014;343:665-670. doi:10.1126/science.1244811
50. Eggermann E, Bucurenciu I, Goswami SP, Jonas P. Nanodomain coupling between Ca2+ channels and sensors of exocytosis at fast mammalian synapses. Nat Rev Neurosci. 2012;13:7-21. doi:10.1038/nrn3125
51. Campagnola L, Seeman SC, Chartrand T, Kim L, Hoggarth A, Gamlin C, et al. Local connectivity and synaptic dynamics in mouse and human neocortex. Science. 2022;375:eabj5861. doi:10.1126/science.abj5861
52. Velmeshev D, Schirmer L, Jung D, Haeussler M, Perez Y, Mayer S, et al. Single-cell genomics identifies cell type–specific molecular changes in autism. Science. 2019;364:685-689. doi:10.1126/science.aav8130
