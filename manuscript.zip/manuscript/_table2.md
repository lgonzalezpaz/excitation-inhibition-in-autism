| Lesion (20% reduction) | Compensating actuator | Δlog CV² | Δlog PPR | Direction (deg) | Residual norm |
|---|---|---|---|---|---|
| release sites (N) | presynaptic (fusion probability) | not reachable | — | — | — |
| release sites (N) | postsynaptic (quantal size) | +0.2231 | -0.0000 | -0.0 | 0.2231 |
| replenishment (k_rep) | presynaptic (fusion probability) | not reachable | — | — | — |
| replenishment (k_rep) | postsynaptic (quantal size) | +0.0000 | -0.0139 | -90.0 | 0.0139 |
| fusion probability (p) | presynaptic (fusion probability) | -0.0000 | -0.0000 | undefined | 0.0000 |
| fusion probability (p) | postsynaptic (quantal size) | +0.3506 | +0.1343 | +21.0 | 0.3754 |
| quantal size (q) | presynaptic (fusion probability) | not reachable | — | — | — |
| quantal size (q) | postsynaptic (quantal size) | +0.0000 | +0.0000 | undefined | 0.0000 |
