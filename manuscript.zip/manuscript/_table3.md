| Outcome | Gene set | n genes | Adjusted OR (95% CI) | P | Matched enrichment | P (permutation) |
|---|---|---|---|---|---|---|
| ASD risk gene (SFARI 1–2) | Capacity axis | 141 | 1.59 (0.95–2.65) | 0.0765 | 1.56 | 0.0471 |
| ASD risk gene (SFARI 1–2) | Actuator axis | 113 | 2.19 (1.27–3.76) | 0.00458 | 1.94 | 0.0041 |
| ASD risk gene (SFARI 1–2) | Postsynaptic (control) | 734 | 2.33 (1.87–2.90) | 4.68e-14 | 2.07 | 0.0001 |
| ASD risk gene (SFARI 1–2) | Vesicle endocytosis (control) | 51 | 1.15 (0.45–2.98) | 0.769 | 1.32 | 0.6519 |
| Altered in ASD cortex | Capacity axis | 141 | 1.06 (0.62–1.83) | 0.826 | 1.11 | 0.7577 |
| Altered in ASD cortex | Actuator axis | 113 | 2.18 (1.34–3.53) | 0.00164 | 1.93 | 0.0048 |
| Altered in ASD cortex | Postsynaptic (control) | 734 | 1.56 (1.25–1.95) | 9.43e-05 | 1.51 | 0.0001 |
| Altered in ASD cortex | Vesicle endocytosis (control) | 51 | 0.55 (0.17–1.78) | 0.322 | 0.59 | 0.4717 |
| Reduced in ASD cortex | Capacity axis | 141 | 1.44 (0.77–2.69) | 0.255 | 1.40 | 0.3194 |
| Reduced in ASD cortex | Actuator axis | 113 | 3.53 (2.10–5.92) | 1.88e-06 | 3.03 | 0.0001 |
| Reduced in ASD cortex | Postsynaptic (control) | 734 | 2.20 (1.70–2.86) | 2.99e-09 | 2.07 | 0.0001 |
| Reduced in ASD cortex | Vesicle endocytosis (control) | 51 | 0.35 (0.05–2.51) | 0.294 | 0.34 | 0.4076 |
