
**Figure 1. The excitation–inhibition ratio has a rank-one sensitivity to presynaptic parameters.**
(**a**) The release model. A terminal carries *N* independent release sites supplied from a vesicle pool at rate *k*~rep~; each occupied site fuses with probability *p* on an action potential and produces a postsynaptic response of mean size *q*. The mean, the squared coefficient of variation and the failure probability of the response follow in closed form.
(**b**) Along the curve of parameter combinations that hold the mean fixed, the mean amplitude and therefore the excitation–inhibition ratio are constant by construction, while the squared coefficient of variation and the failure probability vary over more than an order of magnitude. Values are normalised to the literature-parameterised operating point (dotted line).
(**c**) Elasticity matrix of the five-component observable vector with respect to the four log-parameters, for the neocortical layer-5 connection. Entries are ∂(observable)/∂(log parameter). The first row alone has rank 1; the full matrix has rank 4.

**Figure 2. The model is exact and reproduces measurements it was not fitted to.**
(**a**, **b**) Mean quantal content and squared coefficient of variation through an eight-pulse 20 Hz train at three literature-parameterised synapses. Lines, exact recursions; open symbols, site-level Markov-chain simulation of 400,000 trials.
(**c**) Dependence of fusion probability on external calcium. Filled circles, the two measured Schaffer collateral release probabilities used as anchors; diamond, the value predicted at the physiological 2 mM with the cooperativity fixed at its independently measured value; open square with error bars, an independent measurement from a different laboratory and preparation (mean ± s.d., *n* = 43).
(**d**) A simulated multiple-probability fluctuation analysis with 60 trials at each of seven external calcium concentrations, fitted by weighted least squares.
(**e**) Recovery of the release-site number across 300 simulated experiments per condition. Symbols, median; bars, 95 per cent interval; dashed segments, the true value. A 30 per cent increase in fusion probability leaves the estimate numerically identical to wild type.
(**f**) Three quantities that entered no part of the parameterisation, compared with their published measurements.

**Figure 3. A mean-restoring controller leaves a residual, and presynaptic compensation saturates.**
(**a**) Schematic. A controller that restores the mean moves the system along the horizontal axis only, so any displacement along the orthogonal direction survives it.
(**b**) Residual trajectories in the plane of the two routine mean-invariant coordinates after exact restoration of the sustained drive by postsynaptic scaling, for lesions of increasing severity from 5 to 50 per cent. The three lesion axes lie on distinct rays.
(**c**) The same analysis with presynaptic compensation. The remaining axes collapse towards collinearity; a loss of release sites cannot be offset by this actuator at all (panels e, f).
(**d**) Direction of the residual for each lesion axis under postsynaptic compensation. A quantal-size lesion offset by quantal scaling leaves no residual and has no direction; it is omitted.
(**e**) The largest fractional loss of release sites that raising fusion probability can still offset, as a function of ongoing firing rate.
(**f**) Why the ceiling exists. Sustained drive approaches a bound that is proportional to the resupply rate and contains no fusion-probability term. Symbols mark the measured operating point of the excitatory layer-5 connection.

**Figure 4. A non-selective lesion produces an apparent imbalance.**
(**a**, **b**) Elasticity of sustained drive to fusion probability and to resupply rate across the physiological plane at 20 Hz, with the measured operating points of the excitatory and inhibitory reference synapses marked.
(**c**) Apparent change in the excitation–inhibition ratio produced by a 20 per cent reduction applied identically to both synapse classes, as a function of ongoing firing rate. A loss of release sites produces exactly no change at any rate.
(**d**) The same comparison at 20 Hz for two excitatory references. The sign of the shift identifies the lesioned parameter.

**Figure 5. In human cortex the actuator axis carries the transcriptional signature.**
(**a**) The two gene sets are matched on coding constraint and on gene length (two-sided Mann–Whitney).
(**b**) Enrichment of each gene set for three outcomes, by logistic regression adjusted for constraint, gene and transcript length and GC content. Points, odds ratio; bars, 95 per cent confidence interval. \*P < 0.05, \*\*P < 0.01, \*\*\*P < 0.001; n.s., not significant.
(**c**) Null distributions for the proportion of genes reduced in autistic cortex, built by resampling gene sets of matched size from the same joint deciles of constraint and gene length (20,000 permutations). Vertical lines, observed values.
(**d**) Direction of change among differentially expressed genes of each set, against the direction split of all differentially expressed genes (dashed line); exact binomial test.
(**e**) The same proportion resolved by individual annotation term. Symbol area is proportional to the number of genes.

**Figure 6. Measurement requirements for the decisive experiment.**
(**a**) Fisher information about the resupply rate carried by a paired-pulse protocol, as a function of inter-pulse interval, normalised to its maximum. Stars mark the optimum, which lies close to the reciprocal of the resupply rate.
(**b**) Trials per group needed to detect a given fractional difference with 80 per cent power at α = 0.05, at the allocation maximising the determinant of the information matrix.
(**c**) Trials needed to distinguish the true release-site number from a neighbouring integer at matched mean quantal content. The inset text reports maximum-likelihood recovery of the full parameter vector from a three-interval protocol.
