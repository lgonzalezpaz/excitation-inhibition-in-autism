| Synapse | Optimal interval for k_rep (ms) | Trials, p 20% | Trials, p 10% | Trials, k_rep 20% | Trials, k_rep 10% | Trials, k_rep 20% with steady state | Trials to resolve one fewer / one more site |
|---|---|---|---|---|---|---|---|
| Excitatory, neocortical L5 to L5 | 400 | 52 | 232 | 2270 | 10184 | 795 | 69 / 209 |
| Excitatory, Schaffer collateral to CA1 | 400 | 77 | 344 | 2325 | 10427 | 1490 | 10 / 73 |
| Inhibitory, basket cell to granule cell | 1800 | 53 | 238 | 1962 | 8799 | 2657 | 12 / 47 |
